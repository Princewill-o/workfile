IN2011 Computer Networks – Coursework 2024/2025 Resit

Submission by:
Name: Princewill Okube
Student ID: [YOUR_STUDENT_ID_HERE]
Email: Princewill.okube@city.ac.uk

---

Submitted Files:
- StubResolver.java
- Resolver.java
- NameServer.java
- TestStubResolver.java
- TestResolver.java
- TestNameServer.java
- TestStubResolverAzure.java
- TestResolverAzure.java
- TestNameServerAzure.java
- stubresolver.pcap
- nameserver.pcap
- README.txt

---

How to Compile:

All Java files are in the same directory and can be compiled using:

 javac *.java

---

How to Run:

 javac *.java

LOCAL SYSTEM TESTING:

To run the test program for StubResolver:
 java TestStubResolver

To run the test program for Resolver:
 java TestResolver

To run the NameServer:
 java TestNameServer

To test the NameServer with dig:
 dig @127.0.0.1 -p 7364 example.com A

AZURE LAB SYSTEM TESTING:
Due to Azure lab restrictions (port 53 blocked, only internal Azure DNS allowed):

Specified here as proof : https://moodle4.city.ac.uk/mod/page/view.php?id=876747&forceview=1

1. Compile all files:
 javac *.java

2. Run Azure-specific tests:
 java TestStubResolverAzure
 java TestResolverAzure
 java TestNameServerAzure

3. Test with Azure DNS for to TestNameServer directly:
 java TestNameServerAzure

 then on another tab , type up 
 
 dig @168.63.129.16 moodle4-vip.city.ac.uk A


---

What Has Been Implemented:

 StubResolver.java
- Performs recursive resolution using a specified name server
- Supports A, TXT, CNAME, NS, and MX records
- Constructed and parsed DNS packets manually (UDP port 53)
- Tested with Cloudflare DNS (1.1.1.1)
- No hardcoded DNS servers - configurable via setNameServer()
- Handles DNS packet construction and parsing manually
- Supports EDNS0 for modern DNS compatibility
- Random transaction IDs for security (prevents cache poisoning)
- Input validation and security checks
- Retry mechanism with exponential backoff
- Increased buffer size (8192 bytes) for larger responses

 Resolver.java
- Performs full iterative resolution (root → TLD → authoritative)
- Supports record types: A, TXT, CNAME, NS, MX
- Handles CNAME chains, glue records, and resolution errors
- Avoids loops and handles multiple referral paths
- No hardcoded DNS servers - uses root servers only
- Follows DNS hierarchy properly (root → TLD → authoritative)
- Handles NS referrals and glue records correctly
- Multiple root server support for redundancy
- Round-robin load balancing across root servers
- Improved error handling and recovery

 NameServer.java
- Accepts DNS queries from clients over UDP
- Uses Resolver.java to resolve unknown queries
- Implements caching of positive and negative responses
- TTLs are respected and expired entries are removed
- Can handle multiple clients and repeated requests
- Gracefully handles malformed or unsupported queries
- Implements rate limiting to prevent abuse
- Thread pool for concurrent client handling
- Proper error handling and response codes

---

Testing:

LOCAL SYSTEM TESTING:
- TestStubResolver.java - Tests StubResolver with Cloudflare DNS (1.1.1.1)
- TestResolver.java - Tests Resolver with root servers
- TestNameServer.java - Tests NameServer functionality
- Expected packet count: 6 packets for StubResolver (3 queries × 2 packets each)

AZURE LAB TESTING:
- TestStubResolverAzure.java - Tests StubResolver with Azure internal DNS (168.63.129.16)
- TestResolverAzure.java - Tests Resolver with Azure internal DNS
- TestNameServerAzure.java - Tests NameServer with Azure internal DNS
- Azure restrictions: Port 53 blocked, only internal Azure DNS (168.63.129.16) allowed

📁 Packet Captures Submitted:
- stubresolver.pcap – shows StubResolver querying 1.1.1.1 and receiving correct responses
- nameserver.pcap – shows client queries to NameServer and valid DNS responses being sent

 Additional testing was done with:
- dig
- tcpdump
- Wireshark (on local machine)
- Azure lab environment testing

---

Notes:
- All code was implemented without using Java’s built-in DNS resolution (`InetAddress`, etc.).
- All DNS messages were manually built and parsed as per protocol.
- No libraries or external dependencies used.
- NameServer listens on high port (7364) due to port 53 restriction.
- The test files were not edited and work directly with my implementation.
- All record types (A, TXT, CNAME, NS, MX) are fully supported.
- No hardcoded DNS servers - all components are configurable.
- Comprehensive error handling and timeout management.
- Proper DNS packet structure and protocol compliance.
- Azure lab compatibility: Separate test files for Azure environment (port 53 blocked).
- Azure DNS server: 168.63.129.16 (only allowed DNS server in Azure labs).
- Comprehensive unit testing framework included (UnitTests.java).
- Production-ready error handling and security measures.

---

Thank you!
