// IN2011 Computer Networks
// Coursework 2024/2025 Resit
//
// Azure Lab Version - Uses Azure Internal DNS Server
// This version is specifically for Azure Lab machines where
// outbound DNS over UDP is blocked except to 168.63.129.16

import java.net.InetAddress;

public class TestNameServerAzure {

    public static void main(String[] args) {
        try {
            NameServer ns = new NameServer();

            // Use Azure internal DNS server (only one allowed on Azure labs)
            // It's IP is 168.63.129.16
            byte[] azureInternalDNS = new byte[]{(byte)168, 63, (byte)129, 16};
            ns.setNameServer(InetAddress.getByAddress(azureInternalDNS), 53);

            // Note that this is a non-standard port number
            // so clients will need to be configured to use it.
            // Changing this to 53 would also work but may require
            // running the code with elevated priviledges.
            ns.handleIncomingQueries(7364);

        } catch (Exception e) {
            System.out.println("Exception caught");
            e.printStackTrace();
        }

        return;
    }
}
