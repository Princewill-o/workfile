// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  YOUR_NAME_GOES_HERE
//  YOUR_STUDENT_ID_NUMBER_GOES_HERE
//  YOUR_EMAIL_GOES_HERE

// DO NOT EDIT starts
// This gives the interface that your code must implement.

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

interface NodeInterface {

    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;

    // Handle incoming messages with a timeout.
    public void handleIncomingMessages(int delay) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    public boolean isActive(String nodeName) throws Exception;

    // Methods for relaying messages.
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;

    // CRN-25 network functionality
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

// DO NOT EDIT ends

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new HashMap<>();
    private Stack<String> relayStack = new Stack<>();

    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException ignored) {
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        String command = parts[0];
        String response = "ERROR";

        switch (command) {
            case "EXISTS":
                response = (parts.length > 1) ? Boolean.toString(dataStore.containsKey(parts[1])) : "ERROR";
                break;
            case "READ":
                response = (parts.length > 1) ? dataStore.getOrDefault(parts[1], "NULL") : "ERROR";
                break;
            case "WRITE":
                String[] keyValue = (parts.length > 1) ? parts[1].split(" ", 2) : new String[0];
                if (keyValue.length == 2) {
                    dataStore.put(keyValue[0], keyValue[1]);
                    response = "OK";
                }
                break;
            case "CAS":
                String[] casParts = (parts.length > 1) ? parts[1].split(" ", 3) : new String[0];
                if (casParts.length == 3 && dataStore.containsKey(casParts[0])) {
                    if (dataStore.get(casParts[0]).equals(casParts[1])) {
                        dataStore.put(casParts[0], casParts[2]);
                        response = "OK";
                    } else {
                        response = "FAIL";
                    }
                }
                break;
        }
        sendResponse(response, sender, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    public boolean isActive(String nodeName) throws Exception {
        // Implement logic to check if node is active via UDP message exchange
        return true;
    }

    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    public String read(String key) throws Exception {
        return dataStore.getOrDefault(key, null);
    }

    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }
}
