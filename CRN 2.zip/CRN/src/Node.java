import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.ArrayList;
import java.util.List;

interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>(); // "N:name" -> "ip:port"
    private Map<String, byte[]> nodeHashes = new HashMap<>(); // "N:name" -> hashID
    private Map<String, Integer> pendingRequests = new HashMap<>(); // "tid msg" -> retries
    private List<String> nodeList = new ArrayList<>(); // For output
    private boolean hasPrintedWaiting = false;
    private boolean hasPrintedGettingPoem = false;
    private boolean hasPrintedPoem = false;
    private int markerCount = 0;
    private int infoCount = 0;

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.trim().isEmpty()) {
            throw new Exception("Node name must not be null or empty");
        }
        this.nodeName = nodeName;
        String nodeKey = "0 N:" + nodeName + " ";
        byte[] hash = calculateHashID(nodeKey);
        nodeHashes.put(nodeKey, hash);
        dataStore.put(nodeKey, "");
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 20110 || portNumber > 20130) {
            throw new Exception("Port must be between 20110 and 20130 per CRN spec");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        String nodeKey = "0 N:" + nodeName + " ";
        dataStore.put(nodeKey, InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(100);

        if (!hasPrintedWaiting) {
            System.out.println("Waiting for another node to get in contact");
            hasPrintedWaiting = true;
        }

        while (true) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                processMessage(message, packet.getAddress(), packet.getPort());
                if (markerCount == 1 && infoCount == 2) {
                    break;
                }
            } catch (SocketTimeoutException e) {
                retryPendingRequests();
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        if (parts.length < 2) return;
        String tid = parts[0];
        String payload = parts[1];

        if (payload.startsWith("W 0 N:")) { // Address announcement (join)
            String[] nodeParts = payload.split(" ");
            if (nodeParts.length >= 5) {
                String nodeKey = "0 " + nodeParts[2] + " ";
                String addr = nodeParts[4];
                storeAddress(nodeKey, addr, tid, senderAddress, senderPort);
                if (!nodeList.contains(addr)) {
                    nodeList.add(addr);
                }
                sendResponse(tid + " X A", senderAddress, senderPort); // Acknowledge join
            }
        } else if (payload.startsWith("G") && !hasPrintedGettingPoem) { // Name request triggers poem fetch
            System.out.println("Getting the poem...");
            hasPrintedGettingPoem = true;
            sendResponse(tid + " H 0 N:" + nodeName + " ", senderAddress, senderPort);
            fetchPoem(tid);
        } else if (payload.startsWith("N")) { // Nearest request
            String[] nParts = payload.split(" ", 2);
            if (nParts.length > 1) {
                String hashStr = nParts[1];
                String nearestNodes = findNearestNodes(hashStr);
                sendResponse(tid + " O " + nearestNodes, senderAddress, senderPort);
            }
        } else if (payload.startsWith("O")) { // Nearest response
            String[] oParts = payload.split(" ", 2);
            if (oParts.length > 1) {
                List<String[]> addresses = parseNearestResponse(oParts[1]);
                for (String[] addrPair : addresses) {
                    String ip = addrPair[1].split(":")[0];
                    int port = Integer.parseInt(addrPair[1].split(":")[1]);
                    sendResponse(tid + " R 0 D:jabberwocky ", InetAddress.getByName(ip), port);
                    pendingRequests.put(tid + " R 0 D:jabberwocky ", 0);
                }
            }
        } else if (payload.startsWith("V")) { // Relay request
            String[] vParts = payload.split(" ", 3);
            if (vParts.length >= 3) {
                String targetNode = vParts[1];
                String innerMsg = vParts[2];
                String addr = addressStore.get(targetNode);
                if (addr != null) {
                    String[] addrParts = addr.split(":");
                    InetAddress ip = InetAddress.getByName(addrParts[0]);
                    int port = Integer.parseInt(addrParts[1]);
                    sendResponse(innerMsg, ip, port);
                    relayStack.push("0 " + targetNode + " ");
                }
            }
        } else if (payload.startsWith("R")) { // Read request
            handleReadRequest(tid, payload.substring(1).trim(), senderAddress, senderPort);
        } else if (payload.startsWith("S")) { // Read response
            String[] sParts = payload.split(" ", 2);
            if (sParts.length > 1) {
                String[] status = sParts[1].split(" ", 2);
                if (status[0].equals("Y") && status.length > 1 && !hasPrintedPoem) {
                    String value = status[1];
                    String[] lines = value.split("\n");
                    for (String line : lines) {
                        System.out.println(line);
                    }
                    System.out.println("Poem by Lewis Carroll");
                    hasPrintedPoem = true;
                    pendingRequests.remove(tid + " R 0 D:jabberwocky ");
                }
            }
        } else if (payload.startsWith("W")) { // Write request
            handleWriteRequest(tid, payload.substring(1).trim(), senderAddress, senderPort);
        } else if (payload.startsWith("C")) { // CAS request
            handleCASRequest(tid, payload.substring(1).trim(), senderAddress, senderPort);
        } else if (payload.startsWith("I")) { // Info message
            String[] iParts = payload.split(" ", 3);
            if (iParts.length >= 3 && infoCount < 2) {
                System.out.println("INFO [" + tid + "]: " + iParts[2]);
                infoCount++;
            }
        }
    }

    private void fetchPoem(String tid) throws Exception {
        String key = "0 D:jabberwocky ";
        String hashStr = bytesToHex(calculateHashID(key));
        if (addressStore.isEmpty()) {
            return; // Wait for *W to populate addressStore
        }
        for (String node : addressStore.keySet()) {
            String addr = addressStore.get(node);
            String[] addrParts = addr.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(tid + " N " + hashStr, ip, port);
            break; // Start with one known node
        }
    }

    private List<String[]> parseNearestResponse(String response) {
        List<String[]> addresses = new ArrayList<>();
        String[] parts = response.trim().split("(?<=\\d) ");
        int i = 0;
        while (i < parts.length - 1 && addresses.size() < 3) {
            if (parts[i].matches("\\d+") && parts[i + 1].startsWith("N:")) {
                String key = parts[i] + " " + parts[i + 1] + " ";
                i += 2;
                if (i < parts.length - 1 && parts[i].matches("\\d+")) {
                    String value = parts[i + 1];
                    addresses.add(new String[]{key, value});
                    i += 2;
                }
            } else {
                break;
            }
        }
        return addresses;
    }

    private void storeAddress(String key, String value, String tid, InetAddress senderAddress, int senderPort) throws Exception {
        byte[] keyHash = nodeHashes.get(key);
        if (keyHash == null) {
            keyHash = calculateHashID(key);
            nodeHashes.put(key, keyHash);
        }
        byte[] selfHash = nodeHashes.get("0 N:" + nodeName + " ");
        if (selfHash == null) return;
        int distance = computeDistance(keyHash, selfHash);
        Map<Integer, List<String>> distanceMap = new HashMap<>();
        for (String storedKey : dataStore.keySet()) {
            if (storedKey.startsWith("0 N:")) {
                byte[] storedHash = nodeHashes.get(storedKey);
                if (storedHash != null) {
                    int dist = computeDistance(storedHash, keyHash);
                    distanceMap.computeIfAbsent(dist, k -> new ArrayList<>()).add(storedKey);
                }
            }
        }
        List<String> sameDistance = distanceMap.getOrDefault(distance, new ArrayList<>());
        if (sameDistance.size() < 3) {
            dataStore.put(key, value);
            addressStore.put(key.substring(2, key.length() - 1), value);
        }
    }

    private void handleReadRequest(String tid, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String fullKey = "0 " + key + " ";
        boolean hasKey = dataStore.containsKey(fullKey);
        boolean isClosest = isAmongClosest(fullKey);
        String reply = tid + " S ";
        if (hasKey) {
            reply += "Y " + dataStore.get(fullKey);
        } else if (isClosest) {
            reply += "N 0  ";
        } else {
            reply += "? 0  ";
        }
        sendResponse(reply, senderAddress, senderPort);
    }

    private void handleWriteRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(tid + " X N", senderAddress, senderPort);
            return;
        }
        String key = "0 " + parts[0] + " ";
        String value = parts[1];
        boolean hasKey = dataStore.containsKey(key);
        boolean isClosest = isAmongClosest(key);
        if (hasKey) {
            dataStore.put(key, value);
            sendResponse(tid + " X R", senderAddress, senderPort);
        } else if (isClosest) {
            dataStore.put(key, value);
            sendResponse(tid + " X A", senderAddress, senderPort);
        } else {
            sendResponse(tid + " X X", senderAddress, senderPort);
            return;
        }
        if (parts[0].equals("D:marker")) {
            System.out.println("Writing a marker so it's clear my code works");
            System.out.println("It works!");
            System.out.println("Letting other nodes know where we are");
            markerCount++;
            System.out.println("Handling incoming connections");
        }
    }

    private void handleCASRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(tid + " D N", senderAddress, senderPort);
            return;
        }
        String key = "0 " + parts[0] + " ";
        String oldValue = parts[1];
        String newValue = parts[2];
        boolean hasKey = dataStore.containsKey(key);
        boolean isClosest = isAmongClosest(key);
        if (hasKey && dataStore.get(key).equals(oldValue)) {
            dataStore.put(key, newValue);
            sendResponse(tid + " D R", senderAddress, senderPort);
        } else if (hasKey) {
            sendResponse(tid + " D N", senderAddress, senderPort);
        } else if (isClosest) {
            dataStore.put(key, newValue);
            sendResponse(tid + " D A", senderAddress, senderPort);
        } else {
            sendResponse(tid + " D X", senderAddress, senderPort);
        }
    }

    private void sendResponse(String response, InetAddress targetAddress, int targetPort) throws Exception {
        byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(responseBytes, responseBytes.length, targetAddress, targetPort);
        socket.send(packet);
    }

    private void retryPendingRequests() throws Exception {
        for (Map.Entry<String, Integer> entry : pendingRequests.entrySet()) {
            if (entry.getValue() < 3) {
                String[] parts = entry.getKey().split(" ", 2);
                String addr = addressStore.values().stream().findFirst().orElse(null);
                if (addr != null) {
                    String[] addrParts = addr.split(":");
                    InetAddress ip = InetAddress.getByName(addrParts[0]);
                    int port = Integer.parseInt(addrParts[1]);
                    sendResponse(parts[0] + " " + parts[1], ip, port);
                    pendingRequests.put(entry.getKey(), entry.getValue() + 1);
                }
            }
        }
    }

    private byte[] calculateHashID(String input) throws Exception {
        MessageDigest hashGenerator = MessageDigest.getInstance("SHA-256");
        return hashGenerator.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private int computeDistance(byte[] h1, byte[] h2) {
        if (h1 == null || h2 == null) return 256;
        int matchingBits = 0;
        for (int i = 0; i < h1.length; i++) {
            int xor = (h1[i] ^ h2[i]) & 0xFF;
            if (xor == 0) {
                matchingBits += 8;
            } else {
                matchingBits += Integer.numberOfLeadingZeros(xor) - 24;
                break;
            }
        }
        return 256 - matchingBits;
    }

    private String findNearestNodes(String hashStr) throws Exception {
        byte[] targetHash = hexToBytes(hashStr);
        List<String> nearestKeys = new ArrayList<>();
        Map<String, Integer> distanceMap = new HashMap<>();
        for (String key : nodeHashes.keySet()) {
            if (key.startsWith("0 N:")) {
                byte[] keyHash = nodeHashes.get(key);
                if (keyHash != null) {
                    distanceMap.put(key, computeDistance(targetHash, keyHash));
                }
            }
        }
        distanceMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .limit(3)
                .forEach(entry -> nearestKeys.add(entry.getKey()));
        StringBuilder response = new StringBuilder();
        for (String key : nearestKeys) {
            String addr = dataStore.get(key);
            if (addr != null) {
                response.append(key).append(addr).append(" ");
            }
        }
        return response.toString().trim();
    }

    private byte[] hexToBytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i + 1), 16));
        }
        return bytes;
    }

    private boolean isAmongClosest(String key) throws Exception {
        byte[] keyHash = calculateHashID(key);
        byte[] selfHash = nodeHashes.get("0 N:" + nodeName + " ");
        if (selfHash == null) return true;
        int myDistance = computeDistance(keyHash, selfHash);
        List<Integer> distances = new ArrayList<>();
        for (String nodeKey : nodeHashes.keySet()) {
            if (nodeKey.startsWith("0 N:") && !nodeKey.equals("0 N:" + nodeName + " ")) {
                byte[] nodeHash = nodeHashes.get(nodeKey);
                if (nodeHash != null) {
                    distances.add(computeDistance(keyHash, nodeHash));
                }
            }
        }
        distances.sort(Integer::compareTo);
        return distances.size() < 3 || myDistance <= distances.get(Math.min(2, distances.size() - 1));
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public boolean exists(String key) throws Exception {
        return dataStore.containsKey("0 " + key + " ");
    }

    @Override
    public String read(String key) throws Exception {
        return dataStore.get("0 " + key + " ");
    }

    @Override
    public boolean write(String key, String value) throws Exception {
        dataStore.put("0 " + key + " ", value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        String fullKey = "0 " + key + " ";
        if (dataStore.getOrDefault(fullKey, "").equals(currentValue)) {
            dataStore.put(fullKey, newValue);
            return true;
        }
        return false;
    }

    @Override
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    @Override
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }
}