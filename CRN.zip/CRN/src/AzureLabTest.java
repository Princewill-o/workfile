import java.nio.charset.StandardCharsets;
import java.util.Random;

class AzureLabTest {
	public static void main(String[] args) {
		String emailAddress = "Princewill.okube@city.ac.uk";
		if (false && emailAddress.indexOf('@') == -1) {
			System.err.println("Please set your e-mail address!");
			System.exit(1);
		}
		String ipAddress = "10.216.35.255";
		if (false && ipAddress.indexOf('.') == -1) {
			System.err.println("Please set your IP address!");
			System.exit(1);
		}

		try {
			// Create a node and initialize it
			Node node = new Node();
			String nodeName = "N:" + emailAddress;
			node.setNodeName(nodeName);

			int port = 20110;
			node.openPort(port);

			// Wait for incoming connections
			System.out.println("Waiting for another node to contact...");
			node.handleIncomingMessages(12 * 1000);

			// Reading key/value pairs stored on the network
			System.out.println("Retrieving stored data...");
			for (int i = 0; i < 7; ++i) {
				String key = "D:jabberwocky" + i;
				String value = node.read(key);
				if (value == null) {
					System.err.println("Cannot find stored data " + i);
				} else {
					System.out.println(value);
				}
			}

			// Writing a key/value pair
			System.out.println("Writing a marker to verify functionality...");
			{
				String key = "D:" + emailAddress;
				byte[] hashedKey = HashID.computeHashID(key);
				String hashString = bytesToHex(hashedKey);
				String value = "It works!";
				node.write(hashString, value);

				// Read it back to confirm
				System.out.println("Stored value: " + node.read(hashString));
			}

			// Register the node
			System.out.println("Registering node on network...");
			node.write(nodeName, ipAddress + ":" + port);

			System.out.println("Handling incoming requests...");
			node.handleIncomingMessages(0);

		} catch (Exception e) {
			System.err.println("Exception during AzureLabTest execution");
			e.printStackTrace(System.err);
		}
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuilder hexString = new StringBuilder();
		for (byte b : bytes) {
			hexString.append(String.format("%02x", b));
		}
		return hexString.toString();
	}
}