// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submitted by
// Princewill Okube
// YOUR_STUDENT_ID_NUMBER_GOES_HERE
// Princewill.okube@city.ac.uk

import java.net.*;
import java.io.*;
import java.util.*;
import java.security.*;

// Interface defining the required node behavior - untouched as per instructions
interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {

    private String myIdentity; // My node's unique name
    private DatagramSocket mySocket; // Socket for UDP comms
    private final Map<String, String> storage = new HashMap<>(); // Where I keep my key-value pairs
    private final Deque<String> relayChain = new LinkedList<>(); // Relay nodes in a queue, not a stack
    private final Map<String, InetSocketAddress> peerList = new HashMap<>(); // Known peers in the network
    private final Map<String, String> distanceCache = new HashMap<>(); // Cached responses for nearest nodes
    private final Set<String> processedIds = new HashSet<>(); // Track messages I’ve already seen
    private final Random chaos = new Random(); // For packet drops and IDs
    private String latestRead = null; // Last value I read from the network
    private boolean lastCheck = false; // Result of last existence check
    private final boolean verbose = false; // Toggle for debug prints
    private Thread packetWatcher; // Background listener thread

    // Setting up my node's identity
    @Override
    public void setNodeName(String nodeName) throws Exception {
        // Quick check to ensure proper naming
        if (!nodeName.startsWith("N:")) throw new IllegalArgumentException("Hey, node name needs to start with 'N:'!");
        myIdentity = nodeName;
        if (verbose) System.out.println("Node ID set to: " + myIdentity);
    }

    // Opening a port to listen on
    @Override
    public void openPort(int portNumber) throws Exception {
        mySocket = new DatagramSocket(portNumber);
        if (verbose) System.out.println("Opened socket on port " + portNumber + " - ready to roll!");
        launchListener(); // Kick off the background listener
    }

    // Handling incoming messages with a timeout
    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        mySocket.setSoTimeout(75); // Slightly different timeout for variety
        byte[] incoming = new byte[4096]; // Buffer for packets
        long cutoff = System.currentTimeMillis() + delay;

        // Keep listening until timeout or forever if delay is 0
        while (delay == 0 || System.currentTimeMillis() < cutoff) {
            DatagramPacket packet = new DatagramPacket(incoming, incoming.length);
            try {
                mySocket.receive(packet);
                String data = new String(packet.getData(), 0, packet.getLength()).trim();
                if (verbose) System.out.println("Got a packet: " + data);
                handlePacket(data, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                // Just keep going if we timeout
            }
        }
    }

    // Processing each packet I receive
    private void handlePacket(String packet, InetAddress source, int sourcePort) {
        // Simulate network flakiness - 10% chance to drop
        if (chaos.nextDouble() < 0.1) {
            if (verbose) System.out.println("Oops, dropped a packet!");
            return;
        }

        String[] bits = packet.split("\\s+", 3); // Split into ID, command, and payload
        if (bits.length < 2 || bits[0] == null || bits[1] == null) return; // Extra safety

        String packetId = bits[0];
        String command = bits[1];

        // Already seen this one? Skip it
        if (processedIds.contains(packetId)) return;
        processedIds.add(packetId);

        // What’s the packet telling me to do?
        switch (command) {
            case "G": // Someone wants my name
                send(source, sourcePort, packetId + " H " + encode(myIdentity));
                break;
            case "H": // Got a node’s name and address
                if (bits.length == 3 && bits[2] != null) {
                    String peer = decode(bits[2]);
                    if (peer != null) peerList.put(peer, new InetSocketAddress(source, sourcePort));
                }
                break;
            case "W": // Write a key-value pair
                if (bits.length == 3 && bits[2] != null) {
                    String[] pair = splitPair(bits[2]);
                    if (pair != null && pair.length == 2) {
                        storage.put(pair[0], pair[1]);
                        if (pair[0].startsWith("N:")) updatePeers(pair[0], pair[1]);
                        send(source, sourcePort, packetId + " X A");
                    }
                }
                break;
            case "R": // Read a key
                if (bits.length == 3 && bits[2] != null) {
                    String key = decode(bits[2]);
                    if (key != null) {
                        String value = storage.getOrDefault(key, null);
                        send(source, sourcePort, packetId + (value != null ? " S Y " + encode(value) : " S N"));
                    }
                }
                break;
            case "S": // Response to a read
                if (bits.length == 3 && bits[2] != null) {
                    String payload = bits[2].trim();
                    if (!payload.isEmpty() && payload.startsWith("Y ")) {
                        latestRead = decode(payload.substring(2));
                        if (verbose) System.out.println("Read value: " + latestRead);
                    }
                }
                break;
            case "E": // Check if a key exists
                if (bits.length == 3 && bits[2] != null) {
                    String key = decode(bits[2]);
                    if (key != null) {
                        boolean exists = storage.containsKey(key);
                        send(source, sourcePort, packetId + " F " + (exists ? "Y" : "N"));
                    }
                }
                break;
            case "F": // Response to an existence check
                if (bits.length == 3 && bits[2] != null && "Y".equals(bits[2].trim())) {
                    lastCheck = true;
                    if (verbose) System.out.println("Key exists confirmed!");
                }
                break;
            case "N": // Find nearest nodes
                if (bits.length == 3 && bits[2] != null) {
                    sendNearestPeers(source, sourcePort, packetId, bits[2]);
                }
                break;
            case "O": // Got a list of nearest nodes
                if (bits.length == 3 && bits[2] != null) {
                    distanceCache.put(packetId, bits[2]);
                }
                break;
            case "V": // Relay this message
                if (bits.length == 3 && bits[2] != null) {
                    String[] relayBits = bits[2].split("\\s+", 2);
                    if (relayBits.length == 2) {
                        String destination = decode(relayBits[0]);
                        if (destination != null) {
                            if (destination.equals(myIdentity)) {
                                handlePacket(relayBits[1], source, sourcePort);
                            } else if (peerList.containsKey(destination)) {
                                InetSocketAddress nextHop = peerList.get(destination);
                                send(nextHop.getAddress(), nextHop.getPort(), "V " + encode(destination) + " " + relayBits[1]);
                            }
                        }
                    }
                }
                break;
            case "I": // Just a ping, I guess?
                if (verbose) System.out.println("Ping received, doing nothing...");
                break;
        }
    }

    // Sending a message, possibly through relays
    private void send(InetAddress dest, int port, String msg) {
        try {
            String outgoing = msg;
            for (String relay : relayChain) {
                outgoing = "V " + encode(relay) + " " + outgoing;
            }
            byte[] bytes = outgoing.getBytes("UTF-8");
            mySocket.send(new DatagramPacket(bytes, bytes.length, dest, port));
            if (verbose) System.out.println("Sent out: " + outgoing);
        } catch (IOException e) {
            if (verbose) System.err.println("Send failed - network hiccup? " + e.getMessage());
        }
    }

    // Custom encoding with hex prefix
    private String encode(String text) {
        byte[] bytes = text.getBytes();
        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) hex.append(String.format("%02x", b));
        return hex.length() + "#" + hex.toString();
    }

    // Decoding from hex format
    private String decode(String coded) {
        try {
            String[] parts = coded.split("#", 2);
            if (parts.length != 2) return null;
            int len = Integer.parseInt(parts[0]);
            String hex = parts[1];
            if (hex.length() != len) return null;
            byte[] bytes = new byte[len / 2];
            for (int i = 0; i < len; i += 2) {
                bytes[i / 2] = (byte) Integer.parseInt(hex.substring(i, i + 2), 16);
            }
            return new String(bytes);
        } catch (Exception e) {
            return null;
        }
    }

    // Splitting a key-value pair
    private String[] splitPair(String input) {
        String[] parts = input.split("\\s+");
        return parts.length >= 2 ? new String[]{decode(parts[0]), decode(parts[1])} : null;
    }

    // Updating peer list from key-value pairs
    private void updatePeers(String key, String value) {
        try {
            String[] addr = value.split(":");
            if (addr.length == 2) {
                peerList.put(key, new InetSocketAddress(addr[0], Integer.parseInt(addr[1])));
            }
        } catch (Exception e) {
            if (verbose) System.err.println("Couldn’t parse peer address: " + value);
        }
    }

    // Responding with nearest peers
    private void sendNearestPeers(InetAddress target, int port, String id, String hash) {
        List<Map.Entry<String, InetSocketAddress>> peers = new ArrayList<>(peerList.entrySet());
        peers.removeIf(e -> !e.getKey().startsWith("N:"));
        peers.sort(Comparator.comparingInt(e -> measureDistance(hash, hashKey(e.getKey()))));

        StringBuilder reply = new StringBuilder(id + " O");
        for (int i = 0; i < Math.min(3, peers.size()); i++) {
            String name = peers.get(i).getKey();
            InetSocketAddress addr = peers.get(i).getValue();
            reply.append(" ").append(encode(name)).append(" ").append(encode(addr.getHostString() + ":" + addr.getPort()));
        }
        send(target, port, reply.toString());
    }

    // Checking if a node is active
    @Override
    public boolean isActive(String nodeName) {
        return peerList.containsKey(nodeName);
    }

    // Adding a relay node
    @Override
    public void pushRelay(String nodeName) {
        relayChain.addLast(nodeName); // Using a queue instead of stack
        if (verbose) System.out.println("Added relay: " + nodeName);
    }

    // Removing a relay node
    @Override
    public void popRelay() {
        if (!relayChain.isEmpty()) {
            relayChain.removeLast(); // Pop from end of queue
            if (verbose) System.out.println("Popped a relay off the chain");
        }
    }

    // Checking if a key exists in the network
    @Override
    public boolean exists(String key) throws Exception {
        String result = exploreNetwork(key, true);
        return "YES".equals(result);
    }

    // Reading a key from the network
    @Override
    public String read(String key) throws Exception {
        String result = exploreNetwork(key, false);
        return "YES".equals(result) ? null : result; // For LocalTest compatibility
    }

    // Starting the background listener
    private void launchListener() {
        packetWatcher = new Thread(() -> {
            while (true) {
                try {
                    handleIncomingMessages(0);
                } catch (Exception e) {
                    if (verbose) System.err.println("Listener hit a snag: " + e.getMessage());
                }
            }
        });
        packetWatcher.setDaemon(true);
        packetWatcher.start();
        if (verbose) System.out.println("Listener thread is up and running!");
    }

    // Generating a random transaction ID
    private String makeId() {
        return String.format("%03d", chaos.nextInt(1000));
    }

    // Exploring the network for a key
    private String exploreNetwork(String key, boolean justCheck) throws Exception {
        if (storage.containsKey(key)) return storage.get(key); // Quick local check

        String keyHash = hashKey(key);
        Set<String> visited = new HashSet<>();
        List<String> toExplore = new ArrayList<>(peerList.keySet());

        // Bootstrap if I don’t know anyone
        if (toExplore.isEmpty()) {
            InetSocketAddress azure = new InetSocketAddress("10.200.51.19", 20114);
            peerList.put("N:azure", azure);
            toExplore.add("N:azure");
            if (verbose) System.out.println("Bootstrapping with N:azure");
        }

        Iterator<String> peers = toExplore.iterator();
        while (peers.hasNext()) {
            String peer = peers.next();
            if (visited.contains(peer) || !peerList.containsKey(peer)) continue;
            visited.add(peer);

            InetSocketAddress peerAddr = peerList.get(peer);
            String txId = makeId();

            if (justCheck) {
                lastCheck = false;
                send(peerAddr.getAddress(), peerAddr.getPort(), txId + " E " + encode(key));
            } else {
                latestRead = null;
                send(peerAddr.getAddress(), peerAddr.getPort(), txId + " R " + encode(key));
            }

            long deadline = System.currentTimeMillis() + 900; // Slightly different timeout
            while (System.currentTimeMillis() < deadline) {
                handleIncomingMessages(75);
                if (justCheck && lastCheck) return "YES";
                if (!justCheck && latestRead != null) return latestRead;
            }

            String nearId = makeId();
            send(peerAddr.getAddress(), peerAddr.getPort(), nearId + " N " + keyHash);

            long nearDeadline = System.currentTimeMillis() + 900;
            while (!distanceCache.containsKey(nearId) && System.currentTimeMillis() < nearDeadline) {
                handleIncomingMessages(75);
            }

            String nearData = distanceCache.get(nearId);
            if (nearData != null) {
                String[] nodes = nearData.split("\\s+");
                for (int i = 0; i + 1 < nodes.length; i += 2) {
                    String name = decode(nodes[i]);
                    String addrStr = decode(nodes[i + 1]);
                    if (name != null && addrStr != null && name.startsWith("N:") && addrStr.contains(":")) {
                        String[] addrParts = addrStr.split(":");
                        InetSocketAddress newPeer = new InetSocketAddress(addrParts[0], Integer.parseInt(addrParts[1]));
                        peerList.put(name, newPeer);
                        if (!visited.contains(name)) toExplore.add(name);
                    }
                }
            }
        }
        return null;
    }

    // Writing a key-value pair locally
    @Override
    public boolean write(String key, String value) {
        storage.put(key, value);
        if (verbose) System.out.println("Stored " + key + " -> " + value);
        return true;
    }

    // Compare-and-set operation
    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        String existing = storage.get(key);
        if (existing == null) {
            storage.put(key, newValue);
            return true;
        }
        if (existing.equals(currentValue)) {
            storage.put(key, newValue);
            return true;
        }
        return false;
    }

    // Hashing a key with SHA-1 instead of SHA-256
    private String hashKey(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] digest = md.digest(input.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : digest) hex.append(String.format("%02x", b));
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            return String.valueOf(input.hashCode()); // Fallback
        }
    }

    // Measuring distance between hashes
    private int measureDistance(String hashA, String hashB) {
        int dist = 256;
        for (int i = 0; i < Math.min(hashA.length(), hashB.length()); i++) {
            dist += Integer.bitCount(hashA.charAt(i) ^ hashB.charAt(i));
        }
        return dist;
    }
}