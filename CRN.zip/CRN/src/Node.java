import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

interface NodeInterface {

    // Configure the node
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;

    // Handle incoming messages with a timeout
    public void handleIncomingMessages(int delay) throws Exception;

    // Check if a node is active
    public boolean isActive(String nodeName) throws Exception;

    // Relay message functions
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;

    // CRN-25 network functionality
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new HashMap<>();
    private Stack<String> relayStack = new Stack<>();

    // Set the node name
    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
    }

    // Open a UDP socket on the specified port
    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
    }

    // Handle incoming messages for a specified timeout delay
    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);  // Set socket timeout
        byte[] buffer = new byte[1024];  // Buffer to store incoming data
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);  // Wait for an incoming packet
            String message = new String(packet.getData(), 0, packet.getLength());  // Convert byte array to string
            processMessage(message, packet.getAddress(), packet.getPort());  // Process the received message
        } catch (SocketTimeoutException ignored) {
            // Timeout, no message received
        }
    }

    // Process incoming messages based on command type
    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        String command = parts[0];
        String response = "ERROR";  // Default response in case of errors

        switch (command) {
            case "EXISTS":
                if (parts.length > 1) {
                    response = Boolean.toString(dataStore.containsKey(parts[1]));  // Check if key exists
                }
                break;
            case "READ":
                if (parts.length > 1) {
                    response = dataStore.getOrDefault(parts[1], "NULL");  // Read the value for the given key
                    if ("NULL".equals(response)) {
                        // If key not found locally, try querying nearest node
                        String nearestNodeResponse = queryNearestNode(parts[1]);
                        if (!"NULL".equals(nearestNodeResponse)) {
                            response = nearestNodeResponse;
                        }
                    }
                }
                break;
            case "WRITE":
                String[] keyValue = (parts.length > 1) ? parts[1].split(" ", 2) : new String[0];
                if (keyValue.length == 2) {
                    dataStore.put(keyValue[0], keyValue[1]);  // Write the key-value pair
                    response = "OK";
                }
                break;
            case "CAS":
                String[] casParts = (parts.length > 1) ? parts[1].split(" ", 3) : new String[0];
                if (casParts.length == 3 && dataStore.containsKey(casParts[0])) {
                    if (dataStore.get(casParts[0]).equals(casParts[1])) {
                        dataStore.put(casParts[0], casParts[2]);  // Perform CAS (Compare-And-Swap)
                        response = "OK";
                    } else {
                        response = "FAIL";
                    }
                }
                break;
        }
        sendResponse(response, sender, senderPort);  // Send the response back to the sender
    }

    // Send response back to the sender node
    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    // Query the nearest node if the key is not found locally
    private String queryNearestNode(String key) throws Exception {
        // Here we simulate querying the nearest node. This should be replaced by actual network discovery logic.
        String nearestResponse = getNearestNode(key);  // Simulate finding nearest node

        if (nearestResponse.equals("NULL")) {
            return nearestResponse;  // No nearest node available
        }

        // Now query the nearest node for the actual data
        String[] nearestNodeData = nearestResponse.split(" ", 2);
        String nearestNode = nearestNodeData[0];  // Assuming nearest node is returned in the response
        return sendReadRequest(nearestNode, key);  // Send a READ request to the nearest node
    }

    // Simulate getting the nearest node for a given key
    private String getNearestNode(String key) {
        return "NodeA 192.168.1.1:1234";  // Example of a simulated nearest node (should query the actual network)
    }

    // Send a READ request to a nearest node
    private String sendReadRequest(String nearestNode, String key) throws Exception {
        String message = "READ " + key;
        InetAddress nodeAddress = InetAddress.getByName(nearestNode.split(" ")[1].split(":")[0]);
        int nodePort = Integer.parseInt(nearestNode.split(" ")[1].split(":")[1]);

        DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), nodeAddress, nodePort);
        socket.send(packet);

        // Receive the response from the nearest node
        byte[] buffer = new byte[1024];
        DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
        socket.receive(responsePacket);

        return new String(responsePacket.getData(), 0, responsePacket.getLength());
    }

    // Check if the node is active (you can implement ping or heartbeat functionality here)
    public boolean isActive(String nodeName) throws Exception {
        return true;  // For simplicity, assume the node is always active
    }

    // Push a node to the relay stack (used for message relaying)
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    // Pop a node from the relay stack
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    // Check if the given key exists in the datastore
    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    // Read the value for a given key from the datastore
    public String read(String key) throws Exception {
        return dataStore.getOrDefault(key, null);
    }

    // Write a key-value pair to the datastore
    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;
    }

    // Perform a Compare-And-Swap (CAS) operation for the given key
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }
}
