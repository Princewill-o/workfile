import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private boolean isPoemNode = false;
    private static final Logger logger = Logger.getLogger(Node.class.getName());

    static {
        logger.setLevel(Level.WARNING); // Only log warnings and errors by default
    }

    @Override
    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName));
        if (Arrays.asList("rose", "magenta", "chartreuse").contains(nodeName)) {
            isPoemNode = true;
        }
        logger.info(nodeName + ": Node name set to " + this.nodeName);
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        logger.info(nodeName + ": Port opened on " + this.portNumber);
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay);

        if (isPoemNode) {
            logger.info("Waiting for another node to get in contact");
        }

        while (true) {
            try {
                socket.receive(packet); // Block until a message is received
                String message = new String(packet.getData(), 0, packet.getLength());
                logger.info("Received message: " + message + " from " + packet.getAddress() + ":" + packet.getPort());
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                if (delay != 0) break;
            } catch (Exception e) {
                logger.severe("Error processing message: " + e.getMessage());
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        if (parts.length < 2) return;
        String transactionId = parts[0];
        String payload = parts[1];

        if (payload.startsWith("G")) {
            sendResponse(transactionId + " H " + nodeName, senderAddress, senderPort);
        } else if (payload.startsWith("R")) {
            handleReadRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("W")) {
            handleWriteRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("C")) {
            handleCASRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("O")) {
            handleNearestNodeRequest(transactionId, senderAddress, senderPort);
        }
    }

    private void handleReadRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " S ";
        if (dataStore.containsKey(key)) {
            response += "Y " + dataStore.get(key);
        } else {
            // If the data is not on this node, handle the 'O' (nearest node request)
            response += "?";
            sendResponse(transactionId + " O " + nodeName, senderAddress, senderPort);  // Forward the request to nearest node
        }
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleNearestNodeRequest(String transactionId, InetAddress senderAddress, int senderPort) throws Exception {
        // Respond with the nearest node (In practice, you need to determine which node is nearest)
        String response = transactionId + " O ";
        // Example: We're assuming the nearest node is this node itself for simplicity
        response += nodeName + " " + "10.216.34.91:20111"; // Example address of the nearest node
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(transactionId + " X N", senderAddress, senderPort);
            return;
        }

        String key = parts[0];
        String value = parts[1];

        dataStore.put(key, value);
        sendResponse(transactionId + " X R", senderAddress, senderPort);
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(transactionId + " D N", senderAddress, senderPort);
            return;
        }

        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];

        boolean success = CAS(key, currentValue, newValue);
        String response = success ? "D R" : "D N";
        sendResponse(transactionId + " " + response, senderAddress, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        DatagramPacket packet = new DatagramPacket(response.getBytes(), response.length(), address, port);
        socket.send(packet);
    }

    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) {
        return dataStore.get(key);
    }

    @Override
    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        if (dataStore.getOrDefault(key, "").equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    @Override
    public void pushRelay(String nodeName) {
        // Implement the relay logic if necessary
    }

    @Override
    public void popRelay() {
        // Implement the relay removal logic if necessary
    }

    // Method to send test messages for debugging
    private void sendTestMessage() {
        try {
            String testMessage = "Test message from " + nodeName;
            InetAddress targetAddress = InetAddress.getByName("10.216.34.91"); // Replace with another node's IP
            int targetPort = 20111;  // Replace with the target node's port

            DatagramPacket packet = new DatagramPacket(testMessage.getBytes(), testMessage.length(), targetAddress, targetPort);
            socket.send(packet);

            logger.info("Sent test message to " + targetAddress + ":" + targetPort);
        } catch (Exception e) {
            logger.severe("Error sending test message: " + e.getMessage());
        }
    }

    // Method for Poem node to print the poem
    private static String getPoem() {
        return "'Twas brillig, and the slithy toves\n" +
                "Did gyre and gimble in the wabe:\n" +
                "All mimsy were the borogoves,\n" +
                "And the mome raths outgrabe.\n\n" +
                "\"Beware the Jabberwock, my son!\n" +
                "The jaws that bite, the claws that catch!\"\n" +
                "Poem by Lewis Carroll";
    }
}
