import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import java.net.*;
import java.util.*;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new HashMap<>();
    private Stack<String> relayStack = new Stack<>();
    private List<String> knownNodes = new ArrayList<>();

    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        System.out.println("Node set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
        System.out.println("Node " + nodeName + " listening on port " + port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Received: " + message + " from " + packet.getAddress());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException e) {
            System.out.println("No message received within timeout period.");
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        String command = parts[0];
        String response = "ERROR";

        switch (command) {
            case "EXISTS":
                response = (parts.length > 1) ? Boolean.toString(dataStore.containsKey(parts[1])) : "ERROR";
                break;
            case "READ":
                if (parts.length > 1) {
                    response = dataStore.getOrDefault(parts[1], "NULL");
                    if ("NULL".equals(response)) {
                        System.out.println("Key not found locally, checking nearest node...");
                        response = queryNearestNode(parts[1]);
                    }
                }
                break;
            case "WRITE":
                if (parts.length > 1) {
                    String[] keyValue = parts[1].split(" ", 2);
                    if (keyValue.length == 2) {
                        dataStore.put(keyValue[0], keyValue[1]);
                        response = "OK";
                    }
                }
                break;
            case "CAS":
                if (parts.length > 1) {
                    String[] casParts = parts[1].split(" ", 3);
                    if (casParts.length == 3 && dataStore.containsKey(casParts[0])) {
                        if (dataStore.get(casParts[0]).equals(casParts[1])) {
                            dataStore.put(casParts[0], casParts[2]);
                            response = "OK";
                        } else {
                            response = "FAIL";
                        }
                    }
                }
                break;
        }
        sendResponse(response, sender, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    private String queryNearestNode(String key) throws Exception {
        if (knownNodes.isEmpty()) {
            System.out.println("No known nodes to query.");
            return "NULL";
        }

        for (String node : knownNodes) {
            String response = sendReadRequest(node, key);
            if (!"NULL".equals(response)) {
                return response;
            }
        }
        return "NULL";
    }

    private String sendReadRequest(String nearestNode, String key) throws Exception {
        try {
            String message = "READ " + key;
            String[] nodeData = nearestNode.split(":");
            InetAddress nodeAddress = InetAddress.getByName(nodeData[0]);
            int nodePort = Integer.parseInt(nodeData[1]);

            DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), nodeAddress, nodePort);
            socket.send(packet);

            byte[] buffer = new byte[1024];
            DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(responsePacket);

            return new String(responsePacket.getData(), 0, responsePacket.getLength());
        } catch (Exception e) {
            System.out.println("Error contacting node " + nearestNode + ": " + e.getMessage());
            return "NULL";
        }
    }

    public boolean isActive(String nodeName) throws Exception {
        return knownNodes.contains(nodeName);
    }

    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    public String read(String key) throws Exception {
        return dataStore.getOrDefault(key, "NULL");
    }

    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    public void addKnownNode(String nodeAddress) {
        if (!knownNodes.contains(nodeAddress)) {
            knownNodes.add(nodeAddress);
        }
    }

    public static void main(String[] args) throws Exception {
        Node node = new Node();
        node.setNodeName("Node1");
        node.openPort(1234);
        node.addKnownNode("192.168.1.2:5678"); // Example node
        node.write("poem_verse", "This is a test verse.");
        System.out.println("Node is running...");

        while (true) {
            node.handleIncomingMessages(5000);
        }
    }
}

