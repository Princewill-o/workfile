import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>(); // "N:name" -> "ip:port"
    private Map<String, byte[]> nodeHashes = new HashMap<>(); // "N:name" -> hashID
    private Map<String, Integer> pendingRequests = new HashMap<>(); // "tid R key" -> retries
    private List<String> nodeList = new ArrayList<>();
    private boolean hasPrintedWaiting = false;

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.trim().isEmpty()) {
            throw new Exception("Node name must not be null or empty");
        }
        this.nodeName = nodeName;
        String nodeKey = formatString(nodeName);
        byte[] hash = calculateHashID(nodeKey);
        nodeHashes.put(nodeKey, hash);
        dataStore.put(nodeKey, "");
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 20110 || portNumber > 20130) {
            throw new Exception("Port must be between 20110 and 20130 per CRN spec");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        String nodeKey = formatString(nodeName);
        String addr = formatString(InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
        dataStore.put(nodeKey, addr);
        addressStore.put(nodeName, InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
        // Broadcast presence to known Azure lab range
        broadcastAddress(nodeKey, addr);
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay > 0 ? delay : 100);

        if (!hasPrintedWaiting) {
            System.out.println("Waiting for another node to get in contact");
            hasPrintedWaiting = true;
        }

        long startTime = System.currentTimeMillis();
        while (delay == 0 || System.currentTimeMillis() - startTime < delay) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                retryPendingRequests();
                if (delay > 0 && System.currentTimeMillis() - startTime >= delay) break;
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 3);
        if (parts.length < 2) return;
        String tid = parts[0] + " " + parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (parts[1]) {
            case "W":
                handleWriteRequest(tid, payload, senderAddress, senderPort);
                break;
            case "G":
                sendResponse(tid + "H " + formatString(nodeName), senderAddress, senderPort);
                break;
            case "N":
                handleNearestRequest(tid, payload, senderAddress, senderPort);
                break;
            case "V":
                handleRelayRequest(tid, payload, senderAddress, senderPort);
                break;
            case "R":
                handleReadRequest(tid, payload, senderAddress, senderPort);
                break;
            case "S":
                handleReadResponse(tid, payload);
                break;
            case "C":
                handleCASRequest(tid, payload, senderAddress, senderPort);
                break;
            case "E":
                handleExistsRequest(tid, payload, senderAddress, senderPort);
                break;
            case "I":
                break; // Ignore info messages as per RFC
        }
    }

    private void broadcastAddress(String key, String value) throws Exception {
        String msg = formatTid() + "W " + key + value;
        // Broadcast to Azure lab subnet (10.200.51.0/24)
        for (int i = 1; i <= 255; i++) {
            try {
                InetAddress addr = InetAddress.getByName("10.200.51." + i);
                for (int port = 20110; port <= 20130; port++) {
                    sendResponse(msg, addr, port);
                }
            } catch (Exception e) {
                // Skip unreachable addresses
            }
        }
        for (String addr : addressStore.values()) {
            String[] parts = addr.split(":");
            sendResponse(msg, InetAddress.getByName(parts[0]), Integer.parseInt(parts[1]));
        }
    }

    private void handleNearestRequest(String tid, String hashStr, InetAddress senderAddress, int senderPort) throws Exception {
        String nearest = findNearestNode(hashStr);
        String addr = dataStore.get(nearest);
        String response = tid + "O " + nearest + (addr != null ? addr : formatString(""));
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleRelayRequest(String tid, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) return;
        String targetNode = parts[0];
        String innerMsg = parts[1];
        String addr = addressStore.get(parseString(targetNode));
        if (addr != null) {
            String[] addrParts = addr.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(innerMsg, ip, port);
            relayStack.push(targetNode);
        }
    }

    private void handleReadRequest(String tid, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String fullKey = formatString(key);
        boolean hasKey = dataStore.containsKey(fullKey);
        boolean isClosest = isAmongClosest(fullKey);
        String reply = tid + "S ";
        if (hasKey) {
            reply += "Y " + dataStore.get(fullKey);
        } else if (isClosest) {
            reply += "N " + formatString("");
        } else {
            reply += "? " + formatString("");
        }
        sendResponse(reply, senderAddress, senderPort);
    }

    private void handleWriteRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(tid + "X " + formatString("N"), senderAddress, senderPort);
            return;
        }
        String key = formatString(parts[0]);
        String value = parts[1];
        boolean hasKey = dataStore.containsKey(key);
        boolean isClosest = isAmongClosest(key);
        if (hasKey) {
            dataStore.put(key, value);
            sendResponse(tid + "X " + formatString("R"), senderAddress, senderPort);
        } else if (isClosest) {
            dataStore.put(key, value);
            sendResponse(tid + "X " + formatString("A"), senderAddress, senderPort);
            if (parts[0].startsWith("N:")) {
                addressStore.put(parseString(parts[0]), parseString(value));
                nodeList.add(parseString(value));
            }
        } else {
            sendResponse(tid + "X " + formatString("X"), senderAddress, senderPort);
            String nearest = findNearestNode(bytesToHex(calculateHashID(key)));
            String addr = addressStore.get(parseString(nearest));
            if (addr != null) {
                String[] addrParts = addr.split(":");
                sendResponse(tid + "W " + key + value, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
            }
        }
    }

    private void handleCASRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(tid + "D " + formatString("N"), senderAddress, senderPort);
            return;
        }
        String key = formatString(parts[0]);
        String oldValue = parts[1];
        String newValue = parts[2];
        boolean hasKey = dataStore.containsKey(key);
        boolean isClosest = isAmongClosest(key);
        if (hasKey && dataStore.get(key).equals(oldValue)) {
            dataStore.put(key, newValue);
            sendResponse(tid + "D " + formatString("R"), senderAddress, senderPort);
        } else if (hasKey) {
            sendResponse(tid + "D " + formatString("N"), senderAddress, senderPort);
        } else if (isClosest) {
            dataStore.put(key, newValue);
            sendResponse(tid + "D " + formatString("A"), senderAddress, senderPort);
        } else {
            sendResponse(tid + "D " + formatString("X"), senderAddress, senderPort);
        }
    }

    private void handleReadResponse(String tid, String payload) {
        String[] parts = payload.split(" ", 2);
        if (parts.length > 1 && parts[0].equals("Y")) {
            String[] requestParts = pendingRequests.keySet().stream()
                    .filter(k -> k.startsWith(tid))
                    .findFirst().orElse("").split(" ", 4);
            if (requestParts.length >= 4) {
                String key = requestParts[2] + " " + requestParts[3];
                dataStore.put(key, parts[1]);
                pendingRequests.remove(tid + "R " + key);
            }
        }
    }

    private void handleExistsRequest(String tid, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String fullKey = formatString(key);
        boolean hasKey = dataStore.containsKey(fullKey);
        boolean isClosest = isAmongClosest(fullKey);
        String response = tid + "F " + (hasKey ? "Y" : isClosest ? "N" : "?");
        sendResponse(response, senderAddress, senderPort);
    }

    private void sendResponse(String response, InetAddress targetAddress, int targetPort) throws Exception {
        byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(responseBytes, responseBytes.length, targetAddress, targetPort);
        socket.send(packet);
    }

    private void retryPendingRequests() throws Exception {
        for (Map.Entry<String, Integer> entry : new HashMap<>(pendingRequests).entrySet()) {
            if (entry.getValue() < 3) {
                String[] parts = entry.getKey().split(" ", 2);
                String addr = addressStore.values().stream().findFirst().orElse(null);
                if (addr != null) {
                    String[] addrParts = addr.split(":");
                    sendResponse(parts[0] + parts[1], InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
                    pendingRequests.put(entry.getKey(), entry.getValue() + 1);
                } else {
                    broadcastRequest(parts[0] + parts[1]);
                }
            } else {
                pendingRequests.remove(entry.getKey());
            }
        }
    }

    private byte[] calculateHashID(String input) throws Exception {
        MessageDigest hashGenerator = MessageDigest.getInstance("SHA-256");
        return hashGenerator.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private int computeDistance(byte[] h1, byte[] h2) {
        if (h1 == null || h2 == null) return 256;
        int matchingBits = 0;
        for (int i = 0; i < h1.length; i++) {
            int xor = (h1[i] ^ h2[i]) & 0xFF;
            if (xor == 0) {
                matchingBits += 8;
            } else {
                matchingBits += Integer.numberOfLeadingZeros(xor) - 24;
                break;
            }
        }
        return 256 - matchingBits;
    }

    private String findNearestNode(String hashStr) throws Exception {
        byte[] targetHash = hexToBytes(hashStr);
        String nearest = formatString(nodeName);
        byte[] nearestHash = nodeHashes.get(nearest);
        if (nearestHash == null) return nearest;
        int minDistance = computeDistance(targetHash, nearestHash);
        for (String key : nodeHashes.keySet()) {
            if (key.startsWith(formatString("N:").substring(0, 2))) {
                byte[] keyHash = nodeHashes.get(key);
                if (keyHash != null) {
                    int dist = computeDistance(targetHash, keyHash);
                    if (dist < minDistance) {
                        minDistance = dist;
                        nearest = key;
                    }
                }
            }
        }
        return nearest;
    }

    private byte[] hexToBytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i + 1), 16));
        }
        return bytes;
    }

    private boolean isAmongClosest(String key) throws Exception {
        byte[] keyHash = calculateHashID(key);
        byte[] selfHash = nodeHashes.get(formatString(nodeName));
        if (selfHash == null) return true;
        int myDistance = computeDistance(keyHash, selfHash);
        List<Integer> distances = new ArrayList<>();
        for (String nodeKey : nodeHashes.keySet()) {
            if (nodeKey.startsWith(formatString("N:").substring(0, 2)) &&
                    !nodeKey.equals(formatString(nodeName))) {
                byte[] nodeHash = nodeHashes.get(nodeKey);
                if (nodeHash != null) {
                    distances.add(computeDistance(keyHash, nodeHash));
                }
            }
        }
        distances.sort(Integer::compareTo);
        return distances.size() < 3 || myDistance <= distances.get(Math.min(2, distances.size() - 1));
    }

    private String formatString(String s) {
        int spaces = (int)s.chars().filter(ch -> ch == ' ').count();
        return spaces + " " + s + " ";
    }

    private String parseString(String s) {
        String[] parts = s.split(" ", 2);
        return parts[1].substring(0, parts[1].length() - 1);
    }

    private String formatTid() {
        return String.format("%02x%02x ", (byte)(Math.random() * 255), (byte)(Math.random() * 255));
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public boolean exists(String key) throws Exception {
        String fullKey = formatString(key);
        if (dataStore.containsKey(fullKey)) return true;

        String tid = formatTid();
        String request = tid + "E " + fullKey;
        broadcastRequest(request);
        Thread.sleep(1000);
        return dataStore.containsKey(fullKey);
    }

    @Override
    public String read(String key) throws Exception {
        String fullKey = formatString(key);
        if (dataStore.containsKey(fullKey)) {
            return parseString(dataStore.get(fullKey));
        }

        String tid = formatTid();
        String request = tid + "R " + fullKey;
        broadcastRequest(request);
        Thread.sleep(2000); // Wait longer for Azure lab response
        return dataStore.containsKey(fullKey) ? parseString(dataStore.get(fullKey)) : null;
    }

    @Override
    public boolean write(String key, String value) throws Exception {
        String fullKey = formatString(key);
        String fullValue = formatString(value);
        String tid = formatTid();
        String request = tid + "W " + fullKey + fullValue;

        if (isAmongClosest(fullKey)) {
            dataStore.put(fullKey, fullValue);
            broadcastRequest(request);
        } else {
            String hashStr = bytesToHex(calculateHashID(fullKey));
            String nearest = findNearestNode(hashStr);
            String addr = addressStore.get(parseString(nearest));
            if (addr != null) {
                String[] addrParts = addr.split(":");
                sendResponse(request, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
                pendingRequests.put(request, 0);
            } else {
                broadcastRequest(request);
            }
        }
        Thread.sleep(1000);
        if (key.startsWith("D:")) {
            System.out.println("It works!");
        } else if (key.equals(nodeName)) {
            System.out.println("Letting other nodes know where we are");
            for (String node : nodeList) {
                System.out.println("Node: " + node);
            }
            System.out.println("Handling incoming connections");
        }
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        String fullKey = formatString(key);
        String fullCurrent = formatString(currentValue);
        String fullNew = formatString(newValue);
        String tid = formatTid();
        String request = tid + "C " + fullKey + fullCurrent + fullNew;

        broadcastRequest(request);
        Thread.sleep(1000);
        return dataStore.getOrDefault(fullKey, "").equals(fullNew);
    }

    @Override
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(formatString(nodeName));
    }

    @Override
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    private void broadcastRequest(String request) throws Exception {
        String hashStr = bytesToHex(calculateHashID(request.split(" ", 4)[2] + " " + request.split(" ", 4)[3]));
        String nearest = findNearestNode(hashStr);
        String addr = addressStore.get(parseString(nearest));
        if (addr != null) {
            String[] addrParts = addr.split(":");
            sendResponse(request, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
            pendingRequests.put(request, 0);
        }
        // Broadcast to Azure lab subnet
        for (int i = 1; i <= 255; i++) {
            try {
                InetAddress ip = InetAddress.getByName("10.200.51." + i);
                for (int port = 20110; port <= 20130; port++) {
                    sendResponse(request, ip, port);
                    pendingRequests.put(request, 0);
                }
            } catch (Exception e) {
                // Skip unreachable addresses
            }
        }
    }
}