import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new ConcurrentHashMap<>();
    private Map<String, String> addressStore = new ConcurrentHashMap<>();
    private Stack<String> relayStack = new Stack<>();
    private Random random = new Random();
    private MessageDigest digest;

    public Node() throws Exception {
        this.digest = MessageDigest.getInstance("SHA-256");
    }

    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        this.addressStore.put(nodeName, "127.0.0.1:" + port);
        System.out.println("Node set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
        System.out.println("Node " + nodeName + " listening on port " + port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Received: " + message + " from " + packet.getAddress());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException e) {
            // No message received, continue
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        if (message == null || message.trim().isEmpty()) {
            sendResponse("ERROR Empty message", sender, senderPort);
            return;
        }

        // Handle the asterisk prefix if present
        String processedMessage = message.startsWith("*") ? message.substring(2) : message;

        String[] parts = processedMessage.split(" ", 3);
        if (parts.length < 2) {
            sendResponse("ERROR Malformed request", sender, senderPort);
            return;
        }

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "G":
                handleNameRequest(transactionId, sender, senderPort);
                break;
            case "N":
                handleNearestRequest(transactionId, payload, sender, senderPort);
                break;
            case "E":
                handleExistsRequest(transactionId, payload, sender, senderPort);
                break;
            case "R":
                handleReadRequest(transactionId, payload, sender, senderPort);
                break;
            case "W":
                handleWriteRequest(transactionId, payload, sender, senderPort);
                break;
            case "C":
                handleCASRequest(transactionId, payload, sender, senderPort);
                break;
            case "V":
                handleRelayRequest(transactionId, payload, sender, senderPort);
                break;
            default:
                sendResponse(transactionId + " ERROR Unknown command", sender, senderPort);
                break;
        }
    }

    private void handleNameRequest(String transactionId, InetAddress sender, int senderPort) throws Exception {
        sendResponse(transactionId + " H " + nodeName, sender, senderPort);
    }

    private void handleNearestRequest(String transactionId, String hashID, InetAddress sender, int senderPort) throws Exception {
        List<Map.Entry<String, String>> closestNodes = findClosestNodes(hashID, 3);
        StringBuilder response = new StringBuilder(transactionId + " O");
        for (Map.Entry<String, String> entry : closestNodes) {
            response.append(" ").append(entry.getKey()).append(" ").append(entry.getValue());
        }
        sendResponse(response.toString(), sender, senderPort);
    }

    private List<Map.Entry<String, String>> findClosestNodes(String targetHash, int count) {
        // Simplified - should implement proper distance calculation
        List<Map.Entry<String, String>> nodes = new ArrayList<>(addressStore.entrySet());
        Collections.shuffle(nodes);
        return nodes.subList(0, Math.min(count, nodes.size()));
    }

    private void handleExistsRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        char responseChar;
        if (dataStore.containsKey(key) || addressStore.containsKey(key)) {
            responseChar = 'Y';
        } else if (isClosestNode(key)) {
            responseChar = 'N';
        } else {
            responseChar = '?';
        }
        sendResponse(transactionId + " F " + responseChar, sender, senderPort);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        String value;
        if (dataStore.containsKey(key)) {
            value = dataStore.get(key);
            sendResponse(transactionId + " S Y " + value, sender, senderPort);
        } else if (addressStore.containsKey(key)) {
            value = addressStore.get(key);
            sendResponse(transactionId + " S Y " + value, sender, senderPort);
        } else if (isClosestNode(key)) {
            sendResponse(transactionId + " S N ", sender, senderPort);
        } else {
            value = queryNearestNode(key);
            if (!"NULL".equals(value)) {
                sendResponse(transactionId + " S Y " + value, sender, senderPort);
            } else {
                sendResponse(transactionId + " S ? ", sender, senderPort);
            }
        }
    }

    private String queryNearestNode(String key) throws Exception {
        for (String nodeAddress : addressStore.values()) {
            String[] addressParts = nodeAddress.split(":");
            InetAddress address = InetAddress.getByName(addressParts[0]);
            int port = Integer.parseInt(addressParts[1]);

            String transactionId = generateTransactionId();
            String request = transactionId + " R " + key;

            byte[] data = request.getBytes();
            DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
            socket.send(packet);

            byte[] buffer = new byte[1024];
            DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
            socket.setSoTimeout(5000);
            try {
                socket.receive(responsePacket);
                String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
                String[] responseParts = response.split(" ", 4);
                if (responseParts.length >= 4 && responseParts[2].equals("Y")) {
                    return responseParts[3];
                }
            } catch (SocketTimeoutException e) {
                System.out.println("Timeout querying node: " + nodeAddress);
            }
        }
        return "NULL";
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " X X", sender, senderPort);
            return;
        }

        String key = parts[0];
        String value = parts[1];
        char responseChar;

        if (dataStore.containsKey(key) || addressStore.containsKey(key)) {
            if (key.startsWith("N:")) {
                addressStore.put(key, value);
            } else {
                dataStore.put(key, value);
            }
            responseChar = 'R';
        } else if (isClosestNode(key)) {
            if (key.startsWith("N:")) {
                addressStore.put(key, value);
            } else {
                dataStore.put(key, value);
            }
            responseChar = 'A';
        } else {
            responseChar = 'X';
        }

        sendResponse(transactionId + " X " + responseChar, sender, senderPort);
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length != 3) {
            sendResponse(transactionId + " D X", sender, senderPort);
            return;
        }

        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];
        char responseChar;

        if (dataStore.containsKey(key)) {
            if (dataStore.get(key).equals(currentValue)) {
                dataStore.put(key, newValue);
                responseChar = 'R';
            } else {
                responseChar = 'N';
            }
        } else if (isClosestNode(key)) {
            dataStore.put(key, newValue);
            responseChar = 'A';
        } else {
            responseChar = 'X';
        }

        sendResponse(transactionId + " D " + responseChar, sender, senderPort);
    }

    private void handleRelayRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " ERROR Invalid relay", sender, senderPort);
            return;
        }

        String targetNode = parts[0];
        String relayedMessage = parts[1];

        if (!addressStore.containsKey(targetNode)) {
            sendResponse(transactionId + " ERROR Unknown node", sender, senderPort);
            return;
        }

        String[] addressParts = addressStore.get(targetNode).split(":");
        InetAddress targetAddress = InetAddress.getByName(addressParts[0]);
        int targetPort = Integer.parseInt(addressParts[1]);

        byte[] data = relayedMessage.getBytes();
        DatagramPacket relayPacket = new DatagramPacket(data, data.length, targetAddress, targetPort);
        socket.send(relayPacket);

        byte[] buffer = new byte[1024];
        DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(5000);
        try {
            socket.receive(responsePacket);
            String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
            sendResponse(transactionId + " " + response, sender, senderPort);
        } catch (SocketTimeoutException e) {
            sendResponse(transactionId + " ERROR Timeout", sender, senderPort);
        }
    }

    private boolean isClosestNode(String key) {
        // Simplified - should compare distances with other known nodes
        return true;
    }

    private String generateTransactionId() {
        return String.format("%04x", random.nextInt(65536));
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    // Implement the remaining NodeInterface methods
    public boolean isActive(String nodeName) throws Exception {
        return addressStore.containsKey(nodeName);
    }

    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key) || addressStore.containsKey(key);
    }

    public String read(String key) throws Exception {
        if (dataStore.containsKey(key)) {
            return dataStore.get(key);
        }
        return addressStore.getOrDefault(key, "NULL");
    }

    public boolean write(String key, String value) throws Exception {
        if (key.startsWith("N:")) {
            addressStore.put(key, value);
        } else {
            dataStore.put(key, value);
        }
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    public static void main(String[] args) throws Exception {
        Node node = new Node();
        node.setNodeName("N:node-" + new Random().nextInt(1000));
        node.openPort(20110 + new Random().nextInt(20));

        // Add some initial known nodes if available
        // node.write("N:some-node", "10.200.51.18:20110");

        System.out.println("Node " + node.nodeName + " running on port " + node.port);

        while (true) {
            node.handleIncomingMessages(1000);
            // Periodically perform other network operations if needed
        }
    }
}