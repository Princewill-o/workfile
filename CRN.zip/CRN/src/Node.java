// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
// Princewill Okube
// [Your Student ID]
// Princewill.okube@city.ac.uk

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

// DO NOT EDIT starts
interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}
// DO NOT EDIT ends

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private Map<String, Integer> pendingRequests = new HashMap<>();
    private Set<String> processedTids = new HashSet<>();

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty()) {
            throw new Exception("Node name cannot be null or empty");
        }
        this.nodeName = nodeName;
        String nodeKey = formatString(nodeName);
        byte[] hash = calculateHashID(nodeKey);
        nodeHashes.put(nodeKey, hash);
        dataStore.put(nodeKey, "");
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 20110 || portNumber > 20130) {
            throw new Exception("Port must be between 20110 and 20130");
        }
        try {
            this.socket = new DatagramSocket(portNumber);
            this.portNumber = portNumber;
            socket.setSoTimeout(100); // Short timeout for non-blocking receives
            String nodeKey = formatString(nodeName);
            String addr = formatString(InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
            dataStore.put(nodeKey, addr);
            addressStore.put(nodeName, addr);
            broadcastAddress(nodeKey, addr);
        } catch (SocketException e) {
            throw new Exception("Failed to open port: " + e.getMessage());
        }
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        long startTime = System.currentTimeMillis();

        while (delay == 0 || System.currentTimeMillis() - startTime < delay) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength()).trim();
                String senderAddr = packet.getAddress().getHostAddress() + ":" + packet.getPort();
                if (!addressStore.containsValue(senderAddr)) {
                    addressStore.put("N:" + senderAddr.replace(":", "_"), senderAddr);
                }
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                retryPendingRequests();
                if (delay > 0 && System.currentTimeMillis() - startTime >= delay) break;
            } catch (Exception e) {
                System.err.println("Error in handleIncomingMessages: " + e.getMessage());
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 3);
        if (parts.length < 2) return;
        String tid = parts[0] + " " + parts[1];
        if (processedTids.contains(tid)) return;
        processedTids.add(tid);
        String payload = parts.length > 2 ? parts[2] : "";

        switch (parts[1]) {
            case "W": handleWriteRequest(tid, payload, senderAddress, senderPort); break;
            case "R": handleReadRequest(tid, payload, senderAddress, senderPort); break;
            case "S": handleReadResponse(tid, payload); break;
            case "N": handleNearestRequest(tid, payload, senderAddress, senderPort); break;
            case "O": handleNearestResponse(tid, payload); break;
            case "C": handleCASRequest(tid, payload, senderAddress, senderPort); break;
            case "E": handleExistsRequest(tid, payload, senderAddress, senderPort); break;
            case "G": sendResponse(tid + "H " + formatString(nodeName), senderAddress, senderPort); break;
            case "V": handleRelayRequest(tid, payload, senderAddress, senderPort); break;
            default: sendResponse(tid + "X " + formatString("Unknown command"), senderAddress, senderPort);
        }
    }

    private void handleWriteRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(tid + "X " + formatString("N"), senderAddress, senderPort);
            return;
        }
        String key = formatString(parts[0]);
        String value = parts[1];
        boolean isClosest = isAmongClosest(key);
        if (isClosest) {
            dataStore.put(key, value);
            sendResponse(tid + "X " + formatString("A"), senderAddress, senderPort);
            if (key.startsWith("N:")) {
                addressStore.put(parseString(key), parseString(value));
            }
        } else {
            sendResponse(tid + "X " + formatString("X"), senderAddress, senderPort);
        }
    }

    private void handleReadRequest(String tid, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String fullKey = formatString(key);
        boolean hasKey = dataStore.containsKey(fullKey);
        boolean isClosest = isAmongClosest(fullKey);
        String reply = tid + "S ";
        if (hasKey) reply += "Y " + dataStore.get(fullKey);
        else if (isClosest) reply += "N " + formatString("");
        else {
            String hashStr = bytesToHex(calculateHashID(fullKey));
            handleNearestRequest(tid, hashStr, senderAddress, senderPort);
            return;
        }
        sendResponse(reply, senderAddress, senderPort);
    }

    private void handleReadResponse(String tid, String payload) {
        String[] parts = payload.split(" ", 2);
        if (parts.length > 1 && parts[0].equals("Y")) {
            String[] requestParts = pendingRequests.keySet().stream()
                    .filter(k -> k.startsWith(tid))
                    .findFirst().orElse("").split(" ", 3);
            if (requestParts.length >= 3) {
                String key = requestParts[2];
                dataStore.put(key, parts[1]);
                pendingRequests.remove(tid + "R " + key);
            }
        }
    }

    private void handleNearestRequest(String tid, String hashStr, InetAddress senderAddress, int senderPort) throws Exception {
        List<String> nearestNodes = findNearestNodes(hashStr, 3);
        StringBuilder response = new StringBuilder(tid + "O ");
        for (String node : nearestNodes) {
            String addr = dataStore.get(node);
            response.append(node).append(addr != null ? addr : formatString("")).append(" ");
        }
        sendResponse(response.toString().trim(), senderAddress, senderPort);
    }

    private void handleNearestResponse(String tid, String payload) {
        String[] parts = payload.split(" ");
        if (parts.length < 1) return;
        String request = pendingRequests.keySet().stream()
                .filter(k -> k.startsWith(tid))
                .findFirst().orElse("");
        if (!request.isEmpty() && request.contains("R")) {
            String[] requestParts = request.split(" ", 3);
            String key = requestParts[2];
            for (int i = 0; i < parts.length && i < 3; i++) {
                String nodeKey = parts[i];
                String addr = addressStore.get(parseString(nodeKey));
                if (addr != null) {
                    String[] addrParts = addr.split(":");
                    try {
                        sendResponse(tid + "R " + key, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
                    } catch (Exception e) {
                        System.err.println("Failed to query nearest node: " + e.getMessage());
                    }
                }
            }
        }
    }

    private void handleCASRequest(String tid, String content, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = content.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(tid + "D " + formatString("N"), senderAddress, senderPort);
            return;
        }
        String key = formatString(parts[0]);
        String oldValue = parts[1];
        String newValue = parts[2];
        boolean hasKey = dataStore.containsKey(key);
        boolean isClosest = isAmongClosest(key);
        if (hasKey && dataStore.get(key).equals(oldValue)) {
            dataStore.put(key, newValue);
            sendResponse(tid + "D " + formatString("R"), senderAddress, senderPort);
        } else if (isClosest) {
            sendResponse(tid + "D " + formatString("A"), senderAddress, senderPort);
            dataStore.put(key, newValue);
        } else {
            sendResponse(tid + "D " + formatString("X"), senderAddress, senderPort);
        }
    }

    private void handleExistsRequest(String tid, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String fullKey = formatString(key);
        boolean hasKey = dataStore.containsKey(fullKey);
        boolean isClosest = isAmongClosest(fullKey);
        sendResponse(tid + "F " + (hasKey ? "Y" : isClosest ? "N" : "?"), senderAddress, senderPort);
    }

    private void handleRelayRequest(String tid, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(tid + "S N " + formatString("Invalid relay payload"), senderAddress, senderPort);
            return;
        }
        String targetNode = parts[0];
        String innerMsg = parts[1];
        String addr = addressStore.get(parseString(targetNode));
        if (addr != null) {
            String[] addrParts = addr.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(innerMsg, ip, port);
            relayStack.push(targetNode);
            String innerTid = innerMsg.split(" ")[0] + " " + innerMsg.split(" ")[1];
            String response = innerTid + "S Y " + formatString(dataStore.getOrDefault(innerMsg.split(" ", 3)[2], ""));
            sendResponse(response, senderAddress, senderPort);
        } else {
            sendResponse(tid + "S N " + formatString("Relay target not found"), senderAddress, senderPort);
        }
    }

    private void sendResponse(String response, InetAddress targetAddress, int targetPort) throws Exception {
        if (response == null || response.length() > 1024) return;
        byte[] responseBytes = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(responseBytes, responseBytes.length, targetAddress, targetPort);
        socket.send(packet);
    }

    private void broadcastAddress(String key, String value) throws Exception {
        String msg = formatTid() + "W " + key + value;
        broadcastToSubnet(msg);
    }

    private void retryPendingRequests() throws Exception {
        for (Map.Entry<String, Integer> entry : new HashMap<>(pendingRequests).entrySet()) {
            if (entry.getValue() < 3) {
                broadcastRequest(entry.getKey());
                pendingRequests.put(entry.getKey(), entry.getValue() + 1);
            } else {
                pendingRequests.remove(entry.getKey());
            }
        }
    }

    @Override
    public boolean isActive(String nodeName) throws Exception {
        return this.nodeName != null && this.nodeName.equals(nodeName);
    }

    @Override
    public void pushRelay(String nodeName) throws Exception {
        if (nodeName == null || nodeName.trim().isEmpty()) throw new Exception("Relay node name cannot be null or empty");
        relayStack.push(formatString(nodeName));
    }

    @Override
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) relayStack.pop();
    }

    @Override
    public boolean exists(String key) throws Exception {
        String fullKey = formatString(key);
        if (dataStore.containsKey(fullKey)) return true;
        String tid = formatTid();
        String request = tid + "E " + fullKey;
        broadcastRequest(request);
        Thread.sleep(1000);
        return dataStore.containsKey(fullKey);
    }

    @Override
    public String read(String key) throws Exception {
        String fullKey = formatString(key);
        if (dataStore.containsKey(fullKey)) return parseString(dataStore.get(fullKey));

        String tid = formatTid();
        String request = tid + "R " + fullKey;
        Set<String> queriedNodes = new HashSet<>();
        queriedNodes.add(formatString(nodeName));

        for (int i = 0; i < 3; i++) {
            broadcastRequest(request);
            pendingRequests.put(request, 0);
            Thread.sleep(1000);

            if (dataStore.containsKey(fullKey)) {
                pendingRequests.remove(request);
                return parseString(dataStore.get(fullKey));
            }

            String nextNode = null;
            for (String pending : new HashSet<>(pendingRequests.keySet())) {
                if (pending.startsWith(tid) && pending.contains("O")) {
                    String[] parts = pending.split(" ", 3);
                    if (parts.length == 3) {
                        String[] nearestNodes = parts[2].split(" ");
                        for (String node : nearestNodes) {
                            if (!queriedNodes.contains(node)) {
                                nextNode = node;
                                queriedNodes.add(node);
                                break;
                            }
                        }
                    }
                    pendingRequests.remove(pending);
                }
            }

            if (nextNode != null) {
                String addr = addressStore.get(parseString(nextNode));
                if (addr != null) {
                    String[] addrParts = addr.split(":");
                    sendResponse(request, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
                    Thread.sleep(1000);
                    if (dataStore.containsKey(fullKey)) return parseString(dataStore.get(fullKey));
                }
            }
        }
        return null;
    }

    @Override
    public boolean write(String key, String value) throws Exception {
        String fullKey = formatString(key);
        String fullValue = formatString(value);
        String tid = formatTid();
        String request = tid + "W " + fullKey + fullValue;
        boolean success = false;

        if (isAmongClosest(fullKey)) {
            dataStore.put(fullKey, fullValue);
            broadcastRequest(request);
            success = true;
        } else {
            String hashStr = bytesToHex(calculateHashID(fullKey));
            String nearest = findNearestNode(hashStr);
            String addr = addressStore.get(parseString(nearest));
            if (addr != null) {
                String[] addrParts = addr.split(":");
                sendResponse(request, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
                pendingRequests.put(request, 0);
                success = true;
            } else {
                broadcastRequest(request);
            }
        }
        Thread.sleep(1000);
        return success && dataStore.containsKey(fullKey);
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        String fullKey = formatString(key);
        String fullCurrent = formatString(currentValue);
        String fullNew = formatString(newValue);
        String tid = formatTid();
        String request = tid + "C " + fullKey + fullCurrent + fullNew;
        broadcastRequest(request);
        Thread.sleep(1000);
        return dataStore.getOrDefault(fullKey, "").equals(fullNew);
    }

    private void broadcastRequest(String request) throws Exception {
        String[] parts = request.split(" ", 3);
        if (parts.length < 3) return;
        String hashStr = bytesToHex(calculateHashID(parts[2]));
        String nearest = findNearestNode(hashStr);
        String addr = addressStore.get(parseString(nearest));
        if (addr != null) {
            String[] addrParts = addr.split(":");
            sendResponse(request, InetAddress.getByName(addrParts[0]), Integer.parseInt(addrParts[1]));
            pendingRequests.put(request, 0);
        }
        broadcastToSubnet(request);
    }

    private void broadcastToSubnet(String msg) throws Exception {
        for (int i = 1; i <= 255; i++) {
            try {
                InetAddress ip = InetAddress.getByName("10.200.51." + i);
                for (int port = 20110; port <= 20130; port++) {
                    if (port != portNumber) {
                        sendResponse(msg, ip, port);
                    }
                }
            } catch (UnknownHostException e) {
                // Silent ignore
            }
        }
    }

    private byte[] calculateHashID(String input) throws Exception {
        MessageDigest hashGenerator = MessageDigest.getInstance("SHA-256");
        return hashGenerator.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private int computeDistance(byte[] h1, byte[] h2) {
        if (h1 == null || h2 == null) return 256;
        int matchingBits = 0;
        for (int i = 0; i < h1.length; i++) {
            int xor = (h1[i] ^ h2[i]) & 0xFF;
            if (xor == 0) matchingBits += 8;
            else {
                matchingBits += Integer.numberOfLeadingZeros(xor) - 24;
                break;
            }
        }
        return 256 - matchingBits;
    }

    private String findNearestNode(String hashStr) throws Exception {
        List<String> nearest = findNearestNodes(hashStr, 1);
        return nearest.isEmpty() ? formatString(nodeName) : nearest.get(0);
    }

    private List<String> findNearestNodes(String hashStr, int count) throws Exception {
        byte[] targetHash = hexToBytes(hashStr);
        List<Map.Entry<String, Integer>> distances = new ArrayList<>();
        for (String key : nodeHashes.keySet()) {
            if (key.startsWith(formatString("N:").substring(0, 2)) || key.equals(formatString(nodeName))) {
                byte[] keyHash = nodeHashes.get(key);
                if (keyHash != null) {
                    int dist = computeDistance(targetHash, keyHash);
                    distances.add(new AbstractMap.SimpleEntry<>(key, dist));
                }
            }
        }
        distances.sort(Comparator.comparingInt(Map.Entry::getValue));
        List<String> nearest = new ArrayList<>();
        for (int i = 0; i < Math.min(count, distances.size()); i++) {
            nearest.add(distances.get(i).getKey());
        }
        return nearest;
    }

    private byte[] hexToBytes(String hex) {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length(); i += 2) {
            bytes[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i + 1), 16));
        }
        return bytes;
    }

    private boolean isAmongClosest(String key) throws Exception {
        byte[] keyHash = calculateHashID(key);
        byte[] selfHash = nodeHashes.get(formatString(nodeName));
        if (selfHash == null) return true;
        int myDistance = computeDistance(keyHash, selfHash);
        List<Integer> distances = new ArrayList<>();
        for (String nodeKey : nodeHashes.keySet()) {
            if (nodeKey.startsWith(formatString("N:").substring(0, 2)) && !nodeKey.equals(formatString(nodeName))) {
                byte[] nodeHash = nodeHashes.get(nodeKey);
                if (nodeHash != null) distances.add(computeDistance(keyHash, nodeHash));
            }
        }
        distances.sort(Integer::compareTo);
        return distances.size() < 3 || myDistance <= distances.get(Math.min(2, distances.size() - 1));
    }

    private String formatString(String s) {
        if (s == null) return "";
        return s.replace("\n", "\\n");
    }

    private String parseString(String s) {
        if (s == null || s.trim().isEmpty()) return "";
        return s.replace("\\n", "\n");
    }

    private String formatTid() {
        return String.format("%02x%02x ", (byte)(Math.random() * 255), (byte)(Math.random() * 255));
    }
}