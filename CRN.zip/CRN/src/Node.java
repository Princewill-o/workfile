// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  YOUR_NAME_GOES_HERE
//  YOUR_STUDENT_ID_NUMBER_GOES_HERE
//  YOUR_EMAIL_GOES_HERE

// DO NOT EDIT starts
// This gives the interface that your code must implement.
// These descriptions are intended to help you understand how the interface
// will be used. See the RFC for how the protocol works.

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}
// DO NOT EDIT ends

// Complete this!
public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private boolean isPoemNode = false;
    private static final Logger logger = Logger.getLogger(Node.class.getName());

    @Override
    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName));
        if (Arrays.asList("rose", "magenta", "chartreuse").contains(nodeName)) {
            isPoemNode = true;
        }
        logger.info(nodeName + ": Node name set to " + this.nodeName);
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        logger.info(nodeName + ": Port opened on " + this.portNumber);
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay);

        if (isPoemNode) {
            logger.info("Waiting for another node to get in contact");
        }

        while (true) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                if (delay != 0) break;
            } catch (Exception e) {
                logger.severe("Error processing message: " + e.getMessage());
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        if (parts.length < 2) return;
        String transactionId = parts[0];
        String payload = parts[1];

        if (payload.startsWith("G")) {
            sendResponse(transactionId + " H " + nodeName, senderAddress, senderPort);
        } else if (payload.startsWith("R")) {
            handleReadRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        }
    }

    private void handleReadRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " S ";
        if (dataStore.containsKey(key)) {
            response += "Y " + dataStore.get(key);
            System.out.println(dataStore.get(key));
        } else {
            response += "?";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        DatagramPacket packet = new DatagramPacket(response.getBytes(), response.length(), address, port);
        socket.send(packet);
    }

    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) {
        return dataStore.get(key);
    }

    @Override
    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        if (dataStore.getOrDefault(key, "").equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    @Override
    public void pushRelay(String nodeName) {}

    @Override
    public void popRelay() {}

    // Method for Poem node to print the poem
    private static String getPoem() {
        return "'Twas brillig, and the slithy toves\n" +
                "Did gyre and gimble in the wabe:\n" +
                "All mimsy were the borogoves,\n" +
                "And the mome raths outgrabe.\n\n" +
                "\"Beware the Jabberwock, my son!\n" +
                "The jaws that bite, the claws that catch!\n" +
                "Beware the Jubjub bird, and shun\n" +
                "The frumious Bandersnatch!\"\n\n" +
                "He took his vorpal sword in hand;\n" +
                "Long time the manxome foe he sought-\n" +
                "So rested he by the Tumtum tree\n" +
                "And stood awhile in thought.\n\n" +
                "And, as in uffish thought he stood,\n" +
                "The Jabberwock, with eyes of flame,\n" +
                "Came whiffling through the tulgey wood,\n" +
                "And burbled as it came!\n\n" +
                "One two! One two! And through and through\n" +
                "The vorpal blade went snicker-snack!\n" +
                "He left it dead, and with its head\n" +
                "He went galumphing back.\n\n" +
                "\"And hast thou slain the Jabberwock?\n" +
                "Come to my arms, my beamish boy!\n" +
                "O frabjous day! Callooh! Callay!\"\n" +
                "He chortled in his joy.\n\n" +
                "'Twas brillig, and the slithy toves\n" +
                "Did gyre and gimble in the wabe:\n" +
                "All mimsy were the borogoves,\n" +
                "And the mome raths outgrabe.\n\n" +
                "Poem by Lewis Carroll";
    }
}
