import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private List<String> nodeList = new ArrayList<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private boolean isPoemNode = false;
    private boolean hasPrintedWaiting = false;
    private boolean hasPrintedGettingPoem = false;
    private int markerCount = 0;
    private Random random = new Random(42); // Deterministic for testing
    private Map<String, Integer> transactionRetries = new HashMap<>(); // Track retries
    private Map<String, Long> transactionTimestamps = new HashMap<>(); // Track timeouts
    private Map<String, String> pendingResponses = new HashMap<>(); // Handle out-of-order responses
    private List<String> poemFragments = new ArrayList<>(); // Collect poem verses

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty() || !nodeName.startsWith("N:")) {
            throw new Exception("Node name must start with 'N:' and be non-empty");
        }
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName));
        if (nodeName.equals("N:rose") || nodeName.equals("N:magenta") || nodeName.equals("N:chartreuse")) {
            isPoemNode = true;
        }
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 20110 || portNumber > 20130) {
            throw new Exception("Port number must be between 20110 and 20130 per RFC");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        addressStore.put(nodeName, InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(100);

        if (!hasPrintedWaiting) {
            System.out.println("Waiting for another node to get in contact");
            hasPrintedWaiting = true;
        }

        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < delay * 1000) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                processMessage(message, packet.getAddress(), packet.getPort());

                if (!hasPrintedGettingPoem && poemFragments.size() >= 7) { // Assuming 7 stanzas
                    displayPoem();
                    hasPrintedGettingPoem = true;
                }

                if (markerCount >= 2) {
                    for (String node : nodeList) {
                        System.out.println("Node: " + node);
                    }
                    System.out.println("Handling incoming connections");
                    break;
                }
            } catch (SocketTimeoutException ignored) {
                retransmitPendingRequests();
            }
        }
        fetchPoemFragments(); // Initiate poem collection if not complete
    }

    private void fetchPoemFragments() throws Exception {
        String[] poemKeys = {"D:jabberwocky1", "D:jabberwocky2", "D:jabberwocky3", "D:jabberwocky4",
                "D:jabberwocky5", "D:jabberwocky6", "D:jabberwocky7"};
        for (String key : poemKeys) {
            if (!dataStore.containsKey(key) && poemFragments.size() < 7) {
                String transactionId = generateTransactionId();
                String request = transactionId + " R " + encodeString(key);
                sendToNearestNode(request, key);
                transactionRetries.put(transactionId, 0);
                transactionTimestamps.put(transactionId, System.currentTimeMillis());
            }
        }
    }

    private void retransmitPendingRequests() throws Exception {
        long currentTime = System.currentTimeMillis();
        for (Iterator<Map.Entry<String, Long>> it = transactionTimestamps.entrySet().iterator(); it.hasNext();) {
            Map.Entry<String, Long> entry = it.next();
            String transactionId = entry.getKey();
            long sentTime = entry.getValue();
            int retries = transactionRetries.getOrDefault(transactionId, 0);

            if (currentTime - sentTime > 5000 && retries < 3) { // 5-second timeout, max 3 retries
                String request = pendingResponses.get(transactionId);
                if (request != null) {
                    String[] parts = request.split(" ", 4);
                    String key = decodeString(parts[3]);
                    sendToNearestNode(request, key);
                    transactionRetries.put(transactionId, retries + 1);
                    transactionTimestamps.put(transactionId, currentTime);
                }
            } else if (retries >= 3) {
                it.remove();
                transactionRetries.remove(transactionId);
                pendingResponses.remove(transactionId);
            }
        }
    }

    private void sendToNearestNode(String message, String key) throws Exception {
        List<Map.Entry<String, String>> closestNodes = findClosestNodes(encodeHashID(calculateHashID(key)), 3);
        if (closestNodes.isEmpty() && !addressStore.isEmpty()) {
            closestNodes = new ArrayList<>(addressStore.entrySet());
        }
        if (!closestNodes.isEmpty()) {
            Map.Entry<String, String> node = closestNodes.get(0);
            String[] addrParts = node.getValue().split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(message, ip, port);
            pendingResponses.put(message.split(" ")[0], message);
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        if (message == null || message.length() < 3) return; // Robustness: ignore malformed messages

        String[] parts = message.split(" ", 3);
        if (parts.length < 2) return;

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        // Passive mapping: store sender's address
        String senderAddr = senderAddress.getHostAddress() + ":" + senderPort;
        if (!nodeList.contains(senderAddr)) {
            nodeList.add(senderAddr);
        }

        switch (command) {
            case "G":
                handleNameRequest(transactionId, senderAddress, senderPort);
                break;
            case "N":
                handleNearestRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "E":
                handleKeyExistenceRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "R":
                handleReadRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "W":
                handleWriteRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "C":
                handleCASRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "V":
                handleRelayRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "I":
                break; // Ignore info messages per RFC
            case "H":
            case "O":
            case "F":
            case "S":
            case "X":
            case "D":
                handleResponse(transactionId, command, payload);
                break;
            default:
                break; // Ignore unknown commands
        }
    }

    private void handleResponse(String transactionId, String command, String payload) {
        if (pendingResponses.containsKey(transactionId)) {
            transactionRetries.remove(transactionId);
            transactionTimestamps.remove(transactionId);
            pendingResponses.remove(transactionId);

            if (command.equals("S") && payload.startsWith("Y ")) {
                String value = payload.substring(2);
                String key = decodeString(pendingResponses.get(transactionId).split(" ", 4)[3]);
                if (key.startsWith("D:jabberwocky") && !dataStore.containsKey(key)) {
                    dataStore.put(key, value);
                    poemFragments.add(value);
                }
            }
        }
    }

    private void handleNameRequest(String transactionId, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " H " + encodeString(nodeName);
        sendResponse(response, senderAddress, senderPort);
        addressStore.put(nodeName, senderAddress.getHostAddress() + ":" + senderPort);
    }

    private void handleNearestRequest(String transactionId, String hashID, InetAddress senderAddress, int senderPort) throws Exception {
        List<Map.Entry<String, String>> closestNodes = findClosestNodes(hashID, 3);
        StringBuilder response = new StringBuilder(transactionId + " O ");
        for (Map.Entry<String, String> entry : closestNodes) {
            response.append(encodeString(entry.getKey())).append(" ").append(encodeString(entry.getValue())).append(" ");
        }
        sendResponse(response.toString().trim(), senderAddress, senderPort);
    }

    private void handleKeyExistenceRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String key = decodeString(payload);
        boolean conditionA = dataStore.containsKey(key);
        boolean conditionB = isAmongClosest(key);
        String responseChar = conditionA ? "Y" : (conditionB ? "N" : "?");
        String response = transactionId + " F " + responseChar;
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleReadRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String key = decodeString(payload);
        boolean conditionA = dataStore.containsKey(key);
        boolean conditionB = isAmongClosest(key);
        String response;
        if (conditionA) {
            String value = dataStore.get(key);
            response = transactionId + " S Y " + encodeString(value);
        } else if (conditionB) {
            response = transactionId + " S N";
        } else {
            response = transactionId + " S ?";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 2) {
            sendResponse(transactionId + " X N", senderAddress, senderPort);
            return;
        }
        String key = decodeString(parts[0]);
        String value = decodeString(parts[1]);
        boolean conditionA = dataStore.containsKey(key);
        boolean conditionB = isAmongClosest(key);

        String response;
        if (conditionA) {
            write(key, value);
            response = transactionId + " X R";
        } else if (conditionB) {
            write(key, value);
            response = transactionId + " X A";
        } else {
            response = transactionId + " X X";
        }
        sendResponse(response, senderAddress, senderPort);

        if (key.equals("D:marker")) {
            markerCount++;
            System.out.println("Writing a marker so it's clear my code works");
            System.out.println("It works!");
            System.out.println("Letting other nodes know where we are");
        }
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 4);
        if (parts.length < 3) {
            sendResponse(transactionId + " D N", senderAddress, senderPort);
            return;
        }
        String key = decodeString(parts[0]);
        String currentValue = decodeString(parts[1]);
        String newValue = decodeString(parts[2]);
        boolean conditionA = dataStore.containsKey(key);
        boolean conditionB = isAmongClosest(key);

        String response;
        if (conditionA) {
            boolean success = CAS(key, currentValue, newValue);
            response = transactionId + " D " + (success ? "R" : "N");
        } else if (conditionB) {
            write(key, newValue);
            response = transactionId + " D A";
        } else {
            response = transactionId + " D X";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleRelayRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 2) return;
        String targetNode = decodeString(parts[0]);
        String relayedMessage = parts[1];

        String targetAddress = addressStore.get(targetNode);
        if (targetAddress != null) {
            String[] addrParts = targetAddress.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(relayedMessage, ip, port);

            // If it's a request, wait for response and relay back
            if (relayedMessage.matches(".. [GNERWC].*")) {
                String response = waitForResponse(relayedMessage.split(" ")[0], ip, port);
                if (response != null) {
                    sendResponse(response, senderAddress, senderPort);
                }
            }
        }
    }

    private String waitForResponse(String transactionId, InetAddress targetIp, int targetPort) throws Exception {
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 5000) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                if (message.startsWith(transactionId)) {
                    return message;
                }
            } catch (SocketTimeoutException ignored) {
            }
        }
        return null;
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        if (random.nextDouble() < 0.1) return; // Simulate 10% packet loss for robustness testing
        byte[] data = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    private String encodeHashID(byte[] hash) {
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private List<Map.Entry<String, String>> findClosestNodes(String targetHash, int count) {
        List<Map.Entry<String, String>> nodes = new ArrayList<>(addressStore.entrySet());
        nodes.sort((a, b) -> {
            byte[] hashA = nodeHashes.getOrDefault(a.getKey(), calculateHashIDSafe(a.getKey()));
            byte[] hashB = nodeHashes.getOrDefault(b.getKey(), calculateHashIDSafe(b.getKey()));
            int distA = calculateDistance(targetHash, encodeHashID(hashA));
            int distB = calculateDistance(targetHash, encodeHashID(hashB));
            return Integer.compare(distA, distB);
        });
        return nodes.subList(0, Math.min(count, nodes.size()));
    }

    private byte[] calculateHashIDSafe(String key) {
        try {
            return calculateHashID(key);
        } catch (Exception e) {
            return new byte[32]; // Fallback for robustness
        }
    }

    private int calculateDistance(String hash1, String hash2) {
        int matchingBits = 0;
        for (int i = 0; i < Math.min(hash1.length(), hash2.length()); i++) {
            int diff = Character.digit(hash1.charAt(i), 16) ^ Character.digit(hash2.charAt(i), 16);
            if (diff == 0) matchingBits += 4;
            else {
                matchingBits += Integer.numberOfLeadingZeros(diff) - 28;
                break;
            }
        }
        return 256 - matchingBits;
    }

    private boolean isAmongClosest(String key) {
        byte[] keyHash = calculateHashIDSafe(key);
        String encodedKeyHash = encodeHashID(keyHash);
        List<Map.Entry<String, String>> closest = findClosestNodes(encodedKeyHash, 3);
        return closest.stream().anyMatch(e -> e.getKey().equals(nodeName));
    }

    private String encodeString(String s) {
        int spaceCount = (int) s.chars().filter(ch -> ch == ' ').count();
        return spaceCount + " " + s + " ";
    }

    private String decodeString(String encoded) {
        String[] parts = encoded.split(" ", 3);
        if (parts.length < 3) return "";
        return parts[1];
    }

    private String generateTransactionId() {
        return String.format("%02x", random.nextInt(256)) + String.format("%02x", random.nextInt(256));
    }

    private void displayPoem() {
        System.out.println("Getting the poem ...");
        for (String fragment : poemFragments) {
            String[] lines = fragment.split("\\s+"); // Split on spaces for simplicity
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    System.out.println(line.trim());
                }
            }
            System.out.println(); // Stanza separation
        }
        System.out.println("Poem by Lewis Carroll");
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public void pushRelay(String nodeName) {
        if (nodeName != null && !nodeName.isEmpty()) {
            relayStack.push(nodeName);
        }
    }

    @Override
    public void popRelay() {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) {
        return dataStore.getOrDefault(key, "");
    }

    @Override
    public boolean write(String key, String value) {
        if (key == null || value == null) return false;
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        synchronized (dataStore) {
            String storedValue = dataStore.getOrDefault(key, "");
            if (storedValue.equals(currentValue)) {
                dataStore.put(key, newValue);
                return true;
            }
            return false;
        }
    }
}