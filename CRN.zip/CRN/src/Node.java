// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  [Your Name Goes Here]
//  [Your Student ID Number Goes Here]
//  [Your Email Goes Here]

// Alright, so this is my attempt at building a node for the CRN protocol.
// It’s supposed to chat with other nodes over UDP, grab the Jabberwocky poem,
// and handle some marker stuff. Let’s see how it goes!

// DO NOT EDIT starts
// This is the interface I have to follow. It’s like the rulebook for what my node needs to do.
// The comments here are pretty helpful for figuring out how it’s used—check the RFC for the nitty-gritty details.
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {

    // These two get my node ready to roll.
    // Gotta call them once when I set things up, before anything else happens.

    // Sets the name for my node—like giving it an ID card.
    public void setNodeName(String nodeName) throws Exception;

    // Opens up a UDP port so my node can send and receive messages.
    public void openPort(int portNumber) throws Exception;

    // These are for messing with the network—checking stuff and moving messages around.

    // This one listens for incoming messages. If nothing shows up after "delay" milliseconds, it gives up.
    // If delay’s 0, it’ll wait forever (or until something happens).
    public void handleIncomingMessages(int delay) throws Exception;

    // Checks if another node is alive and responding. Also deals with any messages that pop up.
    public boolean isActive(String nodeName) throws Exception;

    // I’ve got a stack of relay nodes here—like a list of buddies to pass messages through.
    // First one in the stack relays to the next, and so on.

    // Adds a node to my relay stack for sending messages through.
    public void pushRelay(String nodeName) throws Exception;

    // Takes the top node off the relay stack. Does nothing if it’s empty.
    public void popRelay() throws Exception;

    // These are the main tools for working with the CRN network—like reading and writing stuff.

    // Checks if a key exists in the network. Also handles any messages that come in.
    public boolean exists(String key) throws Exception;

    // Grabs the value for a key from the network. Returns null if there’s nothing there.
    // Keeps an eye on incoming messages too.
    public String read(String key) throws Exception;

    // Sets a key to a value in the network. Returns true if it works, false if it flops.
    // Handles messages that show up while it’s at it.
    public boolean write(String key, String value) throws Exception;

    // If a key’s value matches currentValue, swaps it to newValue. True if it works, false if not.
    // Deals with messages too.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Here’s where I build my node! It’s got to do everything the interface says.
public class Node implements NodeInterface {
    private String nodeName; // My node’s name—like "N:alice" or whatever.
    private DatagramSocket socket; // The UDP socket for chatting with other nodes.
    private int portNumber; // The port I’m using (between 20110 and 20130).
    private Stack<String> relayStack = new Stack<>(); // Stack for relay nodes.
    private Map<String, String> dataStore = new HashMap<>(); // Where I keep key/value stuff locally.
    private Map<String, String> addressStore = new HashMap<>(); // Tracks node addresses.
    private List<String> nodeList = new ArrayList<>(); // List of nodes I’ve seen.
    private Map<String, byte[]> nodeHashes = new HashMap<>(); // Hashes for finding close nodes.
    private boolean isPoemNode = false; // Flags if I’m a special poem node (like rose or magenta).
    private boolean hasPrintedWaiting = false; // So I don’t spam "Waiting..." too much.
    private boolean hasPrintedGettingPoem = false; // Keeps "Getting the poem..." to once.
    private int markerCount = 0; // Counts how many markers I’ve seen.
    private Random random = new Random(42); // Random number thing—kept it at 42 so it’s predictable.
    private Map<String, Integer> transactionRetries = new HashMap<>(); // Keeps track of retries.
    private Map<String, Long> transactionTimestamps = new HashMap<>(); // Times when I sent stuff.
    private Map<String, String> pendingResponses = new HashMap<>(); // Stuff I’m waiting to hear back on.
    private List<String> poemFragments = new ArrayList<>(); // Bits of the poem I’ve collected.

    // Sets my node’s name. Gotta start with "N:" or it freaks out.
    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty() || !nodeName.startsWith("N:")) {
            throw new Exception("Hey, node name needs to start with 'N:' and can’t be blank!");
        }
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName)); // Hash it for later.
        // Check if I’m one of the cool poem nodes.
        if (nodeName.equals("N:rose") || nodeName.equals("N:magenta") || nodeName.equals("N:chartreuse")) {
            isPoemNode = true;
        }
    }

    // Opens a port for UDP. Has to be in the right range or it’s a no-go.
    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 20110 || portNumber > 20130) {
            throw new Exception("Port’s gotta be between 20110 and 20130—RFC says so!");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
        addressStore.put(nodeName, InetAddress.getLocalHost().getHostAddress() + ":" + portNumber);
    }

    // Listens for messages coming in. If nothing happens in "delay" time, it stops waiting.
    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[2048]; // Big enough for most messages, I hope!
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(100); // Quick timeout so I don’t hang forever.

        if (!hasPrintedWaiting) {
            System.out.println("Waiting for another node to get in touch...");
            hasPrintedWaiting = true;
        }

        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < delay * 1000) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                processMessage(message, packet.getAddress(), packet.getPort());

                // If I’ve got all 7 poem bits, show it off!
                if (!hasPrintedGettingPoem && poemFragments.size() >= 7) {
                    displayPoem();
                    hasPrintedGettingPoem = true;
                }

                // If I’ve seen 2 markers, list nodes and chill.
                if (markerCount >= 2) {
                    for (String node : nodeList) {
                        System.out.println("Node: " + node);
                    }
                    System.out.println("Handling incoming connections now!");
                    break;
                }
            } catch (SocketTimeoutException ignored) {
                retransmitPendingRequests(); // Resend anything I’m still waiting on.
            }
        }
        fetchPoemFragments(); // Try grabbing poem bits if I don’t have them yet.
    }

    // Goes after the poem bits from other nodes.
    private void fetchPoemFragments() throws Exception {
        String[] poemKeys = {"D:jabberwocky1", "D:jabberwocky2", "D:jabberwocky3", "D:jabberwocky4",
                "D:jabberwocky5", "D:jabberwocky6", "D:jabberwocky7"};
        for (String key : poemKeys) {
            if (!dataStore.containsKey(key) && poemFragments.size() < 7) {
                String transactionId = generateTransactionId();
                String request = transactionId + " R " + encodeString(key);
                sendToNearestNode(request, key);
                transactionRetries.put(transactionId, 0);
                transactionTimestamps.put(transactionId, System.currentTimeMillis());
            }
        }
    }

    // Resends stuff if I haven’t heard back in a while.
    private void retransmitPendingRequests() throws Exception {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<String, Long>> it = transactionTimestamps.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, Long> entry = it.next();
            String transactionId = entry.getKey();
            long sentTime = entry.getValue();
            int retries = transactionRetries.getOrDefault(transactionId, 0);

            if (now - sentTime > 5000 && retries < 3) { // 5 seconds, 3 tries max.
                String request = pendingResponses.get(transactionId);
                if (request != null) {
                    String[] parts = request.split(" ", 4);
                    String key = decodeString(parts[3]);
                    sendToNearestNode(request, key);
                    transactionRetries.put(transactionId, retries + 1);
                    transactionTimestamps.put(transactionId, now);
                }
            } else if (retries >= 3) { // Give up after 3 tries.
                it.remove();
                transactionRetries.remove(transactionId);
                pendingResponses.remove(transactionId);
            }
        }
    }

    // Sends a message to the closest node I know about.
    private void sendToNearestNode(String message, String key) throws Exception {
        List<Map.Entry<String, String>> closest = findClosestNodes(encodeHashID(calculateHashID(key)), 3);
        if (closest.isEmpty() && !addressStore.isEmpty()) {
            closest = new ArrayList<>(addressStore.entrySet());
        }
        if (!closest.isEmpty()) {
            Map.Entry<String, String> node = closest.get(0);
            String[] addrParts = node.getValue().split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(message, ip, port);
            pendingResponses.put(message.split(" ")[0], message);
        }
    }

    // Figures out what to do with a message I got.
    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        if (message == null || message.length() < 3) return; // Skip junk messages.

        String[] parts = message.split(" ", 3);
        if (parts.length < 2) return;

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        // Keep track of who’s talking to me.
        String senderAddr = senderAddress.getHostAddress() + ":" + senderPort;
        if (!nodeList.contains(senderAddr)) {
            nodeList.add(senderAddr);
        }

        switch (command) {
            case "G": // "Who are you?"
                handleNameRequest(transactionId, senderAddress, senderPort);
                break;
            case "N": // "Who’s close to this hash?"
                handleNearestRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "E": // "Does this key exist?"
                handleKeyExistenceRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "R": // "Gimme the value for this key!"
                handleReadRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "W": // "Store this key/value!"
                handleWriteRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "C": // "Swap this value if it matches!"
                handleCASRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "V": // "Pass this along!"
                handleRelayRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "I": // Info message—meh, ignore it.
                break;
            case "H":
            case "O":
            case "F":
            case "S":
            case "X":
            case "D": // Responses to my requests.
                handleResponse(transactionId, command, payload);
                break;
            default: // What even is this? Skip it.
                break;
        }
    }

    // Deals with responses to stuff I asked for.
    private void handleResponse(String transactionId, String command, String payload) {
        if (pendingResponses.containsKey(transactionId)) {
            transactionRetries.remove(transactionId);
            transactionTimestamps.remove(transactionId);
            pendingResponses.remove(transactionId);

            if (command.equals("S") && payload.startsWith("Y ")) {
                String value = payload.substring(2);
                String key = decodeString(pendingResponses.get(transactionId).split(" ", 4)[3]);
                if (key.startsWith("D:jabberwocky") && !dataStore.containsKey(key)) {
                    dataStore.put(key, value);
                    poemFragments.add(value);
                }
            }
        }
    }

    // Answers "Who are you?" with my name.
    private void handleNameRequest(String transactionId, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " H " + encodeString(nodeName);
        sendResponse(response, senderAddress, senderPort);
        addressStore.put(nodeName, senderAddress.getHostAddress() + ":" + senderPort);
    }

    // Tells someone who’s close to a hash.
    private void handleNearestRequest(String transactionId, String hashID, InetAddress senderAddress, int senderPort) throws Exception {
        List<Map.Entry<String, String>> closest = findClosestNodes(hashID, 3);
        StringBuilder response = new StringBuilder(transactionId + " O ");
        for (Map.Entry<String, String> entry : closest) {
            response.append(encodeString(entry.getKey())).append(" ").append(encodeString(entry.getValue())).append(" ");
        }
        sendResponse(response.toString().trim(), senderAddress, senderPort);
    }

    // Checks if a key exists and if I’m close to it.
    private void handleKeyExistenceRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String key = decodeString(payload);
        boolean gotIt = dataStore.containsKey(key);
        boolean closeEnough = isAmongClosest(key);
        String answer = gotIt ? "Y" : (closeEnough ? "N" : "?");
        String response = transactionId + " F " + answer;
        sendResponse(response, senderAddress, senderPort);
    }

    // Gives back a value if I’ve got it—or says if I don’t.
    private void handleReadRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String key = decodeString(payload);
        boolean gotIt = dataStore.containsKey(key);
        boolean closeEnough = isAmongClosest(key);
        String response;
        if (gotIt) {
            String value = dataStore.get(key);
            response = transactionId + " S Y " + encodeString(value);
        } else if (closeEnough) {
            response = transactionId + " S N";
        } else {
            response = transactionId + " S ?";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    // Stores a key/value pair and lets them know how it went.
    private void handleWriteRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 2) {
            sendResponse(transactionId + " X N", senderAddress, senderPort);
            return;
        }
        String key = decodeString(parts[0]);
        String value = decodeString(parts[1]);
        boolean gotIt = dataStore.containsKey(key);
        boolean closeEnough = isAmongClosest(key);

        String response;
        if (gotIt) {
            write(key, value);
            response = transactionId + " X R";
        } else if (closeEnough) {
            write(key, value);
            response = transactionId + " X A";
        } else {
            response = transactionId + " X X";
        }
        sendResponse(response, senderAddress, senderPort);

        if (key.equals("D:marker")) {
            markerCount++;
            System.out.println("Writing a marker—proof my code’s doing something!");
            System.out.println("It works! Woo!");
            System.out.println("Telling the other nodes where we’re at.");
        }
    }

    // Swaps a value if it matches what they expect.
    private void handleCASRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 4);
        if (parts.length < 3) {
            sendResponse(transactionId + " D N", senderAddress, senderPort);
            return;
        }
        String key = decodeString(parts[0]);
        String currentValue = decodeString(parts[1]);
        String newValue = decodeString(parts[2]);
        boolean gotIt = dataStore.containsKey(key);
        boolean closeEnough = isAmongClosest(key);

        String response;
        if (gotIt) {
            boolean worked = CAS(key, currentValue, newValue);
            response = transactionId + " D " + (worked ? "R" : "N");
        } else if (closeEnough) {
            write(key, newValue);
            response = transactionId + " D A";
        } else {
            response = transactionId + " D X";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    // Passes a message along to another node.
    private void handleRelayRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 2) return;
        String targetNode = decodeString(parts[0]);
        String relayedMessage = parts[1];

        String targetAddress = addressStore.get(targetNode);
        if (targetAddress != null) {
            String[] addrParts = targetAddress.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(relayedMessage, ip, port);

            // If it’s a request, wait for an answer and send it back.
            if (relayedMessage.matches(".. [GNERWC].*")) {
                String response = waitForResponse(relayedMessage.split(" ")[0], ip, port);
                if (response != null) {
                    sendResponse(response, senderAddress, senderPort);
                }
            }
        }
    }

    // Waits a bit for a response from a relayed message.
    private String waitForResponse(String transactionId, InetAddress targetIp, int targetPort) throws Exception {
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < 5000) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                if (message.startsWith(transactionId)) {
                    return message;
                }
            } catch (SocketTimeoutException ignored) {
            }
        }
        return null; // No luck—timeout!
    }

    // Sends a message out over UDP. Sometimes pretends it gets lost for fun.
    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        if (random.nextDouble() < 0.1) return; // 10% chance to drop it—testing the chaos!
        byte[] data = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    // Turns a string into a fancy SHA-256 hash.
    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    // Makes a hash into a hex string—looks cool!
    private String encodeHashID(byte[] hash) {
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // Finds the nodes closest to a hash—up to 3 of them.
    private List<Map.Entry<String, String>> findClosestNodes(String targetHash, int count) {
        List<Map.Entry<String, String>> nodes = new ArrayList<>(addressStore.entrySet());
        nodes.sort((a, b) -> {
            byte[] hashA = nodeHashes.getOrDefault(a.getKey(), calculateHashIDSafe(a.getKey()));
            byte[] hashB = nodeHashes.getOrDefault(b.getKey(), calculateHashIDSafe(b.getKey()));
            int distA = calculateDistance(targetHash, encodeHashID(hashA));
            int distB = calculateDistance(targetHash, encodeHashID(hashB));
            return Integer.compare(distA, distB);
        });
        return nodes.subList(0, Math.min(count, nodes.size()));
    }

    // Safe version of hash calc—if it fails, just give a blank one.
    private byte[] calculateHashIDSafe(String key) {
        try {
            return calculateHashID(key);
        } catch (Exception e) {
            return new byte[32]; // Eh, good enough fallback.
        }
    }

    // Figures out how close two hashes are—bit by bit.
    private int calculateDistance(String hash1, String hash2) {
        int matchingBits = 0;
        for (int i = 0; i < Math.min(hash1.length(), hash2.length()); i++) {
            int diff = Character.digit(hash1.charAt(i), 16) ^ Character.digit(hash2.charAt(i), 16);
            if (diff == 0) matchingBits += 4;
            else {
                matchingBits += Integer.numberOfLeadingZeros(diff) - 28;
                break;
            }
        }
        return 256 - matchingBits;
    }

    // Am I one of the closest nodes to this key?
    private boolean isAmongClosest(String key) {
        byte[] keyHash = calculateHashIDSafe(key);
        String encodedKeyHash = encodeHashID(keyHash);
        List<Map.Entry<String, String>> closest = findClosestNodes(encodedKeyHash, 3);
        return closest.stream().anyMatch(e -> e.getKey().equals(nodeName));
    }

    // Encodes a string with a space count—RFC’s weird string trick.
    private String encodeString(String s) {
        int spaceCount = (int) s.chars().filter(ch -> ch == ' ').count();
        return spaceCount + " " + s + " ";
    }

    // Pulls the string back out of that weird format.
    private String decodeString(String encoded) {
        String[] parts = encoded.split(" ", 3);
        if (parts.length < 3) return "";
        return parts[1];
    }

    // Makes a random-ish ID for tracking messages.
    private String generateTransactionId() {
        return String.format("%02x", random.nextInt(256)) + String.format("%02x", random.nextInt(256));
    }

    // Shows off the poem once I’ve got it all.
    private void displayPoem() {
        System.out.println("Getting the poem ...");
        for (String fragment : poemFragments) {
            String[] lines = fragment.split("\\s+"); // Splits on spaces—hope that’s right!
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    System.out.println(line.trim());
                }
            }
            System.out.println(); // Blank line between stanzas.
        }
        System.out.println("Poem by Lewis Carroll");
    }

    // Checks if a node’s name matches mine—am I the one they’re looking for?
    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    // Adds a relay node to my stack—gotta pass messages through them.
    @Override
    public void pushRelay(String nodeName) {
        if (nodeName != null && !nodeName.isEmpty()) {
            relayStack.push(nodeName);
        }
    }

    // Pops a relay off the stack—if there’s anything to pop.
    @Override
    public void popRelay() {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    // Does this key exist in my little stash?
    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    // Grabs a value from my stash—or nothing if it’s not there.
    @Override
    public String read(String key) {
        return dataStore.getOrDefault(key, "");
    }

    // Stashes a key/value pair—easy peasy!
    @Override
    public boolean write(String key, String value) {
        if (key == null || value == null) return false;
        dataStore.put(key, value);
        return true;
    }

    // Swaps a value if it matches—locks it so no one messes with it mid-swap.
    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        synchronized (dataStore) {
            String storedValue = dataStore.getOrDefault(key, "");
            if (storedValue.equals(currentValue)) {
                dataStore.put(key, newValue);
                return true;
            }
            return false;
        }
    }
}