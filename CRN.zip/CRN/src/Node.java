import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new ConcurrentHashMap<>();
    private Map<String, String> addressStore = new ConcurrentHashMap<>();
    private Stack<String> relayStack = new Stack<>();
    private List<String> knownNodes = new ArrayList<>();
    private Random random = new Random();
    private Map<String, Integer> transactionCounters = new ConcurrentHashMap<>();

    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        this.addressStore.put(nodeName, "127.0.0.1:" + port); // Store our own address
        System.out.println("Node set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
        System.out.println("Node " + nodeName + " listening on port " + port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Received: " + message + " from " + packet.getAddress());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException e) {
            System.out.println("No message received within timeout period.");
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        if (message == null || message.trim().isEmpty()) {
            sendResponse("ERROR Empty message", sender, senderPort);
            return;
        }

        String[] parts = message.split(" ", 3);
        if (parts.length < 2) {
            sendResponse("ERROR Malformed request", sender, senderPort);
            return;
        }

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "G": // Name request
                handleNameRequest(transactionId, sender, senderPort);
                break;
            case "N": // Nearest request
                handleNearestRequest(transactionId, payload, sender, senderPort);
                break;
            case "E": // Exists request
                handleExistsRequest(transactionId, payload, sender, senderPort);
                break;
            case "R": // Read request
                handleReadRequest(transactionId, payload, sender, senderPort);
                break;
            case "W": // Write request
                handleWriteRequest(transactionId, payload, sender, senderPort);
                break;
            case "C": // CAS request
                handleCASRequest(transactionId, payload, sender, senderPort);
                break;
            case "V": // Relay request
                handleRelayRequest(transactionId, payload, sender, senderPort);
                break;
            default:
                sendResponse(transactionId + " ERROR Unknown command", sender, senderPort);
                break;
        }
    }

    private void handleNameRequest(String transactionId, InetAddress sender, int senderPort) throws Exception {
        sendResponse(transactionId + " H " + nodeName, sender, senderPort);
    }

    private void handleNearestRequest(String transactionId, String hashID, InetAddress sender, int senderPort) throws Exception {
        // Simplified - should return closest nodes to the hashID
        StringBuilder response = new StringBuilder(transactionId + " O");
        int count = 0;
        for (Map.Entry<String, String> entry : addressStore.entrySet()) {
            if (count >= 3) break;
            response.append(" ").append(entry.getKey()).append(" ").append(entry.getValue());
            count++;
        }
        sendResponse(response.toString(), sender, senderPort);
    }

    private void handleExistsRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        char responseChar;
        if (dataStore.containsKey(key) || addressStore.containsKey(key)) {
            responseChar = 'Y';
        } else if (isClosestNode(key)) {
            responseChar = 'N';
        } else {
            responseChar = '?';
        }
        sendResponse(transactionId + " F " + responseChar, sender, senderPort);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        String response;
        if (dataStore.containsKey(key)) {
            response = transactionId + " S Y " + dataStore.get(key);
        } else if (addressStore.containsKey(key)) {
            response = transactionId + " S Y " + addressStore.get(key);
        } else if (isClosestNode(key)) {
            response = transactionId + " S N ";
        } else {
            response = transactionId + " S ? ";
        }
        sendResponse(response, sender, senderPort);
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " X X", sender, senderPort);
            return;
        }

        String key = parts[0];
        String value = parts[1];
        char responseChar;

        if (dataStore.containsKey(key) || addressStore.containsKey(key)) {
            if (key.startsWith("N:")) {
                addressStore.put(key, value);
            } else {
                dataStore.put(key, value);
            }
            responseChar = 'R';
        } else if (isClosestNode(key)) {
            if (key.startsWith("N:")) {
                addressStore.put(key, value);
            } else {
                dataStore.put(key, value);
            }
            responseChar = 'A';
        } else {
            responseChar = 'X';
        }

        sendResponse(transactionId + " X " + responseChar, sender, senderPort);
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length != 3) {
            sendResponse(transactionId + " D X", sender, senderPort);
            return;
        }

        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];
        char responseChar;

        if (dataStore.containsKey(key)) {
            if (dataStore.get(key).equals(currentValue)) {
                dataStore.put(key, newValue);
                responseChar = 'R';
            } else {
                responseChar = 'N';
            }
        } else if (isClosestNode(key)) {
            dataStore.put(key, newValue);
            responseChar = 'A';
        } else {
            responseChar = 'X';
        }

        sendResponse(transactionId + " D " + responseChar, sender, senderPort);
    }

    private void handleRelayRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " ERROR Invalid relay", sender, senderPort);
            return;
        }

        String targetNode = parts[0];
        String relayedMessage = parts[1];

        if (!addressStore.containsKey(targetNode)) {
            sendResponse(transactionId + " ERROR Unknown node", sender, senderPort);
            return;
        }

        String[] addressParts = addressStore.get(targetNode).split(":");
        InetAddress targetAddress = InetAddress.getByName(addressParts[0]);
        int targetPort = Integer.parseInt(addressParts[1]);

        // Forward the message
        byte[] data = relayedMessage.getBytes();
        DatagramPacket relayPacket = new DatagramPacket(data, data.length, targetAddress, targetPort);
        socket.send(relayPacket);

        // Wait for response
        byte[] buffer = new byte[1024];
        DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(5000); // 5 second timeout
        try {
            socket.receive(responsePacket);
            String response = new String(responsePacket.getData(), 0, responsePacket.getLength());
            // Forward response back to original sender
            sendResponse(transactionId + " " + response, sender, senderPort);
        } catch (SocketTimeoutException e) {
            sendResponse(transactionId + " ERROR Timeout", sender, senderPort);
        }
    }

    private boolean isClosestNode(String key) {
        // Simplified - should compare distances with other known nodes
        return true;
    }

    private String generateTransactionId() {
        int id = random.nextInt(65536);
        return String.format("%04x", id);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    public boolean isActive(String nodeName) throws Exception {
        return knownNodes.contains(nodeName) || addressStore.containsKey(nodeName);
    }

    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key) || addressStore.containsKey(key);
    }

    public String read(String key) throws Exception {
        if (dataStore.containsKey(key)) {
            return dataStore.get(key);
        }
        return addressStore.getOrDefault(key, "NULL");
    }

    public boolean write(String key, String value) throws Exception {
        if (key.startsWith("N:")) {
            addressStore.put(key, value);
        } else {
            dataStore.put(key, value);
        }
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    public void addKnownNode(String nodeAddress) {
        if (!knownNodes.contains(nodeAddress)) {
            knownNodes.add(nodeAddress);
        }
    }

    public static void main(String[] args) throws Exception {
        Node node = new Node();
        node.setNodeName("N:Node1");
        node.openPort(20110);
        node.addKnownNode("127.0.0.1:20111"); // Example node
        node.write("D:poem_verse", "This is a test verse.");
        System.out.println("Node is running...");

        while (true) {
            node.handleIncomingMessages(5000);
        }
    }
}