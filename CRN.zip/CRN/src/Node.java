// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  YOUR_NAME_GOES_HERE
//  YOUR_STUDENT_ID_NUMBER_GOES_HERE
//  YOUR_EMAIL_GOES_HERE


// DO NOT EDIT starts
// This gives the interface that your code must implement.
// These descriptions are intended to help you understand how the interface
// will be used. See the RFC for how the protocol works.

import java.net.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.math.BigInteger;

interface NodeInterface {


    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    // Set the name of the node.
    public void setNodeName(String nodeName) throws Exception;


    // Open a UDP port for sending and receiving messages.
    public void openPort(int portNumber) throws Exception;


    /*
     * These methods query and change how the network is used.
     */

    // Handle all incoming messages.
    // If you wait for more than delay miliseconds and
    // there are no new incoming messages return.
    // If delay is zero then wait for an unlimited amount of time.
    public void handleIncomingMessages(int delay) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    // Handles any messages that have arrived.
    public boolean isActive(String nodeName) throws Exception;

    // You need to keep a stack of nodes that are used to relay messages.
    // The base of the stack is the first node to be used as a relay.
    // The first node must relay to the second node and so on.

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void pushRelay(String nodeName) throws Exception;

    // Pops the top entry from the stack of nodes used for relaying.
    // No effect if the stack is empty
    public void popRelay() throws Exception;


    /*
     * These methods provide access to the basic functionality of
     * CRN-25 network.
     */

    // Checks if there is an entry in the network with the given key.
    // Handles any messages that have arrived.
    public boolean exists(String key) throws Exception;

    // Reads the entry stored in the network for key.
    // If there is a value, return it.
    // If there isn't a value, return null.
    // Handles any messages that have arrived.
    public String read(String key) throws Exception;

    // Sets key to be value.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean write(String key, String value) throws Exception;

    // If key is set to currentValue change it to newValue.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Complete this!
public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>(); // Store addresses
    private Map<String, String> transactionMap = new HashMap<>(); //Store transaction ID's

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty()) {
            throw new Exception("Node name cannot be empty");
        }
        this.nodeName = nodeName;
        addressStore.put(nodeName, "127.0.0.1:" + portNumber); // Store own address
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 1024 || portNumber > 65535) {
            throw new Exception("Invalid port number: Must be between 1024 and 65535");
        }
        try {
            this.socket = new DatagramSocket(portNumber);
            this.portNumber = portNumber;
            System.out.println("Port opened successfully on " + portNumber);
        } catch (SocketException e) {
            throw new Exception("Failed to open port: " + e.getMessage());
        }
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay); // Set timeout
        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength()).trim();
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException e) {
            // Timeout, no message
        }
    }

    private void processMessage(String message, InetAddress address, int port) throws Exception {
        String[] parts = message.split(" ");
        String transactionID = parts[0];
        String command = parts[1];

        if (command.equals("G")) { // Name request
            String response = transactionID + " H " + nodeName + " ";
            sendUDP(response, address, port);
        } else if (command.equals("N")) { // Nearest request
            String hash = parts[2];
            String response = transactionID + " O ";
            List<String> nearest = findNearest(hash);
            for (String addr : nearest) {
                response += "0 " + addr + " ";
            }
            sendUDP(response, address, port);
        } else if (command.equals("R")) { // Read request
            String key = parts[2];
            String value = dataStore.getOrDefault(key, "");
            String response = transactionID + " S ";
            if (dataStore.containsKey(key)) {
                response += "Y 0 " + value + " ";
            } else {
                response += "N 0  ";
            }
            sendUDP(response, address, port);
        } else if (command.equals("W")) { // Write request
            String key = parts[2];
            String value = parts[3] + " " + parts[4];
            dataStore.put(key, value);
            String response = transactionID + " X ";
            response += "A ";
            sendUDP(response, address, port);
        } else if (command.equals("C")) { // Compare-and-swap
            String key = parts[2];
            String currentValue = parts[3]+ " " + parts[4];
            String newValue = parts[5]+ " " + parts[6];
            String response = transactionID + " D ";
            if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
                dataStore.put(key, newValue);
                response += "R ";
            } else {
                response += "N ";
            }
            sendUDP(response, address, port);
        } else if (command.equals("V")) { //Relay message
            String nextNodeName = parts[2];
            String relayedMessage = message.substring(message.indexOf(nextNodeName) + nextNodeName.length() +1);
            String nextNodeAddress = addressStore.get(nextNodeName);
            if (nextNodeAddress != null){
                String[] ipAndPort = nextNodeAddress.split(":");
                sendUDP(relayedMessage, InetAddress.getByName(ipAndPort[0]), Integer.parseInt(ipAndPort[1]));
            }
        }
    }

    private void sendUDP(String message, InetAddress address, int port) throws Exception {
        byte[] buffer = message.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, port);
        socket.send(packet);
    }

    private List<String> findNearest(String hash) throws Exception {
        // Find nearest nodes based on hash (simplified for now)
        List<String> nearest = new ArrayList<>();
        Map<BigInteger, String> distanceMap = new HashMap<>();

        BigInteger targetHash = new BigInteger(calculateHash(hash), 16);

        for (String nodeName : addressStore.keySet()) {
            BigInteger nodeHash = new BigInteger(calculateHash(nodeName), 16);
            BigInteger distance = targetHash.subtract(nodeHash).abs();
            distanceMap.put(distance, addressStore.get(nodeName));
        }

        List<BigInteger> distances = new ArrayList<>(distanceMap.keySet());
        Collections.sort(distances);

        int count = 0;
        for (BigInteger distance : distances) {
            nearest.add(distanceMap.get(distance));
            count++;
            if (count >= 3) {
                break;
            }
        }
        return nearest; // Return closest 3 nodes
    }

    @Override
    public boolean isActive(String nodeName) throws Exception {
        // Send a name request and check for a response
        // (simplified for now)
        return true;
    }

    @Override
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    @Override
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    @Override
    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) throws Exception {
        return dataStore.getOrDefault(key, null);
    }

    @Override
    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    private String calculateHash(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
        return String.format("%064x", new BigInteger(1, hash));
    }
}