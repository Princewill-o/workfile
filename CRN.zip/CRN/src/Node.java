// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  [Your Name Goes Here]
//  [Your Student ID Number Goes Here]
//  [Your Email Goes Here]

// Alright, so this is my attempt at building a node for the CRN protocol.
// It’s supposed to chat with other nodes over UDP, grab the Jabberwocky poem,
// and handle some marker stuff. Let’s see how it goes!

// DO NOT EDIT starts
// This is the interface I have to follow. It’s like the rulebook for what my node needs to do.
// The comments here are pretty helpful for figuring out how it’s used—check the RFC for the nitty-gritty details.
import java.io.IOException;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {

    // These two get my node ready to roll.
    // Gotta call them once when I set things up, before anything else happens.

    // Sets the name for my node—like giving it an ID card.
    public void setNodeName(String nodeName) throws Exception;

    // Opens up a UDP port so my node can send and receive messages.
    public void openPort(int portNumber) throws Exception;

    // These are for messing with the network—checking stuff and moving messages around.

    // This one listens for incoming messages. If nothing shows up after "delay" milliseconds, it gives up.
    // If delay’s 0, it’ll wait forever (or until something happens).
    public void handleIncomingMessages(int delay) throws Exception;

    // Checks if another node is alive and responding. Also deals with any messages that pop up.
    public boolean isActive(String nodeName) throws Exception;

    // I’ve got a stack of relay nodes here—like a list of buddies to pass messages through.
    // First one in the stack relays to the next, and so on.

    // Adds a node to my relay stack for sending messages through.
    public void pushRelay(String nodeName) throws Exception;

    // Takes the top node off the relay stack. Does nothing if it’s empty.
    public void popRelay() throws Exception;

    // These are the main tools for working with the CRN network—like reading and writing stuff.

    // Checks if a key exists in the network. Also handles any messages that come in.
    public boolean exists(String key) throws Exception;

    // Grabs the value for a key from the network. Returns null if there’s nothing there.
    // Keeps an eye on incoming messages too.
    public String read(String key) throws Exception;

    // Sets a key to a value in the network. Returns true if it works, false if it flops.
    // Handles messages that show up while it’s at it.
    public boolean write(String key, String value) throws Exception;

    // If a key’s value matches currentValue, swaps it to newValue. True if it works, false if not.
    // Deals with messages too.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Here’s where I build my node! It’s got to do everything the interface says.
public class Node implements NodeInterface {

    // Node identity and socket for UDP communication
    private String nodeId;
    private DatagramSocket socket;

    // Key-value store for storing data
    private final Map<String, String> keyValueStore = new HashMap<>();

    // Stack to handle message relaying through intermediate nodes
    private final Stack<String> relayStack = new Stack<>();

    // Map of known peers and their network addresses
    private final Map<String, InetSocketAddress> networkPeers = new HashMap<>();

    // Storage for replies from proximity lookups
    private final Map<String, String> proximityResponses = new HashMap<>();

    // Cache of handled transaction IDs to avoid duplicates
    private final Set<String> handledTransactions = Collections.newSetFromMap(new LinkedHashMap<>() {
        protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
            return size() > 1000;
        }
    });

    private final Random random = new Random();
    private String lastReadValue = null;
    private boolean lastExistenceCheck = false;
    private final boolean showDebug = false;
    private Thread listenerThread;

    // Set the name/ID of the node, must begin with "N:"
    @Override
    public void setNodeName(String name) {
        if (!name.startsWith("N:")) throw new IllegalArgumentException("Node name must start with 'N:'");
        this.nodeId = name;
    }

    // Bind the socket to a given port and start listening for messages
    @Override
    public void openPort(int port) throws Exception {
        socket = new DatagramSocket(port);
        if (showDebug) System.out.println("Listening on port " + port);
        startListening();
    }

    // Handle incoming messages for a given duration (or indefinitely if timeout is 0)
    @Override
    public void handleIncomingMessages(int timeout) throws Exception {
        socket.setSoTimeout(100); // Polling delay
        byte[] buffer = new byte[2048];
        long start = System.currentTimeMillis();

        while (timeout == 0 || System.currentTimeMillis() - start < timeout) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                if (showDebug) System.out.println("Received: " + message);
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException ignored) {}
        }
    }

    // Process a received message based on its type
    private void processMessage(String msg, InetAddress sender, int senderPort) {
        try {
            if (Math.random() < 0.1) return; // Simulate packet loss (10%)

            String[] parts = msg.trim().split(" ", 3);
            if (parts.length < 2) return;

            String txnId = parts[0], type = parts[1];

            // Skip if already handled
            if (handledTransactions.contains(txnId)) return;
            handledTransactions.add(txnId);

            switch (type) {
                case "G" -> reply(sender, senderPort, txnId + " H " + wrap(nodeId)); // Greet request
                case "H" -> { // Greet reply
                    if (parts.length > 2) {
                        String node = unwrap(parts[2]);
                        if (node != null) {
                            networkPeers.put(node, new InetSocketAddress(sender, senderPort));
                        }
                    }
                }
                case "W" -> { // Write request
                    String[] kv = extractKeyValue(parts.length > 2 ? parts[2] : "");
                    if (kv != null) {
                        keyValueStore.put(kv[0], kv[1]);
                        // If the key represents a node ID, store its address
                        if (kv[0].startsWith("N:")) {
                            try {
                                String[] ipPort = kv[1].split(":");
                                if (ipPort.length == 2) {
                                    networkPeers.put(kv[0], new InetSocketAddress(ipPort[0], Integer.parseInt(ipPort[1])));
                                }
                            } catch (Exception ignored) {}
                        }
                        reply(sender, senderPort, txnId + " X A"); // Acknowledge write
                    }
                }
                case "R" -> { // Read request
                    String key = unwrap(parts.length > 2 ? parts[2] : "");
                    if (key != null) {
                        String value = keyValueStore.get(key);
                        reply(sender, senderPort, txnId + (value != null ? " S Y " + wrap(value) : " S N "));
                    }
                }
                case "S" -> { // Read response
                    if (parts.length > 2) {
                        String[] responseParts = parts[2].split(" ", 2);
                        if (responseParts[0].equals("Y") && responseParts.length > 1)
                            lastReadValue = unwrap(responseParts[1]);
                    }
                }
                case "E" -> { // Existence check request
                    String key = unwrap(parts.length > 2 ? parts[2] : "");
                    boolean exists = key != null && keyValueStore.containsKey(key);
                    reply(sender, senderPort, txnId + " F " + (exists ? "Y" : "N"));
                }
                case "F" -> { // Existence check response
                    if (parts.length > 2 && parts[2].trim().equals("Y")) lastExistenceCheck = true;
                }
                case "N" -> { // Proximity node request
                    if (parts.length > 2) {
                        String hash = parts[2].trim();
                        List<String> candidates = new ArrayList<>(networkPeers.keySet());
                        candidates.removeIf(n -> !n.startsWith("N:"));
                        candidates.sort(Comparator.comparingInt(n -> {
                            try {
                                return computeDistance(hash, computeHash(n));
                            } catch (Exception e) {
                                return Integer.MAX_VALUE;
                            }
                        }));
                        StringBuilder response = new StringBuilder(txnId + " O");
                        for (int i = 0; i < Math.min(3, candidates.size()); i++) {
                            String peer = candidates.get(i);
                            InetSocketAddress address = networkPeers.get(peer);
                            if (address != null) {
                                String ipPort = address.getAddress().getHostAddress() + ":" + address.getPort();
                                response.append(" ").append(wrap(peer)).append(wrap(ipPort));
                            }
                        }
                        reply(sender, senderPort, response.toString());
                    }
                }
                case "O" -> { // Proximity node response
                    if (parts.length > 2) proximityResponses.put(txnId, parts[2]);
                }
                case "V" -> { // Routed message
                    if (parts.length > 2) {
                        String[] inner = parts[2].split(" ", 2);
                        if (inner.length == 2) {
                            String next = unwrap(inner[0]);
                            String payload = inner[1];
                            if (next != null) {
                                if (next.equals(nodeId)) {
                                    processMessage(payload, sender, senderPort); // Final destination
                                } else if (networkPeers.containsKey(next)) {
                                    InetSocketAddress forwardTarget = networkPeers.get(next);
                                    String routedMsg = "V " + wrap(next) + payload;
                                    reply(forwardTarget.getAddress(), forwardTarget.getPort(), routedMsg); // Forward
                                }
                            }
                        }
                    }
                }
                case "I" -> {
                    // Ping or heartbeat handler (not implemented)
                }
            }
        } catch (Exception e) {
            if (showDebug) System.err.println("Processing error: " + e.getMessage());
        }
    }

    // Sends a message, applying relay stack if needed
    private void reply(InetAddress address, int port, String msg) {
        try {
            for (int i = relayStack.size() - 1; i >= 0; i--) {
                msg = "V " + wrap(relayStack.get(i)) + msg;
            }
            byte[] data = msg.getBytes();
            DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
            socket.send(packet);
            if (showDebug) System.out.println("Sent: " + msg);
        } catch (IOException e) {
            if (showDebug) System.err.println("Send failed: " + e.getMessage());
        }
    }

    // Encodes a string with its space count
    private String wrap(String s) {
        long spaces = s.chars().filter(c -> c == ' ').count();
        return spaces + " " + s + " ";
    }

    // Decodes a wrapped string
    private String unwrap(String s) {
        int idx = s.indexOf(' ');
        return (idx != -1 && s.length() > idx + 1) ? s.substring(idx + 1, s.length() - 1) : null;
    }

    // Extracts a key-value pair from a string
    private String[] extractKeyValue(String data) {
        try {
            String[] elements = data.trim().split(" ", 4);
            if (elements.length == 4) return new String[]{elements[1], elements[3]};
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    public boolean isActive(String nodeName) {
        return networkPeers.containsKey(nodeName);
    }

    @Override
    public void pushRelay(String nodeName) {
        relayStack.push(nodeName);
    }

    @Override
    public void popRelay() {
        if (!relayStack.isEmpty()) relayStack.pop();
    }

    @Override
    public boolean exists(String key) throws Exception {
        return tryLookup(key, true) != null;
    }

    @Override
    public String read(String key) throws Exception {
        return tryLookup(key, false);
    }

    // Starts the background thread that continuously listens for messages
    private void startListening() {
        listenerThread = new Thread(() -> {
            try {
                while (true) handleIncomingMessages(0);
            } catch (Exception e) {
                if (showDebug) System.err.println("Listener failed: " + e.getMessage());
            }
        });
        listenerThread.setDaemon(true);
        listenerThread.start();
    }

    // Generates a short random transaction ID
    private String generateTxn() {
        return "" + (char) ('A' + random.nextInt(26)) + (char) ('A' + random.nextInt(26));
    }

    // Attempts to read or check a key across the network using proximity routing
    private String tryLookup(String key, boolean checkExist) throws Exception {
        if (keyValueStore.containsKey(key)) return keyValueStore.get(key);

        String hash = computeHash(key);
        Set<String> queried = new HashSet<>();
        Queue<String> toVisit = new LinkedList<>(networkPeers.keySet());

        if (networkPeers.isEmpty()) {
            // Hardcoded fallback node
            networkPeers.put("N:azure", new InetSocketAddress("10.200.51.19", 20114));
            toVisit.add("N:azure");
        }

        while (!toVisit.isEmpty()) {
            String current = toVisit.poll();
            if (queried.contains(current) || !networkPeers.containsKey(current)) continue;
            queried.add(current);

            InetSocketAddress target = networkPeers.get(current);
            String txn = generateTxn();

            if (checkExist) {
                lastExistenceCheck = false;
                reply(target.getAddress(), target.getPort(), txn + " E " + wrap(key));
            } else {
                lastReadValue = null;
                reply(target.getAddress(), target.getPort(), txn + " R " + wrap(key));
            }

            long start = System.currentTimeMillis();
            while (System.currentTimeMillis() - start < 1000) {
                handleIncomingMessages(100);
                if ((checkExist && lastExistenceCheck) || (!checkExist && lastReadValue != null)) {
                    return checkExist ? "YES" : lastReadValue;
                }
            }

            // If key not found, get nearby nodes and continue
            String queryTxn = generateTxn();
            reply(target.getAddress(), target.getPort(), queryTxn + " N " + hash);

            long wait = System.currentTimeMillis();
            while (!proximityResponses.containsKey(queryTxn) && System.currentTimeMillis() - wait < 1000) {
                handleIncomingMessages(100);
            }

            String response = proximityResponses.get(queryTxn);
            if (response == null) continue;

            String[] nodes = response.trim().split(" ");
            for (int i = 0; i + 3 < nodes.length; i += 4) {
                String nodeName = nodes[i + 1];
                String addr = nodes[i + 3];
                if (nodeName.startsWith("N:") && addr.contains(":")) {
                    String[] ipPort = addr.split(":");
                    InetSocketAddress newNode = new InetSocketAddress(ipPort[0], Integer.parseInt(ipPort[1]));
                    networkPeers.put(nodeName, newNode);
                    if (!queried.contains(nodeName)) toVisit.add(nodeName);
                }
            }
        }

        return null;
    }

    @Override
    public boolean write(String key, String value) {
        keyValueStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String oldVal, String newVal) {
        if (!keyValueStore.containsKey(key)) {
            keyValueStore.put(key, newVal);
            return true;
        } else if (keyValueStore.get(key).equals(oldVal)) {
            keyValueStore.put(key, newVal);
            return true;
        }
        return false;
    }

    // SHA-256 hash function for node or key
    private String computeHash(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashed = digest.digest(input.getBytes("UTF-8"));
        StringBuilder builder = new StringBuilder();
        for (byte b : hashed) builder.append(String.format("%02x", b));
        return builder.toString();
    }

    // Computes bitwise distance between two hash strings
    private int computeDistance(String hash1, String hash2) {
        for (int i = 0; i < hash1.length(); i++) {
            int val1 = Integer.parseInt(hash1.substring(i, i + 1), 16);
            int val2 = Integer.parseInt(hash2.substring(i, i + 1), 16);
            int xor = val1 ^ val2;
            for (int bit = 3; bit >= 0; bit--) {
                if (((xor >> bit) & 1) == 1) return i * 4 + (3 - bit);
            }
        }
        return 256;
    }
}
