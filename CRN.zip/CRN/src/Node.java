import java.net.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

interface NodeInterface {
    void setNodeName(String nodeName) throws Exception;
    void openPort(int portNumber) throws Exception;
    void handleIncomingMessages(int delay) throws Exception;
    boolean isActive(String nodeName) throws Exception;
    void pushRelay(String nodeName) throws Exception;
    void popRelay() throws Exception;
    boolean exists(String key) throws Exception;
    String read(String key) throws Exception;
    boolean write(String key, String value) throws Exception;
    boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private final Map<String, String> dataStore = new ConcurrentHashMap<>();
    private final Map<String, String> addressStore = new ConcurrentHashMap<>();
    private final Stack<String> relayStack = new Stack<>();
    private final Random random = new Random();
    private final MessageDigest digest;

    public Node() throws Exception {
        this.digest = MessageDigest.getInstance("SHA-256");
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
        System.out.println("Node set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
        System.out.println("Node " + nodeName + " listening on port " + port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Received: " + message + " from " + packet.getAddress());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException ignored) {
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        if (message.trim().isEmpty()) {
            sendResponse("ERROR Empty message", sender, senderPort);
            return;
        }

        String processedMessage = message.startsWith("*") ? message.substring(2) : message;
        String[] parts = processedMessage.split(" ", 3);
        if (parts.length < 2) {
            sendResponse("ERROR Malformed request", sender, senderPort);
            return;
        }

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "G": handleNameRequest(transactionId, sender, senderPort); break;
            case "E": handleExistsRequest(transactionId, payload, sender, senderPort); break;
            case "R": handleReadRequest(transactionId, payload, sender, senderPort); break;
            case "W": handleWriteRequest(transactionId, payload, sender, senderPort); break;
            case "C": handleCASRequest(transactionId, payload, sender, senderPort); break;
            case "N": handleNearestRequest(transactionId, sender, senderPort); break;
            case "L": handleRelayRequest(transactionId, payload, sender, senderPort); break;
            default: sendResponse(transactionId + " ERROR Unknown command", sender, senderPort); break;
        }
    }

    private void handleNameRequest(String transactionId, InetAddress sender, int senderPort) throws Exception {
        sendResponse(transactionId + " H " + nodeName, sender, senderPort);
    }

    private void handleExistsRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        boolean exists = dataStore.containsKey(key) || addressStore.containsKey(key);
        sendResponse(transactionId + " F " + (exists ? "Y" : "N"), sender, senderPort);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        String value = dataStore.getOrDefault(key, addressStore.getOrDefault(key, "NULL"));
        sendResponse(transactionId + " S " + ("NULL".equals(value) ? "N" : "Y") + " " + value, sender, senderPort);
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " X X", sender, senderPort);
            return;
        }
        dataStore.put(parts[0], parts[1]);
        sendResponse(transactionId + " X A", sender, senderPort);
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length != 3) {
            sendResponse(transactionId + " D X", sender, senderPort);
            return;
        }
        boolean success = dataStore.containsKey(parts[0]) && dataStore.get(parts[0]).equals(parts[1]);
        if (success) dataStore.put(parts[0], parts[2]);
        sendResponse(transactionId + " D " + (success ? "R" : "N"), sender, senderPort);
    }

    private void handleNearestRequest(String transactionId, InetAddress sender, int senderPort) throws Exception {
        String nearest = nodeName; // Default to self
        int minDistance = Integer.MAX_VALUE;

        for (String otherNode : addressStore.keySet()) {
            int distance = getHashDistance(nodeName, otherNode);
            if (distance < minDistance) {
                nearest = otherNode;
                minDistance = distance;
            }
        }
        sendResponse(transactionId + " N " + nearest, sender, senderPort);
    }

    private int getHashDistance(String name1, String name2) throws Exception {
        byte[] hash1 = digest.digest(name1.getBytes());
        byte[] hash2 = digest.digest(name2.getBytes());
        int distance = 0;
        for (int i = 0; i < hash1.length; i++) {
            distance += Math.abs((hash1[i] & 0xFF) - (hash2[i] & 0xFF));
        }
        return distance;
    }


    private void handleRelayRequest(String transactionId, String nodeName, InetAddress sender, int senderPort) throws Exception {
        pushRelay(nodeName);
        sendResponse(transactionId + " L A", sender, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    public boolean isActive(String nodeName) {
        return addressStore.containsKey(nodeName);
    }

    public void pushRelay(String nodeName) {
        relayStack.push(nodeName);
    }

    public void popRelay() {
        if (!relayStack.isEmpty()) relayStack.pop();
    }

    public boolean exists(String key) {
        return dataStore.containsKey(key) || addressStore.containsKey(key);
    }

    public String read(String key) {
        return dataStore.getOrDefault(key, "NULL");
    }

    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) {
        return dataStore.containsKey(key) && dataStore.get(key).equals(currentValue) && dataStore.put(key, newValue) != null;
    }

    public static void main(String[] args) throws Exception {
        Node node = new Node();
        node.setNodeName("N:node-" + new Random().nextInt(1000));
        node.openPort(20110 + new Random().nextInt(20));
        System.out.println("Node " + node.nodeName + " running on port " + node.port);
        while (true) {
            node.handleIncomingMessages(1000);
        }
    }
}