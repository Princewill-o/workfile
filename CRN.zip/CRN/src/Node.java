// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  YOUR_NAME_GOES_HERE
//  YOUR_STUDENT_ID_NUMBER_GOES_HERE
//  YOUR_EMAIL_GOES_HERE


// DO NOT EDIT starts
// This gives the interface that your code must implement.
// These descriptions are intended to help you understand how the interface
// will be used. See the RFC for how the protocol works.

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Stack;

interface NodeInterface {


    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    // Set the name of the node.
    public void setNodeName(String nodeName) throws Exception;


    // Open a UDP port for sending and receiving messages.
    public void openPort(int portNumber) throws Exception;


    /*
     * These methods query and change how the network is used.
     */

    // Handle all incoming messages.
    // If you wait for more than delay miliseconds and
    // there are no new incoming messages return.
    // If delay is zero then wait for an unlimited amount of time.
    public void handleIncomingMessages(int delay) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    // Handles any messages that have arrived.
    public boolean isActive(String nodeName) throws Exception;

    // You need to keep a stack of nodes that are used to relay messages.
    // The base of the stack is the first node to be used as a relay.
    // The first node must relay to the second node and so on.

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void pushRelay(String nodeName) throws Exception;

    // Pops the top entry from the stack of nodes used for relaying.
    // No effect if the stack is empty
    public void popRelay() throws Exception;


    /*
     * These methods provide access to the basic functionality of
     * CRN-25 network.
     */

    // Checks if there is an entry in the network with the given key.
    // Handles any messages that have arrived.
    public boolean exists(String key) throws Exception;

    // Reads the entry stored in the network for key.
    // If there is a value, return it.
    // If there isn't a value, return null.
    // Handles any messages that have arrived.
    public String read(String key) throws Exception;

    // Sets key to be value.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean write(String key, String value) throws Exception;

    // If key is set to currentValue change it to newValue.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Complete this!
public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;  // Declared socket field
    private int portNumber; // Declared portNumber field
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private HashSet<String> queriedNodes = new HashSet<>();

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty()) {
            throw new Exception("Not implemented");
        }
        this.nodeName = nodeName;
    }
    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 1024 || portNumber > 65535) {
            throw new Exception("Not implemented");
        }
        try {
            this.socket = new DatagramSocket(portNumber);
            this.portNumber = portNumber;
        } catch (SocketException e) {
            throw new Exception("Failed to open port: " + e.getMessage());
        }
    }

    private String handleNearestRequest(String transactionId, String hashId) {
        String nearestAddresses = findNearestAddresses(hashId);
        return transactionId + " O " + nearestAddresses;
    }

    private String findNearestAddresses(String hashId) {
        String exampleAddresses = "N:node1 127.0.0.1:20110 N:node2 127.0.0.1:20111";
        return exampleAddresses;
    }

    private String getPoemVerse(String verseKey) throws Exception {
        queriedNodes.clear();
        return findVerse(verseKey, "127.0.0.1:20110");
    }

    private String findVerse(String verseKey, String nodeAddress) throws Exception {
        if (queriedNodes.contains(nodeAddress)) {
            return null;
        }
        queriedNodes.add(nodeAddress);

        String readResponse = sendReadRequest(verseKey, nodeAddress);

        if (readResponse.startsWith("S Y")) {
            return readResponse.substring(4);
        } else if (readResponse.startsWith("O")) {
            String[] nearestNodes = parseNearestResponse(readResponse);
            for (String nearestNode : nearestNodes) {
                String verse = findVerse(verseKey, nearestNode);
                if (verse != null) {
                    return verse;
                }
            }
        }
        return null;
    }

    private String sendReadRequest(String verseKey, String nodeAddress) throws Exception {
        String message = "TXID R " + verseKey;
        String[] parts = nodeAddress.split(":");
        InetAddress address = InetAddress.getByName(parts[0]);
        int port = Integer.parseInt(parts[1]);
        DatagramPacket packet = new DatagramPacket(message.getBytes(), message.length(), address, port);
        socket.send(packet);

        byte[] buffer = new byte[1024];
        DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
        socket.receive(responsePacket);
        return new String(responsePacket.getData(), 0, responsePacket.getLength());
    }

    private String[] parseNearestResponse(String response) {
        String[] parts = response.split(" ");
        String[] addresses = new String[parts.length - 2];
        for (int i = 2; i < parts.length; i++) {
            addresses[i - 2] = parts[i].substring(2);
        }
        return addresses;
    }


    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay);

        while (true) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                processMessage(message, packet.getAddress(), packet.getPort());
            } catch (java.net.SocketTimeoutException e) {
                if (delay != 0) {
                    break;
                }
            }
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        String transactionId = parts[0];
        String payload = parts[1];

        if (payload.startsWith("G")) {
            sendResponse(transactionId + " H " + nodeName, senderAddress, senderPort);
        } else if (payload.startsWith("N")) {
            String response = handleNearestRequest(transactionId, payload.substring(2));
            sendResponse(response, senderAddress, senderPort);
        } else if (payload.startsWith("E")) {
            handleExistsRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("R")) {
            handleReadRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("W")) {
            handleWriteRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("C")) {
            handleCASRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        } else if (payload.startsWith("V")) {
            handleRelayRequest(transactionId, payload.substring(2), senderAddress, senderPort);
        }
    }
    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        DatagramPacket packet = new DatagramPacket(response.getBytes(), response.length(), address, port);
        socket.send(packet);
    }

    private void handleExistsRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " F ";
        if(exists(key)) {
            response += "Y";
        } else if(addressStore.containsKey(key)){
            response += "N";
        } else {
            response += "?";
        }
        sendResponse(response, senderAddress, senderPort);
    }
    private void handleReadRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " S ";
        if (exists(key)) {
            response += "Y " + read(key);
        } else if (addressStore.containsKey(key)){
            response += "N ";
        } else {
            response += "? ";
        }
        sendResponse(response, senderAddress, senderPort);
    }
    private void handleWriteRequest(String transactionId, String keyValue, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = keyValue.split(" ");
        String key = parts[0];
        String value = parts[1];
        String response = transactionId + " X ";
        if (exists(key)) {
            write(key, value);
            response += "R";
        } else if (addressStore.containsKey(key)){
            write(key, value);
            response += "A";
        } else {
            response += "X";
        }
        sendResponse(response, senderAddress, senderPort);
    }
    private void handleCASRequest(String transactionId, String casValue, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = casValue.split(" ");
        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];
        String response = transactionId + " D ";
        if (exists(key)) {
            if (CAS(key, currentValue, newValue)) {
                response += "R";
            } else {
                response += "N";
            }
        } else if (addressStore.containsKey(key)){
            write(key, newValue);
            response += "A";
        } else {
            response += "X";
        }
        sendResponse(response, senderAddress, senderPort);
    }
    private void handleRelayRequest(String transactionId, String relayMessage, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = relayMessage.split(" ", 2);
        String destinationNode = parts[0];
        String innerMessage = parts[1];

        String[] destinationParts = addressStore.get(destinationNode).split(":");
        InetAddress destinationAddress = InetAddress.getByName(destinationParts[0]);
        int destinationPort = Integer.parseInt(destinationParts[1]);

        DatagramPacket relayPacket = new DatagramPacket(innerMessage.getBytes(), innerMessage.length(), destinationAddress, destinationPort);
        socket.send(relayPacket);

        if (innerMessage.startsWith("TXID R") || innerMessage.startsWith("TXID E") || innerMessage.startsWith("TXID W") || innerMessage.startsWith("TXID C")) {
            byte[] buffer = new byte[1024];
            DatagramPacket responsePacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(responsePacket);
            String relayedResponse = new String(responsePacket.getData(), 0, responsePacket.getLength());
            sendResponse(transactionId + " " + relayedResponse, senderAddress, senderPort);
        }
    }
    public boolean isActive(String nodeName) throws Exception {
        return nodeName.equals(this.nodeName);
    }
    @Override
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }
    @Override
    public void popRelay() throws Exception {
        if (relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    @Override
    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) throws Exception {
        return dataStore.get(key);
    }

    @Override
    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;

    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }
}