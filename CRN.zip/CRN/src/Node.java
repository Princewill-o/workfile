// IN2011 Computer Networks
// Coursework 2024/2025
//
// Submission by
//  Princewill Okube
//  YOUR_STUDENT_ID_NUMBER_GOES_HERE
//  Princewill.okube@city.ac.uk

import java.io.IOException;
import java.net.*;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

// DO NOT EDIT starts
interface NodeInterface {
    public void setNodeName(String identifier) throws Exception;
    public void openPort(int port) throws Exception;
    public void handleIncomingMessages(int waitTime) throws Exception;
    public boolean isNodeOperational(String nodeIdentifier) throws Exception;
    public void addRelayNode(String nodeIdentifier) throws Exception;
    public void removeRelayNode() throws Exception;
    public boolean keyExists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean compareAndSet(String key, String oldValue, String newValue) throws Exception;
}
// DO NOT EDIT ends

public class Node implements NodeInterface {

    // Core network and threading variables
    private DatagramSocket commChannel;
    private Thread messageProcessor;
    private static final boolean LOGGING = false;
    private final SecureRandom randomizer = new SecureRandom();

    // Listener setup moved early
    private void startMessageListener() {
        messageProcessor = new Thread(() -> {
            while (true) {
                try {
                    handleIncomingMessages(0);
                } catch (Exception e) {
                    if (LOGGING) System.err.println("Listener error: " + e.getMessage());
                }
            }
        });
        messageProcessor.setDaemon(true);
        messageProcessor.start();
    }

    // Data and state variables
    private String myName;
    private volatile String lastReadValue = null;
    private volatile boolean lastExistsResult = false;
    private final HashMap<String, String> dataVault = new HashMap<>();
    private final LinkedList<String> relayQueue = new LinkedList<>();
    private final HashMap<String, InetSocketAddress> nodeDirectory = new HashMap<>();
    private final HashMap<String, String> proximityCache = new HashMap<>();
    private final HashSet<String> handledMessages = new HashSet<>();

    // Key operation methods
    @Override
    public boolean write(String key, String value) {
        dataVault.put(key, value);
        return true;
    }

    @Override
    public boolean compareAndSet(String key, String oldValue, String newValue) {
        String current = dataVault.get(key);
        if (current == null) {
            dataVault.put(key, newValue);
            return true;
        }
        if (current.equals(oldValue)) {
            dataVault.put(key, newValue);
            return true;
        }
        return false;
    }

    @Override
    public String read(String key) throws Exception {
        String result = searchNetwork(key, false);
        return "YES".equals(result) ? null : result;
    }

    @Override
    public boolean keyExists(String key) throws Exception {
        String result = searchNetwork(key, true);
        return "YES".equals(result);
    }

    // Utility methods for encoding and hashing
    private String generateId() {
        byte[] bytes = new byte[2];
        randomizer.nextBytes(bytes);
        return Base64.getEncoder().encodeToString(bytes).substring(0, 3);
    }

    private String encode(String input) {
        return Base64.getEncoder().encodeToString(input.getBytes());
    }

    private String decode(String input) {
        try {
            return new String(Base64.getDecoder().decode(input));
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private String digestKey(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(input.getBytes());
            return Base64.getEncoder().encodeToString(digest);
        } catch (Exception e) {
            return Integer.toHexString(input.hashCode());
        }
    }

    private int computeProximity(String digest1, String digest2) {
        byte[] d1 = Base64.getDecoder().decode(digest1);
        byte[] d2 = Base64.getDecoder().decode(digest2);
        int distance = 0;
        for (int i = 0; i < Math.min(d1.length, d2.length); i++) {
            distance += Integer.bitCount(d1[i] ^ d2[i]);
        }
        return distance;
    }

    // Network setup and relay methods
    @Override
    public void setNodeName(String identifier) throws Exception {
        if (!identifier.startsWith("N:")) throw new IllegalStateException("Node name must start with 'N:'");
        myName = identifier;
    }

    @Override
    public void openPort(int port) throws Exception {
        commChannel = new DatagramSocket(port);
        if (LOGGING) System.out.println("Listening on port: " + port);
        startMessageListener();
    }

    @Override
    public void addRelayNode(String nodeIdentifier) {
        relayQueue.addFirst(nodeIdentifier);
    }

    @Override
    public void removeRelayNode() {
        if (!relayQueue.isEmpty()) relayQueue.removeFirst();
    }

    @Override
    public boolean isNodeOperational(String nodeIdentifier) {
        return nodeDirectory.containsKey(nodeIdentifier);
    }

    // Message handling and transmission
    @Override
    public void handleIncomingMessages(int waitTime) throws Exception {
        commChannel.setSoTimeout(50);
        byte[] buffer = new byte[4096];
        long deadline = System.currentTimeMillis() + waitTime;

        do {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                commChannel.receive(packet);
                String incoming = new String(packet.getData(), 0, packet.getLength()).trim();
                if (LOGGING) System.out.println("Received: " + incoming);
                processPacket(incoming, packet.getAddress(), packet.getPort());
            } catch (SocketTimeoutException e) {
                // Timeout is expected, continue looping
            }
        } while (waitTime == 0 || System.currentTimeMillis() < deadline);
    }

    private void transmit(InetAddress target, int port, String msg) {
        try {
            String finalMsg = msg;
            for (String relay : relayQueue) {
                finalMsg = "V " + encode(relay) + " " + finalMsg;
            }
            byte[] data = finalMsg.getBytes("UTF-8");
            commChannel.send(new DatagramPacket(data, data.length, target, port));
            if (LOGGING) System.out.println("Sent: " + finalMsg);
        } catch (IOException e) {
            if (LOGGING) System.err.println("Transmission error: " + e.getMessage());
        }
    }

    private void processPacket(String packet, InetAddress sender, int senderPort) {
        if (randomizer.nextInt(10) == 0) return; // 10% drop chance

        String[] parts = packet.split("\\s+", 3);
        if (parts.length < 2) return;

        String msgId = parts[0];
        String action = parts[1];

        if (handledMessages.contains(msgId)) return;
        handledMessages.add(msgId);

        switch (action) {
            case "G":
                transmit(sender, senderPort, msgId + " H " + encode(myName));
                break;
            case "H":
                if (parts.length == 3) {
                    String node = decode(parts[2]);
                    if (node != null) nodeDirectory.put(node, new InetSocketAddress(sender, senderPort));
                }
                break;
            case "W":
                if (parts.length == 3) {
                    String[] kv = extractPair(parts[2]);
                    if (kv != null && kv.length == 2) {
                        dataVault.put(kv[0], kv[1]);
                        if (kv[0].startsWith("N:")) updateNodeDirectory(kv[0], kv[1]);
                        transmit(sender, senderPort, msgId + " X A");
                    }
                }
                break;
            case "R":
                if (parts.length == 3) {
                    String key = decode(parts[2]);
                    if (key != null) {
                        String val = dataVault.getOrDefault(key, null);
                        transmit(sender, senderPort, msgId + (val != null ? " S Y " + encode(val) : " S N"));
                    }
                }
                break;
            case "S":
                if (parts.length == 3 && parts[2].startsWith("Y ")) {
                    lastReadValue = decode(parts[2].substring(2));
                }
                break;
            case "E":
                if (parts.length == 3) {
                    String key = decode(parts[2]);
                    if (key != null) {
                        boolean exists = dataVault.containsKey(key);
                        transmit(sender, senderPort, msgId + " F " + (exists ? "Y" : "N"));
                    }
                }
                break;
            case "F":
                if (parts.length == 3 && "Y".equals(parts[2])) lastExistsResult = true;
                break;
            case "N":
                if (parts.length == 3) {
                    respondWithNearestNodes(sender, senderPort, msgId, parts[2]);
                }
                break;
            case "O":
                if (parts.length == 3) proximityCache.put(msgId, parts[2]);
                break;
            case "V":
                if (parts.length == 3) {
                    String[] relayParts = parts[2].split("\\s+", 2);
                    if (relayParts.length == 2) {
                        String relayTo = decode(relayParts[0]);
                        if (relayTo != null) {
                            if (relayTo.equals(myName)) {
                                processPacket(relayParts[1], sender, senderPort);
                            } else if (nodeDirectory.containsKey(relayTo)) {
                                InetSocketAddress next = nodeDirectory.get(relayTo);
                                transmit(next.getAddress(), next.getPort(), "V " + encode(relayTo) + " " + relayParts[1]);
                            }
                        }
                    }
                }
                break;
            case "I":
                // Optional ping
                break;
        }
    }

    // Additional network support methods
    private String[] extractPair(String data) {
        String[] tokens = data.split("\\s+");
        return tokens.length >= 2 ? new String[]{decode(tokens[0]), decode(tokens[1])} : null;
    }

    private void updateNodeDirectory(String key, String value) {
        try {
            String[] parts = value.split(":");
            if (parts.length == 2) {
                nodeDirectory.put(key, new InetSocketAddress(parts[0], Integer.parseInt(parts[1])));
            }
        } catch (NumberFormatException ignored) {}
    }

    private void respondWithNearestNodes(InetAddress target, int port, String msgId, String hash) {
        List<Map.Entry<String, InetSocketAddress>> peers = new ArrayList<>(nodeDirectory.entrySet());
        peers.removeIf(entry -> !entry.getKey().startsWith("N:"));
        peers.sort(Comparator.comparingInt(entry -> computeProximity(hash, digestKey(entry.getKey()))));

        StringBuilder response = new StringBuilder(msgId + " O");
        for (int i = 0; i < Math.min(3, peers.size()); i++) {
            String name = peers.get(i).getKey();
            InetSocketAddress addr = peers.get(i).getValue();
            response.append(" ").append(encode(name)).append(" ").append(encode(addr.getHostString() + ":" + addr.getPort()));
        }
        transmit(target, port, response.toString());
    }

    // Network search logic at the end
    private String searchNetwork(String key, boolean checkOnly) throws Exception {
        if (dataVault.containsKey(key)) return dataVault.get(key);

        String keyDigest = digestKey(key);
        Set<String> visited = new HashSet<>();
        List<String> toVisit = new ArrayList<>(nodeDirectory.keySet());

        if (toVisit.isEmpty()) {
            InetSocketAddress bootstrap = new InetSocketAddress("10.200.51.19", 20114);
            nodeDirectory.put("N:azure", bootstrap);
            toVisit.add("N:azure");
        }

        Iterator<String> iterator = toVisit.iterator();
        while (iterator.hasNext()) {
            String peer = iterator.next();
            if (visited.contains(peer) || !nodeDirectory.containsKey(peer)) continue;
            visited.add(peer);

            InetSocketAddress peerAddr = nodeDirectory.get(peer);
            String txId = generateId();

            if (checkOnly) {
                lastExistsResult = false;
                transmit(peerAddr.getAddress(), peerAddr.getPort(), txId + " E " + encode(key));
            } else {
                lastReadValue = null;
                transmit(peerAddr.getAddress(), peerAddr.getPort(), txId + " R " + encode(key));
            }

            long endTime = System.currentTimeMillis() + 800;
            while (System.currentTimeMillis() < endTime) {
                handleIncomingMessages(50);
                if (checkOnly && lastExistsResult) return "YES";
                if (!checkOnly && lastReadValue != null) return lastReadValue;
            }

            String nearId = generateId();
            transmit(peerAddr.getAddress(), peerAddr.getPort(), nearId + " N " + keyDigest);

            long nearEnd = System.currentTimeMillis() + 800;
            while (!proximityCache.containsKey(nearId) && System.currentTimeMillis() < nearEnd) {
                handleIncomingMessages(50);
            }

            String nearData = proximityCache.get(nearId);
            if (nearData != null) {
                String[] details = nearData.split("\\s+");
                for (int i = 0; i + 1 < details.length; i += 2) {
                    String name = decode(details[i]);
                    String addrStr = decode(details[i + 1]);
                    if (name != null && addrStr != null && name.startsWith("N:") && addrStr.contains(":")) {
                        String[] addrParts = addrStr.split(":");
                        InetSocketAddress newPeer = new InetSocketAddress(addrParts[0], Integer.parseInt(addrParts[1]));
                        nodeDirectory.put(name, newPeer);
                        if (!visited.contains(name)) toVisit.add(name);
                    }
                }
            }
        }
        return null;
    }
}