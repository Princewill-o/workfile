import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private List<String> nodeList = new ArrayList<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private boolean isPoemNode = false;
    private boolean hasPrintedWaiting = false;
    private boolean hasPrintedGettingPoem = false;
    private boolean hasPrintedFullPoem = false;
    private int markerCount = 0;
    private Random random = new Random();

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty()) {
            throw new Exception("Node name cannot be null or empty");
        }
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName));
        if (nodeName.equals("rose") || nodeName.equals("magenta") || nodeName.equals("chartreuse")) {
            isPoemNode = true;
        }
    }

    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 1024 || portNumber > 65535) {
            throw new Exception("Port number must be between 1024 and 65535");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[2048];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(100);

        if (!hasPrintedWaiting) {
            System.out.println("Waiting for another node to get in contact");
            hasPrintedWaiting = true;
        }

        long startTime = System.currentTimeMillis();
        while (System.currentTimeMillis() - startTime < delay * 1000) {
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);
                processMessage(message, packet.getAddress(), packet.getPort());

                if (markerCount >= 2) {
                    for (String node : nodeList) {
                        System.out.println("Node: " + node);
                    }
                    break;
                }
            } catch (SocketTimeoutException ignored) {
                // Continue waiting for messages
            }
        }
        System.out.println("Handling incoming connections");
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 3);
        if (parts.length < 2) return;

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "G":
                handleNameRequest(transactionId, senderAddress, senderPort);
                break;
            case "N":
                handleNearestRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "E":
                handleKeyExistenceRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "R":
                handleReadRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "W":
                handleWriteRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "C":
                handleCASRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "V":
                handleRelayRequest(transactionId, payload, senderAddress, senderPort);
                break;
            case "I":
                // Information messages are ignored as per RFC
                break;
            default:
                // Unknown commands are ignored
                break;
        }
    }

    private void handleNameRequest(String transactionId, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " H " + nodeName;
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleNearestRequest(String transactionId, String hashID, InetAddress senderAddress, int senderPort) throws Exception {
        // Find closest nodes to the requested hashID
        List<Map.Entry<String, String>> closestNodes = findClosestNodes(hashID, 3);
        StringBuilder response = new StringBuilder(transactionId + " O ");
        for (Map.Entry<String, String> entry : closestNodes) {
            response.append(entry.getKey()).append(" ").append(entry.getValue()).append(" ");
        }
        sendResponse(response.toString(), senderAddress, senderPort);
    }

    private List<Map.Entry<String, String>> findClosestNodes(String targetHash, int count) {
        // Implementation to find closest nodes by hash distance
        // This would compare hash distances and return the closest nodes
        return new ArrayList<>(); // Simplified for brevity
    }

    private void handleKeyExistenceRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String responseChar = dataStore.containsKey(key) ? "Y" : "?";
        String response = transactionId + " F " + responseChar;
        sendResponse(response, senderAddress, senderPort);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response;
        if (dataStore.containsKey(key)) {
            String value = dataStore.get(key);
            response = transactionId + " S Y " + value;
            if (key.equals("D:jabberwocky") && !hasPrintedGettingPoem) {
                hasPrintedGettingPoem = true;
                displayPoem(value);
            }
        } else {
            response = transactionId + " S ?";
        }
        sendResponse(response, senderAddress, senderPort);
    }

    private void displayPoem(String poem) {
        System.out.println("Getting the poem ...");
        System.out.println(poem);
        System.out.println("Poem by Lewis Carroll");
        hasPrintedFullPoem = true;
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(transactionId + " X N", senderAddress, senderPort);
            return;
        }

        String key = parts[0];
        String value = parts[1];
        write(key, value);
        sendResponse(transactionId + " X R", senderAddress, senderPort);

        if (key.equals("D:marker")) {
            markerCount++;
            System.out.println("Writing a marker so it's clear my code works");
            System.out.println("It works!");
            System.out.println("Letting other nodes know where we are");
        }
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(transactionId + " D N", senderAddress, senderPort);
            return;
        }

        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];
        boolean success = CAS(key, currentValue, newValue);
        sendResponse(transactionId + " D " + (success ? "R" : "N"), senderAddress, senderPort);
    }

    private void handleRelayRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) return;

        String targetNode = parts[0];
        String relayedMessage = parts[1];

        // Find target node address and forward message
        String targetAddress = addressStore.get(targetNode);
        if (targetAddress != null) {
            String[] addrParts = targetAddress.split(":");
            InetAddress ip = InetAddress.getByName(addrParts[0]);
            int port = Integer.parseInt(addrParts[1]);
            sendResponse(relayedMessage, ip, port);
        }
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    // Implementations of NodeInterface methods
    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public void pushRelay(String nodeName) {
        relayStack.push(nodeName);
    }

    @Override
    public void popRelay() {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) {
        return dataStore.get(key);
    }

    @Override
    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        synchronized (dataStore) {
            if (dataStore.getOrDefault(key, "").equals(currentValue)) {
                dataStore.put(key, newValue);
                return true;
            }
            return false;
        }
    }
}