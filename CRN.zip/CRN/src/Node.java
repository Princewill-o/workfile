// IN2011 Computer Networks
// Coursework 2024/2025
// 230007985
// Submission by
// Princewill Okube
// 2
// princewill.okube@city.ac.uk


// DO NOT EDIT starts
// This gives the interface that your code must implement.
// These descriptions are intended to help you understand how the interface
// will be used. See the RFC for how the protocol works.

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

interface NodeInterface {

    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    // Set the name of the node.
    public void setNodeName(String nodeName) throws Exception;

    // Open a UDP port for sending and receiving messages.
    public void openPort(int portNumber) throws Exception;


    /*
     * These methods query and change how the network is used.
     */

    // Handle all incoming messages.
    // If you wait for more than delay milliseconds and
    // there are no new incoming messages return.
    // If delay is zero then wait for an unlimited amount of time.
    public void handleIncomingMessages(int delay) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    // Handles any messages that have arrived.
    public boolean isActive(String nodeName) throws Exception;

    // You need to keep a stack of nodes that are used to relay messages.
    // The base of the stack is the first node to be used as a relay.
    // The first node must relay to the second node and so on.

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void pushRelay(String nodeName) throws Exception;

    // Pops the top entry from the stack of nodes used for relaying.
    // No effect if the stack is empty
    public void popRelay() throws Exception;


    /*
     * These methods provide access to the basic functionality of
     * CRN-25 network.
     */

    // Checks if there is an entry in the network with the given key.
    // Handles any messages that have arrived.
    public boolean exists(String key) throws Exception;

    // Reads the entry stored in the network for key.
    // If there is a value, return it.
    // If there isn't a value, return null.
    // Handles any messages that have arrived.
    public String read(String key) throws Exception;

    // Sets key to be value.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean write(String key, String value) throws Exception;

    // If key is set to currentValue change it to newValue.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Complete this!

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private final Map<String, String> dataStore = new HashMap<>();
    private final Map<String, String> addressStore = new HashMap<>();
    private final Stack<String> relayStack = new Stack<>();

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
        addressStore.put(nodeName, "127.0.0.1:" + port); // Store own address
        System.out.println("Node set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
        System.out.println("Node " + nodeName + " listening on port " + port);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println("Received: " + message + " from " + packet.getAddress());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException ignored) {
        }
    }

    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        if (message.trim().isEmpty()) {
            sendResponse("ERROR Empty message", sender, senderPort);
            return;
        }

        String processedMessage = message.startsWith("*") ? message.substring(2) : message;
        String[] parts = processedMessage.split(" ", 3);
        if (parts.length < 2) {
            sendResponse("ERROR Malformed request", sender, senderPort);
            return;
        }

        String transactionId = parts[0];
        String command = parts[1];
        String payload = parts.length > 2 ? parts[2] : "";

        switch (command) {
            case "G": handleNameRequest(transactionId, sender, senderPort); break;
            case "E": handleExistsRequest(transactionId, payload, sender, senderPort); break;
            case "R": handleReadRequest(transactionId, payload, sender, senderPort); break;
            case "W": handleWriteRequest(transactionId, payload, sender, senderPort); break;
            case "C": handleCASRequest(transactionId, payload, sender, senderPort); break;
            case "N": handleNearestRequest(transactionId, payload, sender, senderPort); break;
            case "V": handleRelayRequest(transactionId, payload, sender, senderPort); break;
            default: sendResponse(transactionId + " ERROR Unknown command", sender, senderPort); break;
        }
    }

    private void handleNameRequest(String transactionId, InetAddress sender, int senderPort) throws Exception {
        sendResponse(transactionId + " H " + nodeName, sender, senderPort);
    }

    private void handleExistsRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        boolean exists = dataStore.containsKey(key) || addressStore.containsKey(key);
        sendResponse(transactionId + " F " + (exists ? "Y" : "N"), sender, senderPort);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress sender, int senderPort) throws Exception {
        String value = dataStore.getOrDefault(key, addressStore.getOrDefault(key, "")); // Return empty string if not found
        sendResponse(transactionId + " S " + (value.isEmpty() ? "N" : "Y") + " 0 " + value, sender, senderPort);
    }

    private void handleWriteRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " X X", sender, senderPort);
            return;
        }
        dataStore.put(parts[0], parts[1]);
        sendResponse(transactionId + " X A", sender, senderPort);
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length != 3) {
            sendResponse(transactionId + " D X", sender, senderPort);
            return;
        }
        boolean success = dataStore.containsKey(parts[0]) && dataStore.get(parts[0]).equals(parts[1]);
        if (success) {
            dataStore.put(parts[0], parts[2]);
        }
        sendResponse(transactionId + " D " + (success ? "R" : "N"), sender, senderPort);
    }

    private void handleNearestRequest(String transactionId, String hash, InetAddress sender, int senderPort) throws Exception {
        String response = transactionId + " O ";
        String[] nearest = findNearest(hash);
        for (String address : nearest) {
            response += "0 " + address + " ";
        }
        sendResponse(response, sender, senderPort);
    }

    private void handleRelayRequest(String transactionId, String payload, InetAddress sender, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length != 2) {
            sendResponse(transactionId + " ERROR Relay request malformed", sender, senderPort);
            return;
        }
        String nextNodeName = parts[0];
        String relayedMessage = parts[1];
        String nextNodeAddress = addressStore.get(nextNodeName);
        if (nextNodeAddress != null) {
            String[] addressParts = nextNodeAddress.split(":");
            sendUDP(relayedMessage, InetAddress.getByName(addressParts[0]), Integer.parseInt(addressParts[1]));
        }
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    private String[] findNearest(String hash) {
        // Simple implementation: returns all known addresses.
        return addressStore.values().toArray(new String[0]);
    }

    public boolean isActive(String nodeName) {
        return addressStore.containsKey(nodeName);
    }

    public void pushRelay(String nodeName) {
        relayStack.push(nodeName);
    }

    public void popRelay() {
        if (!relayStack.isEmpty()) relayStack.pop();
    }

    public boolean exists(String key) {
        return dataStore.containsKey(key) || addressStore.containsKey(key);
    }

    public String read(String key) {
        return dataStore.getOrDefault(key, ""); // Return empty string if not found
    }

    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    public boolean CAS(String key, String currentValue, String newValue) {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    private void sendUDP(String message, InetAddress address, int port) throws Exception {
        byte[] data = message.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }
}

