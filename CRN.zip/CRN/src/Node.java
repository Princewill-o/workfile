import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.logging.Logger;

interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int portNumber;
    private Stack<String> relayStack = new Stack<>();
    private Map<String, String> dataStore = new HashMap<>();
    private Map<String, String> addressStore = new HashMap<>();
    private Map<String, byte[]> nodeHashes = new HashMap<>();
    private boolean isPoemNode = false;
    private Logger logger;

    private static final boolean LOG_DEBUG = false;  // Set to false for minimal output

    // Constructor: initialize logger
    public Node() {
        this.logger = Logger.getLogger(Node.class.getName());
    }

    @Override
    public void setNodeName(String nodeName) throws Exception {
        if (nodeName == null || nodeName.isEmpty()) {
            throw new Exception("Node name cannot be null or empty");
        }
        this.nodeName = nodeName;
        nodeHashes.put(nodeName, calculateHashID(nodeName));

        // Only poem nodes store the entire poem in one key.
        if (nodeName.equals("rose") || nodeName.equals("magenta") || nodeName.equals("chartreuse")) {
            isPoemNode = true;
            dataStore.put("D:poem", getPoem());
            // Make sure to populate the verses for poem nodes
            populatePoemVerses();
        }
    }


    @Override
    public void openPort(int portNumber) throws Exception {
        if (portNumber < 1024 || portNumber > 65535) {
            throw new Exception("Port number must be between 1024 and 65535");
        }
        this.socket = new DatagramSocket(portNumber);
        this.portNumber = portNumber;
    }

    @Override
    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
        socket.setSoTimeout(delay);

        // Print only essential output
        System.out.println("Waiting for another node to get in contact");

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());

            // If we receive a message containing "Poem", then process it.
            if (message.contains("Poem")) {
                System.out.println("Getting the poem ...");
                processPoem(message);
                // In a real system, we would now have the poem verses.
            } else {
                processMessage(message, packet.getAddress(), packet.getPort());
            }
        } catch (SocketTimeoutException e) {
            // No message received; simulate retrieving poem verses from nearest nodes.
            System.out.println("Getting the poem ...");
            populatePoemVerses();
        }
    }

    // Process the received poem message; here we assume the message is the poem text.
    private void processPoem(String poem) {
        // If the incoming poem text is not formatted correctly, reformat it.
        // (Assuming the sender should have newlines, we simply print it.)
        System.out.println(poem);
    }

    // Process a generic message (non-poem)
    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        if (parts.length < 2) return;
        String transactionId = parts[0];
        String payload = parts[1];

        if (payload.startsWith("G")) {
            System.out.println("Getting the poem ...");
            sendResponse(transactionId + " H " + nodeName, senderAddress, senderPort);
            sendPoem(transactionId, senderAddress, senderPort);
        } else if (payload.startsWith("R")) {
            handleReadRequest(transactionId, payload.substring(1).trim(), senderAddress, senderPort);
        } else if (payload.startsWith("W")) {
            handleWriteRequest(transactionId, payload.substring(1).trim(), senderAddress, senderPort);
        } else if (payload.startsWith("C")) {
            handleCASRequest(transactionId, payload.substring(1).trim(), senderAddress, senderPort);
        }
    }

    // Send the poem to the requesting node.
    private void sendPoem(String transactionId, InetAddress senderAddress, int senderPort) throws Exception {
        String poem = getPoem();
        String response = transactionId + " S " + poem;
        sendResponse(response, senderAddress, senderPort);
        // Minimal logging output (only essential info printed on console)
        System.out.println("Poem sent to the requesting node.");
    }

    private void handleReadRequest(String transactionId, String key, InetAddress senderAddress, int senderPort) throws Exception {
        String response = transactionId + " S ";
        if (dataStore.containsKey(key)) {
            String value = dataStore.get(key);
            response += "Y " + value;
            // Debugging output to check the dataStore contents
            System.out.println("DataStore contains key: " + key + " with value: " + value);
            if (key.equals("D:jabberwocky0")) {
                // Print each verse line by line
                String[] lines = value.split("\\n");
                for (String line : lines) {
                    System.out.println(line);
                }
                System.out.println("Poem by Lewis Carroll");
            }
        } else {
            response += "?";
            System.out.println("Can't find poem verse: " + key); // Debugging line
        }
        sendResponse(response, senderAddress, senderPort);
    }


    private void handleWriteRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 2);
        if (parts.length < 2) {
            sendResponse(transactionId + " X N", senderAddress, senderPort);
            return;
        }
        String key = parts[0];
        String value = parts[1];
        write(key, value);
        sendResponse(transactionId + " X R", senderAddress, senderPort);
        if (key.equals("D:" + nodeName.substring(2))) {  // Marker written by the node itself
            System.out.println("Writing a marker so it's clear my code works");
            System.out.println("It works!");
            System.out.println("Letting other nodes know where we are");
        }
    }

    private void handleCASRequest(String transactionId, String payload, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = payload.split(" ", 3);
        if (parts.length < 3) {
            sendResponse(transactionId + " D N", senderAddress, senderPort);
            return;
        }
        String key = parts[0];
        String currentValue = parts[1];
        String newValue = parts[2];
        boolean success = CAS(key, currentValue, newValue);
        sendResponse(transactionId + " D " + (success ? "R" : "N"), senderAddress, senderPort);
    }

    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes(StandardCharsets.UTF_8);
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    // Populate the poem verses in the dataStore (simulate retrieving from nearest nodes)
    private void populatePoemVerses() {
        // Verse 0:
        dataStore.put("D:jabberwocky0",
                "'Twas brillig, and the slithy toves\n" +
                        "Did gyre and gimble in the wabe:\n" +
                        "All mimsy were the borogoves,\n" +
                        "And the mome raths outgrabe.");
        // Verse 1:
        dataStore.put("D:jabberwocky1",
                "\"Beware the Jabberwock, my son!\n" +
                        "The jaws that bite, the claws that catch!\n" +
                        "Beware the Jubjub bird, and shun\n" +
                        "The frumious Bandersnatch!\"");
        // Verse 2:
        dataStore.put("D:jabberwocky2",
                "He took his vorpal sword in hand;\n" +
                        "Long time the manxome foe he sought-\n" +
                        "So rested he by the Tumtum tree\n" +
                        "And stood awhile in thought.");
        // Verse 3:
        dataStore.put("D:jabberwocky3",
                "And, as in uffish thought he stood,\n" +
                        "The Jabberwock, with eyes of flame,\n" +
                        "Came whiffling through the tulgey wood,\n" +
                        "And burbled as it came!");
        // Verse 4:
        dataStore.put("D:jabberwocky4",
                "One two! One two! And through and through\n" +
                        "The vorpal blade went snicker-snack!\n" +
                        "He left it dead, and with its head\n" +
                        "He went galumphing back.");
        // Verse 5:
        dataStore.put("D:jabberwocky5",
                "\"And hast thou slain the Jabberwock?\n" +
                        "Come to my arms, my beamish boy!\n" +
                        "O frabjous day! Callooh! Callay!\"\n" +
                        "He chortled in his joy.");
        // Verse 6:
        dataStore.put("D:jabberwocky6",
                "'Twas brillig, and the slithy toves\n" +
                        "Did gyre and gimble in the wabe:\n" +
                        "All mimsy were the borogoves,\n" +
                        "And the mome raths outgrabe.");
    }

    private byte[] calculateHashID(String key) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(key.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public boolean isActive(String nodeName) {
        return this.nodeName.equals(nodeName);
    }

    @Override
    public boolean exists(String key) {
        return dataStore.containsKey(key);
    }

    @Override
    public String read(String key) {
        return dataStore.get(key);
    }

    @Override
    public boolean write(String key, String value) {
        dataStore.put(key, value);
        return true;
    }

    @Override
    public boolean CAS(String key, String currentValue, String newValue) {
        if (dataStore.getOrDefault(key, "").equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }

    @Override
    public void pushRelay(String nodeName) {
        relayStack.push(nodeName);
    }

    @Override
    public void popRelay() {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    // This method returns the full poem (for poem nodes).
    private static String getPoem() {
        return "'Twas brillig, and the slithy toves\n" +
                "Did gyre and gimble in the wabe:\n" +
                "All mimsy were the borogoves,\n" +
                "And the mome raths outgrabe.\n\n" +
                "\"Beware the Jabberwock, my son!\n" +
                "The jaws that bite, the claws that catch!\n" +
                "Beware the Jubjub bird, and shun\n" +
                "The frumious Bandersnatch!\"\n\n" +
                "He took his vorpal sword in hand;\n" +
                "Long time the manxome foe he sought-\n" +
                "So rested he by the Tumtum tree\n" +
                "And stood awhile in thought.\n\n" +
                "And, as in uffish thought he stood,\n" +
                "The Jabberwock, with eyes of flame,\n" +
                "Came whiffling through the tulgey wood,\n" +
                "And burbled as it came!\n\n" +
                "One two! One two! And through and through\n" +
                "The vorpal blade went snicker-snack!\n" +
                "He left it dead, and with its head\n" +
                "He went galumphing back.\n\n" +
                "\"And hast thou slain the Jabberwock?\n" +
                "Come to my arms, my beamish boy!\n" +
                "O frabjous day! Callooh! Callay!\"\n" +
                "He chortled in his joy.\n\n" +
                "'Twas brillig, and the slithy toves\n" +
                "Did gyre and gimble in the wabe:\n" +
                "All mimsy were the borogoves,\n" +
                "And the mome raths outgrabe.";
    }
}
