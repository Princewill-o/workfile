import java.io.IOException;
import java.net.*;
import java.security.MessageDigest;
import java.util.*;

interface NodeInterface {

    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    // Set the name of the node.
    public void setNodeName(String identifier) throws Exception;

    // Open a UDP port for sending and receiving messages.
    public void openPort(int port) throws Exception;

    /*
     * These methods query and change how the network is used.
     */

    // Handle all incoming messages.
    // If you wait for more than delay miliseconds and
    // there are no new incoming messages return.
    // If delay is zero then wait for an unlimited amount of time.
    public void handleIncomingMessages(int waitTime) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    // Handles any messages that have arrived.
    public boolean isNodeOperational(String nodeIdentifier) throws Exception;

    // You need to keep a stack of nodes that are used to relay messages.
    // The base of the stack is the first node to be used as a relay.
    // The first node must relay to the second node and so on.

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void addRelayNode(String nodeIdentifier) throws Exception;

    // Pops the top entry from the stack of nodes used for relaying.
    // No effect if the stack is empty
    public void removeRelayNode() throws Exception;

    /*
     * These methods provide access to the basic functionality of
     * CRN-25 network.
     */

    // Checks if there is an entry in the network with the given key.
    // Handles any messages that have arrived.
    public boolean keyExists(String key) throws Exception;

    // Reads the entry stored in the network for key.
    // If there is a value, return it.
    // If there isn't a value, return null.
    // Handles any messages that have arrived.
    public String read(String key) throws Exception;

    // Sets key to be value.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean write(String key, String value) throws Exception;

    // If key is set to currentValue change it to newValue.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean compareAndSet(String key, String oldValue, String newValue) throws Exception;
}

public class Node implements NodeInterface {

    private String nodeIdentifier;
    private DatagramSocket networkSocket;
    private final Map<String, String> storage = new HashMap<>();
    private final Stack<String> relayChain = new Stack<>();
    private final Map<String, InetSocketAddress> peerList = new HashMap<>();
    private final Map<String, String> nearbyReplies = new HashMap<>();
    private final Set<String> processedTxns = Collections.newSetFromMap(new LinkedHashMap<>() {
        protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
            return size() > 1000;
        }
    });
    private final Random randGen = new Random();
    private String recentValue = null;
    private boolean recentCheck = false;
    private final boolean debugEnabled = false;
    private Thread receiverThread;

    @Override
    public void setNodeName(String identifier) {
        if (!identifier.startsWith("N:")) throw new IllegalArgumentException("Identifier must begin with 'N:'");
        this.nodeIdentifier = identifier;
    }

    @Override
    public void openPort(int port) throws Exception {
        networkSocket = new DatagramSocket(port);
        if (debugEnabled) System.out.println("Monitoring port " + port);
        initiateReceiver();
    }

    @Override
    public void handleIncomingMessages(int waitTime) throws Exception {
        networkSocket.setSoTimeout(100);
        byte[] dataBuffer = new byte[2048];
        long beginTime = System.currentTimeMillis();

        while (waitTime == 0 || System.currentTimeMillis() - beginTime < waitTime) {
            DatagramPacket incomingPacket = new DatagramPacket(dataBuffer, dataBuffer.length);
            try {
                networkSocket.receive(incomingPacket);
                String content = new String(incomingPacket.getData(), 0, incomingPacket.getLength());
                if (debugEnabled) System.out.println("Arrived: " + content);
                handleMessage(content, incomingPacket.getAddress(), incomingPacket.getPort());
            } catch (SocketTimeoutException ignored) {}
        }
    }

    private void handleMessage(String message, InetAddress origin, int originPort) {
        try {
            if (randGen.nextDouble() < 0.1) return;

            String[] components = message.trim().split(" ", 3);
            if (components.length < 2) return;

            String txId = components[0], command = components[1];
            if (processedTxns.contains(txId)) return;
            processedTxns.add(txId);

            switch (command) {
                case "G" -> sendResponse(origin, originPort, txId + " H " + encapsulate(nodeIdentifier));
                case "H" -> {
                    if (components.length > 2) {
                        String peerId = decapsulate(components[2]);
                        if (peerId != null) {
                            peerList.put(peerId, new InetSocketAddress(origin, originPort));
                        }
                    }
                }
                case "W" -> {
                    String[] keyValPair = parsePair(components.length > 2 ? components[2] : "");
                    if (keyValPair != null) {
                        storage.put(keyValPair[0], keyValPair[1]);
                        if (keyValPair[0].startsWith("N:")) {
                            try {
                                String[] addressParts = keyValPair[1].split(":");
                                if (addressParts.length == 2) {
                                    peerList.put(keyValPair[0], new InetSocketAddress(addressParts[0], Integer.parseInt(addressParts[1])));
                                }
                            } catch (Exception ignored) {}
                        }
                        sendResponse(origin, originPort, txId + " X A");
                    }
                }
                case "R" -> {
                    String key = decapsulate(components.length > 2 ? components[2] : "");
                    if (key != null) {
                        String value = storage.get(key);
                        sendResponse(origin, originPort, txId + (value != null ? " S Y " + encapsulate(value) : " S N "));
                    }
                }
                case "S" -> {
                    if (components.length > 2) {
                        String[] replyParts = components[2].split(" ", 2);
                        if (replyParts[0].equals("Y") && replyParts.length > 1)
                            recentValue = decapsulate(replyParts[1]);
                    }
                }
                case "E" -> {
                    String key = decapsulate(components.length > 2 ? components[2] : "");
                    boolean present = key != null && storage.containsKey(key);
                    sendResponse(origin, originPort, txId + " F " + (present ? "Y" : "N"));
                }
                case "F" -> {
                    if (components.length > 2 && components[2].trim().equals("Y")) recentCheck = true;
                }
                case "N" -> {
                    if (components.length > 2) {
                        String hashValue = components[2].trim();
                        List<String> potentialPeers = new ArrayList<>(peerList.keySet());
                        potentialPeers.removeIf(n -> !n.startsWith("N:"));
                        potentialPeers.sort(Comparator.comparingInt(n -> {
                            try {
                                return measureDistance(hashValue, generateHash(n));
                            } catch (Exception e) {
                                return Integer.MAX_VALUE;
                            }
                        }));
                        StringBuilder replyBuilder = new StringBuilder(txId + " O");
                        for (int i = 0; i < Math.min(3, potentialPeers.size()); i++) {
                            String peer = potentialPeers.get(i);
                            InetSocketAddress peerAddress = peerList.get(peer);
                            if (peerAddress != null) {
                                String addrStr = peerAddress.getAddress().getHostAddress() + ":" + peerAddress.getPort();
                                replyBuilder.append(" ").append(encapsulate(peer)).append(encapsulate(addrStr));
                            }
                        }
                        sendResponse(origin, originPort, replyBuilder.toString());
                    }
                }
                case "O" -> {
                    if (components.length > 2) nearbyReplies.put(txId, components[2]);
                }
                case "V" -> {
                    if (components.length > 2) {
                        String[] subParts = components[2].split(" ", 2);
                        if (subParts.length == 2) {
                            String nextHop = decapsulate(subParts[0]);
                            String messageBody = subParts[1];
                            if (nextHop != null) {
                                if (nextHop.equals(nodeIdentifier)) {
                                    handleMessage(messageBody, origin, originPort);
                                } else if (peerList.containsKey(nextHop)) {
                                    InetSocketAddress relayTarget = peerList.get(nextHop);
                                    String forwarded = "V " + encapsulate(nextHop) + messageBody;
                                    sendResponse(relayTarget.getAddress(), relayTarget.getPort(), forwarded);
                                }
                            }
                        }
                    }
                }
                case "I" -> {
                    // Ping or heartbeat handler (optional)
                }
            }
        } catch (Exception e) {
            if (debugEnabled) System.err.println("Message processing failed: " + e.getMessage());
        }
    }

    private void sendResponse(InetAddress destination, int port, String response) {
        try {
            for (int i = relayChain.size() - 1; i >= 0; i--) {
                response = "V " + encapsulate(relayChain.get(i)) + response;
            }
            byte[] payload = response.getBytes();
            DatagramPacket outgoing = new DatagramPacket(payload, payload.length, destination, port);
            networkSocket.send(outgoing);
            if (debugEnabled) System.out.println("Transmitted: " + response);
        } catch (IOException e) {
            if (debugEnabled) System.err.println("Sending failed: " + e.getMessage());
        }
    }

    private String encapsulate(String text) {
        long spaceCount = text.chars().filter(ch -> ch == ' ').count();
        return spaceCount + " " + text + " ";
    }

    private String decapsulate(String text) {
        int spacePos = text.indexOf(' ');
        return (spacePos != -1 && text.length() > spacePos + 1) ? text.substring(spacePos + 1, text.length() - 1) : null;
    }

    private String[] parsePair(String input) {
        try {
            String[] segments = input.trim().split(" ", 4);
            if (segments.length == 4) return new String[]{segments[1], segments[3]};
        } catch (Exception ignored) {}
        return null;
    }

    @Override
    public boolean isNodeOperational(String nodeIdentifier) {
        return peerList.containsKey(nodeIdentifier);
    }

    @Override
    public void addRelayNode(String nodeIdentifier) {
        relayChain.push(nodeIdentifier);
    }

    @Override
    public void removeRelayNode() {
        if (!relayChain.isEmpty()) relayChain.pop();
    }

    @Override
    public boolean keyExists(String key) throws Exception {
        return performSearch(key, true) != null;
    }

    @Override
    public String read(String key) throws Exception {
        return performSearch(key, false);
    }

    private String performSearch(String key, boolean onlyCheck) throws Exception {
        if (storage.containsKey(key)) return storage.get(key);

        String keyHash = generateHash(key);
        Set<String> explored = new HashSet<>();
        Queue<String> pendingPeers = new LinkedList<>(peerList.keySet());

        if (peerList.isEmpty()) {
            peerList.put("N:azure", new InetSocketAddress("10.200.51.19", 20114));
            pendingPeers.add("N:azure");
        }

        while (!pendingPeers.isEmpty()) {
            String currentPeer = pendingPeers.poll();
            if (explored.contains(currentPeer) || !peerList.containsKey(currentPeer)) continue;
            explored.add(currentPeer);

            InetSocketAddress peerAddr = peerList.get(currentPeer);
            String transactionId = createTxId();
            if (onlyCheck) {
                recentCheck = false;
                sendResponse(peerAddr.getAddress(), peerAddr.getPort(), transactionId + " E " + encapsulate(key));
            } else {
                recentValue = null;
                sendResponse(peerAddr.getAddress(), peerAddr.getPort(), transactionId + " R " + encapsulate(key));
            }

            long startTime = System.currentTimeMillis();
            while (System.currentTimeMillis() - startTime < 1000) {
                handleIncomingMessages(100);
                if ((onlyCheck && recentCheck) || (!onlyCheck && recentValue != null)) {
                    return onlyCheck ? "YES" : recentValue;
                }
            }

            String nearbyTxId = createTxId();
            sendResponse(peerAddr.getAddress(), peerAddr.getPort(), nearbyTxId + " N " + keyHash);

            long waitStart = System.currentTimeMillis();
            while (!nearbyReplies.containsKey(nearbyTxId) && System.currentTimeMillis() - waitStart < 1000) {
                handleIncomingMessages(100);
            }

            String replyData = nearbyReplies.get(nearbyTxId);
            if (replyData == null) continue;

            String[] peerDetails = replyData.trim().split(" ");
            for (int i = 0; i + 3 < peerDetails.length; i += 4) {
                String peerName = peerDetails[i + 1];
                String addressStr = peerDetails[i + 3];
                if (peerName.startsWith("N:") && addressStr.contains(":")) {
                    String[] ipAndPort = addressStr.split(":");
                    InetSocketAddress newPeer = new InetSocketAddress(ipAndPort[0], Integer.parseInt(ipAndPort[1]));
                    peerList.put(peerName, newPeer);
                    if (!explored.contains(peerName)) pendingPeers.add(peerName);
                }
            }
        }

        return null;
    }

    @Override
    public boolean write(String key, String value) {
        storage.put(key, value);
        return true;
    }

    @Override
    public boolean compareAndSet(String key, String oldValue, String newValue) {
        if (!storage.containsKey(key)) {
            storage.put(key, newValue);
            return true;
        } else if (storage.get(key).equals(oldValue)) {
            storage.put(key, newValue);
            return true;
        }
        return false;
    }

    private String generateHash(String data) throws Exception {
        MessageDigest hasher = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = hasher.digest(data.getBytes("UTF-8"));
        StringBuilder hashStr = new StringBuilder();
        for (byte b : hashBytes) hashStr.append(String.format("%02x", b));
        return hashStr.toString();
    }

    private int measureDistance(String hashA, String hashB) {
        for (int i = 0; i < hashA.length(); i++) {
            int digitA = Integer.parseInt(hashA.substring(i, i + 1), 16);
            int digitB = Integer.parseInt(hashB.substring(i, i + 1), 16);
            int difference = digitA ^ digitB;
            for (int bit = 3; bit >= 0; bit--) {
                if (((difference >> bit) & 1) == 1) return i * 4 + (3 - bit);
            }
        }
        return 256;
    }

    private String createTxId() {
        return "" + (char) ('A' + randGen.nextInt(26)) + (char) ('A' + randGen.nextInt(26));
    }

    public Set<String> listAllPeers() {
        return peerList.keySet();
    }

    private void initiateReceiver() {
        receiverThread = new Thread(() -> {
            try {
                while (true) handleIncomingMessages(0);
            } catch (Exception e) {
                if (debugEnabled) System.err.println("Receiver stopped: " + e.getMessage());
            }
        });
        receiverThread.setDaemon(true);
        receiverThread.start();
    }
}