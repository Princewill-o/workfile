import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.LinkedList;
import java.util.Queue;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// DO NOT EDIT starts
interface NodeInterface {
    public void setNodeName(String nodeName) throws Exception;
    public void openPort(int portNumber) throws Exception;
    public void handleIncomingMessages(int delay) throws Exception;
    public boolean isActive(String nodeName) throws Exception;
    public void pushRelay(String nodeName) throws Exception;
    public void popRelay() throws Exception;
    public boolean exists(String key) throws Exception;
    public String read(String key) throws Exception;
    public boolean write(String key, String value) throws Exception;
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;
}
// DO NOT EDIT ends

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private Map<String, String> keyValueStore = new HashMap<>();
    private Queue<DatagramPacket> messageQueue = new LinkedList<>();
    private boolean debugMode = false;

    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
        log("Node name set to: " + nodeName);
    }

    public void openPort(int portNumber) throws Exception {
        socket = new DatagramSocket(portNumber);
        log("Opened UDP port: " + portNumber);
    }

    public void handleIncomingMessages(int delay) throws Exception {
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        while (true) {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            log("Received message: " + message);
            processMessage(message, packet.getAddress(), packet.getPort());
            // Add delay handling if necessary
        }
    }

    private void processMessage(String message, InetAddress senderAddress, int senderPort) throws Exception {
        String[] parts = message.split(" ");
        String transactionId = parts[0];
        char command = parts[1].charAt(0);

        switch (command) {
            case 'G':
                sendNameResponse(transactionId, senderAddress, senderPort);
                break;
            case 'N':
                handleNearestRequest(transactionId, parts[2], senderAddress, senderPort);
                break;
            case 'E':
                handleKeyExistenceRequest(transactionId, parts[2], senderAddress, senderPort);
                break;
            case 'R':
                handleReadRequest(transactionId, parts[2], senderAddress, senderPort);
                break;
            case 'W':
                handleWriteRequest(transactionId, parts[2], parts[3], senderAddress, senderPort);
                break;
            case 'C':
                handleCASRequest(transactionId, parts[2], parts[3], parts[4], senderAddress, senderPort);
                break;
            case 'V':
                handleRelayMessage(parts[2], message.substring(parts[2].length() + 3), senderAddress, senderPort);
                break;
            default:
                log("Unknown command: " + command);
        }
    }

    private void sendNameResponse(String transactionId, InetAddress address, int port) throws Exception {
        String response = transactionId + " H " + nodeName + " ";
        sendMessage(response, address, port);
    }

    private void handleNearestRequest(String transactionId, String hashID, InetAddress address, int port) throws Exception {
        // Find the nearest nodes and respond with their address key/value pairs
        String response = transactionId + " O "; // Placeholder for nearest nodes
        sendMessage(response, address, port);
    }

    private void handleKeyExistenceRequest(String transactionId, String key, InetAddress address, int port) throws Exception {
        boolean exists = keyValueStore.containsKey(key);
        char responseChar = exists ? 'Y' : 'N'; // Adjust based on conditions
        String response = transactionId + " F " + responseChar + " ";
        sendMessage(response, address, port);
    }

    private void handleReadRequest(String transactionId, String key, InetAddress address, int port) throws Exception {
        String value = keyValueStore.get(key);
        char responseChar = value != null ? 'Y' : 'N';
        String response = transactionId + " S " + responseChar + " " + (value != null ? value : "") + " ";
        sendMessage(response, address, port);
    }

    private void handleWriteRequest(String transactionId, String key, String value, InetAddress address, int port) throws Exception {
        // Logic to handle writing key/value pairs
        keyValueStore.put(key, value);
        String response = transactionId + " X R "; // Assuming write was successful
        sendMessage(response, address, port);
    }

    private void handleCASRequest(String transactionId, String key, String currentValue, String newValue, InetAddress address, int port) throws Exception {
        // Logic for compare-and-swap
        String storedValue = keyValueStore.get(key);
        char responseChar;
        if (storedValue != null && storedValue.equals(currentValue)) {
            keyValueStore.put(key, newValue);
            responseChar = 'R';
        } else {
            responseChar = 'N'; // or 'A'/'X' based on conditions
        }
        String response = transactionId + " D " + responseChar + " ";
        sendMessage(response, address, port);
    }

    private void handleRelayMessage(String targetNode, String message, InetAddress address, int port) throws Exception {
        // Forward the message to the target node
        sendMessage(message, address, port); // Modify to send to the correct target
    }

    private void sendMessage(String message, InetAddress address, int port) throws Exception {
        byte[] buffer = message.getBytes();
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, port);
        socket.send(packet);
        log("Sent message: " + message);
    }

    public boolean isActive(String nodeName) throws Exception {
        // Implement logic to check if a node is active
        return true; // Placeholder
    }

    public void pushRelay(String nodeName) throws Exception {
        // Logic to manage relay nodes
    }

    public void popRelay() throws Exception {
        // Logic to remove relay nodes
    }

    public boolean exists(String key) throws Exception {
        return keyValueStore.containsKey(key);
    }

    public String read(String key) throws Exception {
        return keyValueStore.get(key);
    }

    public boolean write(String key, String value) throws Exception {
        keyValueStore.put(key, value);
        return true; // Assuming success
    }

    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        String storedValue = keyValueStore.get(key);
        if (storedValue != null && storedValue.equals(currentValue)) {
            keyValueStore.put(key, newValue);
            return true;
        }
        return false;
    }

    private void log(String message) {
        if (debugMode) {
            System.out.println(message);
        }
    }

    private String sha256(String input) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(input.getBytes());
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
