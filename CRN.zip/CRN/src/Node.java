// IN2011 Computer Networks
// Coursework 2024/2025
// 230007985
// Submission by
// Princewill Okube
// 2
// princewill.okube@city.ac.uk


// DO NOT EDIT starts
// This gives the interface that your code must implement.
// These descriptions are intended to help you understand how the interface
// will be used. See the RFC for how the protocol works.

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

interface NodeInterface {

    /* These methods configure your node.
     * They must both be called once after the node has been created but
     * before it is used. */

    // Set the name of the node.
    public void setNodeName(String nodeName) throws Exception;

    // Open a UDP port for sending and receiving messages.
    public void openPort(int portNumber) throws Exception;


    /*
     * These methods query and change how the network is used.
     */

    // Handle all incoming messages.
    // If you wait for more than delay milliseconds and
    // there are no new incoming messages return.
    // If delay is zero then wait for an unlimited amount of time.
    public void handleIncomingMessages(int delay) throws Exception;

    // Determines if a node can be contacted and is responding correctly.
    // Handles any messages that have arrived.
    public boolean isActive(String nodeName) throws Exception;

    // You need to keep a stack of nodes that are used to relay messages.
    // The base of the stack is the first node to be used as a relay.
    // The first node must relay to the second node and so on.

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void pushRelay(String nodeName) throws Exception;

    // Pops the top entry from the stack of nodes used for relaying.
    // No effect if the stack is empty
    public void popRelay() throws Exception;


    /*
     * These methods provide access to the basic functionality of
     * CRN-25 network.
     */

    // Checks if there is an entry in the network with the given key.
    // Handles any messages that have arrived.
    public boolean exists(String key) throws Exception;

    // Reads the entry stored in the network for key.
    // If there is a value, return it.
    // If there isn't a value, return null.
    // Handles any messages that have arrived.
    public String read(String key) throws Exception;

    // Sets key to be value.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean write(String key, String value) throws Exception;

    // If key is set to currentValue change it to newValue.
    // Returns true if it worked, false if it didn't.
    // Handles any messages that have arrived.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception;

}
// DO NOT EDIT ends

// Complete this!

public class Node implements NodeInterface {
    private String nodeName;
    private DatagramSocket socket;
    private int port;
    private Map<String, String> dataStore = new HashMap<>();
    private Stack<String> relayStack = new Stack<>();

    // Set the name of the node.
    public void setNodeName(String nodeName) throws Exception {
        this.nodeName = nodeName;
    }

    // Open a UDP port for sending and receiving messages.
    public void openPort(int portNumber) throws Exception {
        this.port = portNumber;
        this.socket = new DatagramSocket(port);
    }

    // Handle all incoming messages.
    public void handleIncomingMessages(int delay) throws Exception {
        socket.setSoTimeout(delay > 0 ? delay : 0);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            socket.receive(packet);
            String message = new String(packet.getData(), 0, packet.getLength());
            processMessage(message, packet.getAddress(), packet.getPort());
        } catch (SocketTimeoutException ignored) {
        }
    }

    // Process incoming messages based on the command.
    private void processMessage(String message, InetAddress sender, int senderPort) throws Exception {
        String[] parts = message.split(" ", 2);
        String command = parts[0];
        String response = "ERROR";

        switch (command) {
            case "EXISTS":
                response = Boolean.toString(dataStore.containsKey(parts[1]));
                break;
            case "READ":
                response = dataStore.getOrDefault(parts[1], "NULL");
                break;
            case "WRITE":
                String[] keyValue = parts[1].split(" ", 2);
                if (keyValue.length == 2) {
                    dataStore.put(keyValue[0], keyValue[1]);
                    response = "OK";
                }
                break;
            case "CAS":
                String[] casParts = parts[1].split(" ", 3);
                if (casParts.length == 3 && dataStore.containsKey(casParts[0])) {
                    if (dataStore.get(casParts[0]).equals(casParts[1])) {
                        dataStore.put(casParts[0], casParts[2]);
                        response = "OK";
                    } else {
                        response = "FAIL";
                    }
                }
                break;
        }
        sendResponse(response, sender, senderPort);
    }

    // Send the response back to the sender.
    private void sendResponse(String response, InetAddress address, int port) throws Exception {
        byte[] data = response.getBytes();
        DatagramPacket packet = new DatagramPacket(data, data.length, address, port);
        socket.send(packet);
    }

    // Checks if the node is active by sending a UDP message exchange.
    public boolean isActive(String nodeName) throws Exception {
        // Implement logic to check if node is active via UDP message exchange
        return true; // Placeholder, actual logic needs to be implemented.
    }

    // Adds a node name to a stack of nodes used to relay all future messages.
    public void pushRelay(String nodeName) throws Exception {
        relayStack.push(nodeName);
    }

    // Pops the top entry from the stack of nodes used for relaying.
    public void popRelay() throws Exception {
        if (!relayStack.isEmpty()) {
            relayStack.pop();
        }
    }

    // Checks if a key exists in the datastore.
    public boolean exists(String key) throws Exception {
        return dataStore.containsKey(key);
    }

    // Reads the value for a given key.
    public String read(String key) throws Exception {
        return dataStore.getOrDefault(key, null);
    }

    // Writes a value for a given key.
    public boolean write(String key, String value) throws Exception {
        dataStore.put(key, value);
        return true;
    }

    // Performs a compare-and-swap operation for a key.
    public boolean CAS(String key, String currentValue, String newValue) throws Exception {
        if (dataStore.containsKey(key) && dataStore.get(key).equals(currentValue)) {
            dataStore.put(key, newValue);
            return true;
        }
        return false;
    }
}
