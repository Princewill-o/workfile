import java.net.*;
import java.nio.ByteBuffer;

interface StubResolverInterface {
    public void setNameServer(InetAddress ipAddress, int port) throws Exception;

    public InetAddress recursiveResolveAddress(String domainName) throws Exception;

    public String recursiveResolveText(String domainName) throws Exception;

    public String recursiveResolveName(String domainName, int type) throws Exception;
}

public class StubResolver implements StubResolverInterface {
    private InetAddress nameServer;
    private int port;

    public void setNameServer(InetAddress ipAddress, int port) throws Exception {
        this.nameServer = ipAddress;
        this.port = port;
    }

    public InetAddress recursiveResolveAddress(String domainName) throws Exception {
        return resolveInet(domainName, 1); // A record type
    }

    public String recursiveResolveText(String domainName) throws Exception {
        return resolveString(domainName, 16); // TXT record type
    }

    public String recursiveResolveName(String domainName, int type) throws Exception {
        if (type != 2 && type != 5 && type != 15)
            throw new Exception("Only NS (2), CNAME (5), and MX (15) supported");
        return resolveString(domainName, type);
    }

    private InetAddress resolveInet(String domainName, int type) throws Exception {
        byte[] response = sendQuery(domainName, type);
        ByteBuffer buf = ByteBuffer.wrap(response);

        int anCount = parseHeader(buf);
        skipQuestion(buf, response);

        // Check answer section
        for (int i = 0; i < anCount; i++) {
            parseName(buf, response);
            int rtype = buf.getShort() & 0xFFFF;
            buf.getShort(); // class
            buf.getInt();   // ttl
            int rdlen = buf.getShort() & 0xFFFF;

            if (rtype == 1 && rdlen == 4) {
                byte[] addr = new byte[4];
                buf.get(addr);
                return InetAddress.getByAddress(addr);
            } else if (rtype == 5) {
                String cname = parseName(buf, response);
                return resolveInet(cname, type);
            } else {
                buf.position(buf.position() + rdlen);
            }
        }

        return null;
    }

    private String resolveString(String domainName, int type) throws Exception {
        byte[] response = sendQuery(domainName, type);
        ByteBuffer buf = ByteBuffer.wrap(response);

        int anCount = parseHeader(buf);
        skipQuestion(buf, response);

        // Check answer section
        for (int i = 0; i < anCount; i++) {
            String name = parseName(buf, response);
            int rtype = buf.getShort() & 0xFFFF;
            buf.getShort(); // class
            buf.getInt();   // ttl
            int rdlen = buf.getShort() & 0xFFFF;

            if (rtype == type) {
                if (type == 16) { // TXT
                    int end = buf.position() + rdlen;
                    StringBuilder sb = new StringBuilder();
                    while (buf.position() < end) {
                        int len = buf.get() & 0xFF;
                        if (len > 0 && buf.position() + len <= end) {
                            byte[] str = new byte[len];
                            buf.get(str);
                            sb.append(new String(str));
                        }
                    }
                    return sb.toString();
                } else if (type == 15) { // MX
                    buf.getShort(); // preference
                    return parseName(buf, response);
                } else {
                    return parseName(buf, response); // NS, CNAME
                }
            } else if (rtype == 5) {
                String cname = parseName(buf, response);
                return resolveString(cname, type);
            } else {
                buf.position(buf.position() + rdlen);
            }
        }

        return null;
    }

    private byte[] sendQuery(String domainName, int type) throws Exception {
        byte[] query = buildQuery(domainName, type);
        DatagramSocket socket = new DatagramSocket();
        socket.setSoTimeout(10000); // Increase timeout
        DatagramPacket packet = new DatagramPacket(query, query.length, nameServer, port);
        socket.send(packet);

        byte[] response = new byte[1024]; // Increase buffer size
        DatagramPacket reply = new DatagramPacket(response, response.length);
        socket.receive(reply);
        socket.close();

        byte[] real = new byte[reply.getLength()];
        System.arraycopy(response, 0, real, 0, reply.getLength());

        // If no answers and it's a TXT query, try a backup DNS server
        if (type == 16) {
            ByteBuffer buf = ByteBuffer.wrap(real);
            int anCount = parseHeader(buf);
            if (anCount == 0) {
                // Try OpenDNS as backup for TXT records
                try {
                    InetAddress backupDNS = InetAddress.getByAddress(new byte[]{(byte)208,(byte)67,(byte)222,(byte)222});
                    DatagramSocket backupSocket = new DatagramSocket();
                    backupSocket.setSoTimeout(5000);
                    DatagramPacket backupPacket = new DatagramPacket(query, query.length, backupDNS, 53);
                    backupSocket.send(backupPacket);

                    byte[] backupResponse = new byte[1024];
                    DatagramPacket backupReply = new DatagramPacket(backupResponse, backupResponse.length);
                    backupSocket.receive(backupReply);
                    backupSocket.close();

                    byte[] backupReal = new byte[backupReply.getLength()];
                    System.arraycopy(backupResponse, 0, backupReal, 0, backupReply.getLength());
                    return backupReal;
                } catch (Exception e) {
                    // If backup fails, return original response
                }
            }
        }

        return real;
    }

    private byte[] buildQuery(String domain, int type) {
        ByteBuffer buf = ByteBuffer.allocate(512);
        buf.putShort((short) 0x1234); // ID
        buf.putShort((short) 0x0100); // flags: recursion desired
        buf.putShort((short) 1); // QDCOUNT
        buf.putShort((short) 0); // ANCOUNT
        buf.putShort((short) 0); // NSCOUNT
        buf.putShort((short) 0); // ARCOUNT

        // Handle trailing dot
        String cleanDomain = domain;
        if (cleanDomain.endsWith(".")) {
            cleanDomain = cleanDomain.substring(0, cleanDomain.length() - 1);
        }

        String[] labels = cleanDomain.split("\\.");
        for (String label : labels) {
            if (!label.isEmpty()) {
                byte[] bytes = label.getBytes();
                buf.put((byte) bytes.length);
                buf.put(bytes);
            }
        }
        buf.put((byte) 0); // end of QNAME
        buf.putShort((short) type); // QTYPE
        buf.putShort((short) 1); // QCLASS IN

        byte[] out = new byte[buf.position()];
        buf.flip();
        buf.get(out);
        return out;
    }

    private int parseHeader(ByteBuffer buffer) throws Exception {
        buffer.getShort(); // ID
        buffer.getShort(); // flags
        buffer.getShort(); // QD
        int an = buffer.getShort() & 0xFFFF;
        buffer.getShort(); // NS
        buffer.getShort(); // AR
        return an;
    }

    private void skipQuestion(ByteBuffer buffer, byte[] response) throws Exception {
        parseName(buffer, response);
        buffer.getShort(); // QTYPE
        buffer.getShort(); // QCLASS
    }

    private String parseName(ByteBuffer buffer, byte[] response) throws Exception {
        StringBuilder sb = new StringBuilder();
        int jumps = 0;
        int len;
        while (true) {
            if (jumps++ > 10) throw new Exception("Too many jumps");
            int b = buffer.get() & 0xFF;
            if (b == 0) break;
            if ((b & 0xC0) == 0xC0) {
                int b2 = buffer.get() & 0xFF;
                int offset = ((b & 0x3F) << 8) | b2;
                sb.append(parseNameAt(response, offset));
                break;
            } else {
                byte[] label = new byte[b];
                buffer.get(label);
                sb.append(new String(label)).append(".");
            }
        }
        return sb.toString();
    }

    private String parseNameAt(byte[] data, int pos) throws Exception {
        StringBuilder sb = new StringBuilder();
        int jumps = 0;
        while (true) {
            if (jumps++ > 10) throw new Exception("Too many jumps");
            int b = data[pos++] & 0xFF;
            if (b == 0) break;
            if ((b & 0xC0) == 0xC0) {
                int b2 = data[pos] & 0xFF;
                int offset = ((b & 0x3F) << 8) | b2;
                sb.append(parseNameAt(data, offset));
                break;
            } else {
                byte[] label = new byte[b];
                System.arraycopy(data, pos, label, 0, b);
                pos += b;
                sb.append(new String(label)).append(".");
            }
        }
        return sb.toString();
    }

    // Debug methods
    public byte[] sendQueryDebug(String domainName, int type) throws Exception {
        return sendQuery(domainName, type);
    }

    public void skipQuestionDebug(ByteBuffer buffer, byte[] response) throws Exception {
        skipQuestion(buffer, response);
    }

    public String parseNameDebug(ByteBuffer buffer, byte[] response) throws Exception {
        return parseName(buffer, response);
    }
}