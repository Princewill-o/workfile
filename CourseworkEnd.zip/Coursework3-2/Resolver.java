// IN2011 Computer Networks
// Coursework 2024/2025 Resit
//
// Submission by
// [Your Name]
// [Your Student ID]
// [Your Email]

import java.net.*;
import java.io.*;
import java.util.*;

// DO NOT EDIT starts
interface ResolverInterface {
    public void setNameServer(InetAddress ipAddress, int port) throws Exception;

    public InetAddress iterativeResolveAddress(String domainName) throws Exception;
    public String iterativeResolveText(String domainName) throws Exception;
    public String iterativeResolveName(String domainName, int type) throws Exception;
}
// DO NOT EDIT ends

public class Resolver implements ResolverInterface {

    private InetAddress nameServerIP;
    private int nameServerPort;

    @Override
    public void setNameServer(InetAddress ipAddress, int port) {
        this.nameServerIP = ipAddress;
        this.nameServerPort = port;
    }

    @Override
    public InetAddress iterativeResolveAddress(String domainName) throws Exception {
        DNSResult result = iterativeResolve(domainName, 1);
        return result != null ? result.address : null;
    }

    @Override
    public String iterativeResolveText(String domainName) throws Exception {
        DNSResult result = iterativeResolve(domainName, 16);
        return result != null ? result.txt : null;
    }

    @Override
    public String iterativeResolveName(String domainName, int type) throws Exception {
        DNSResult result = iterativeResolve(domainName, type);
        if (result == null) return null;
        switch (type) {
            case 5: return result.cname;
            case 2: return result.ns;
            case 15: return result.mx;
            default: return null;
        }
    }

    private DNSResult iterativeResolve(String domainName, int type) throws Exception {
        Set<String> visited = new HashSet<>();
        List<InetSocketAddress> servers = new ArrayList<>();
        servers.add(new InetSocketAddress(nameServerIP, nameServerPort));

        for (int depth = 0; depth < 10; depth++) {
            List<InetSocketAddress> nextServers = new ArrayList<>();

            for (InetSocketAddress ns : servers) {
                try {
                    byte[] query = buildQuery(domainName, type);
                    byte[] response = sendQuery(query, ns.getAddress(), ns.getPort());
                    DNSResult result = parseResponse(response, domainName, type);

                    if (result.found) {
                        return result;
                    }

                    if (result.cname != null && !result.cname.equalsIgnoreCase(domainName)) {
                        if (visited.contains(result.cname.toLowerCase())) {
                            return null; // CNAME loop detected
                        }
                        visited.add(result.cname.toLowerCase());
                        DNSResult cnameResult = iterativeResolve(result.cname, type);
                        if (cnameResult != null) {
                            return cnameResult;
                        }
                    }

                    if (!result.referralServers.isEmpty()) {
                        nextServers.addAll(result.referralServers);
                    } else if (!result.nsServers.isEmpty()) {
                        // If we have NS server names but no IPs, try to resolve them using a public DNS
                        for (String nsServer : result.nsServers) {
                            try {
                                // Use Google DNS to resolve NS server names
                                InetAddress googleDNS = InetAddress.getByAddress(new byte[]{8,8,8,8});
                                byte[] nsQuery = buildQuery(nsServer, 1);
                                byte[] nsResponse = sendQuery(nsQuery, googleDNS, 53);
                                DNSResult nsResult = parseResponse(nsResponse, nsServer, 1);
                                if (nsResult != null && nsResult.address != null) {
                                    nextServers.add(new InetSocketAddress(nsResult.address, 53));

                                }
                            } catch (Exception e) {

                            }
                        }
                    }
                } catch (SocketTimeoutException e) {
                    continue;
                } catch (IOException e) {
                    continue;
                }
            }

            if (nextServers.isEmpty()) {
                break;
            }
            servers = nextServers;
        }
        return null;
    }

    private byte[] buildQuery(String domain, int type) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        // Header
        dos.writeShort(0x1234); // Transaction ID
        dos.writeShort(0x0100); // Flags - standard query
        dos.writeShort(1);      // Questions count
        dos.writeShort(0);      // Answer RRs
        dos.writeShort(0);      // Authority RRs
        dos.writeShort(0);      // Additional RRs

        // Question section
        String cleanDomain = domain;
        if (cleanDomain.endsWith(".")) {
            cleanDomain = cleanDomain.substring(0, cleanDomain.length() - 1);
        }

        String[] labels = cleanDomain.split("\\.");
        for (String label : labels) {
            if (!label.isEmpty()) {
                byte[] bytes = label.getBytes("UTF-8");
                dos.writeByte(bytes.length);
                dos.write(bytes);
            }
        }
        dos.writeByte(0);       // End of domain name
        dos.writeShort(type);   // Query type
        dos.writeShort(1);     // Query class (IN)

        return baos.toByteArray();
    }

    private byte[] sendQuery(byte[] query, InetAddress server, int port) throws Exception {
        DatagramSocket socket = new DatagramSocket();
        socket.setSoTimeout(2000);

        try {
            DatagramPacket packet = new DatagramPacket(query, query.length, server, port);
            socket.send(packet);

            byte[] buffer = new byte[512];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            socket.receive(response);

            return Arrays.copyOf(response.getData(), response.getLength());
        } finally {
            socket.close();
        }
    }

    private DNSResult parseResponse(byte[] data, String domain, int queryType) throws Exception {
        DNSResult result = new DNSResult();
        DataInputStream dis = new DataInputStream(new ByteArrayInputStream(data));

        // Skip transaction ID
        dis.skipBytes(2);

        // Check response flags
        int flags = dis.readUnsignedShort();
        if ((flags & 0x8000) == 0) {
            throw new IOException("Not a response");
        }
        if ((flags & 0x000F) != 0) {
            return result; // Return empty result for error responses
        }

        int qd = dis.readUnsignedShort();
        int an = dis.readUnsignedShort();
        int ns = dis.readUnsignedShort();
        int ar = dis.readUnsignedShort();



        // Skip question section
        for (int i = 0; i < qd; i++) {
            skipName(dis);
            dis.skipBytes(4);
        }

        // Process answer section
        for (int i = 0; i < an; i++) {
            String name = readName(dis, data);
            int type = dis.readUnsignedShort();
            dis.skipBytes(2); // Skip class
            dis.skipBytes(4); // Skip TTL
            int rdLen = dis.readUnsignedShort();

            // Normalize domain names for comparison
            String normalizedName = name.endsWith(".") ? name.substring(0, name.length() - 1) : name;
            String normalizedDomain = domain.endsWith(".") ? domain.substring(0, domain.length() - 1) : domain;

            if (normalizedName.equalsIgnoreCase(normalizedDomain)) {
                if (type == queryType) {
                    result.found = true;
                    switch (type) {
                        case 1: // A record
                            byte[] addr = new byte[4];
                            dis.readFully(addr);
                            result.address = InetAddress.getByAddress(addr);
                            break;
                        case 5: // CNAME
                            result.cname = readName(dis, data);
                            break;
                        case 2: // NS
                            result.ns = readName(dis, data);
                            break;
                        case 15: // MX
                            dis.readUnsignedShort(); // Skip preference
                            result.mx = readName(dis, data);
                            break;
                        case 16: // TXT
                            int txtLen = dis.readUnsignedByte();
                            byte[] txt = new byte[txtLen];
                            dis.readFully(txt);
                            result.txt = new String(txt, "UTF-8");
                            break;
                        default:
                            dis.skipBytes(rdLen);
                    }
                } else if (type == 5) { // CNAME record for different name
                    result.cname = readName(dis, data);
                } else {
                    dis.skipBytes(rdLen);
                }
            } else {
                dis.skipBytes(rdLen);
            }
        }

        // If we found an answer, return it immediately
        if (result.found) {
            return result;
        }

        // Process additional section for glue records
        Map<String, InetAddress> glue = new HashMap<>();
        for (int i = 0; i < ar; i++) {
            String name = readName(dis, data);
            int type = dis.readUnsignedShort();
            dis.skipBytes(2); // Skip class
            dis.skipBytes(4); // Skip TTL
            int rdLen = dis.readUnsignedShort();

            if (type == 1 && rdLen == 4) { // A record (glue)
                byte[] addr = new byte[4];
                dis.readFully(addr);
                glue.put(name.toLowerCase(), InetAddress.getByAddress(addr));
            } else {
                dis.skipBytes(rdLen);
            }
        }

        // Process authority section for NS records and glue records
        for (int i = 0; i < ns; i++) {
            String name = readName(dis, data);
            int type = dis.readUnsignedShort();
            dis.skipBytes(2); // Skip class
            dis.skipBytes(4); // Skip TTL
            int rdLen = dis.readUnsignedShort();



            if (type == 2) { // NS record
                String nsHost = readName(dis, data);
                result.nsServers.add(nsHost);
                InetAddress ip = glue.get(nsHost.toLowerCase());
                if (ip != null) {
                    result.referralServers.add(new InetSocketAddress(ip, 53));
                }
            } else if (type == 1 && rdLen == 4) { // A record (glue)
                byte[] addr = new byte[4];
                dis.readFully(addr);
                InetAddress ip = InetAddress.getByAddress(addr);
                result.referralServers.add(new InetSocketAddress(ip, 53));
            } else {
                dis.skipBytes(rdLen);
            }
        }

        return result;
    }

    private void skipName(DataInputStream dis) throws IOException {
        int len;
        while ((len = dis.readUnsignedByte()) != 0) {
            if ((len & 0xC0) == 0xC0) {
                dis.readUnsignedByte();
                break;
            } else {
                dis.skipBytes(len);
            }
        }
    }

    private String readName(DataInputStream dis, byte[] full) throws IOException {
        StringBuilder name = new StringBuilder();
        int len = dis.readUnsignedByte();
        while (len != 0) {
            if ((len & 0xC0) == 0xC0) {
                int b2 = dis.readUnsignedByte();
                int ptr = ((len & 0x3F) << 8) | b2;
                name.append(readNameFromPointer(full, ptr));
                break;
            } else {
                byte[] label = new byte[len];
                dis.readFully(label);
                name.append(new String(label, "UTF-8")).append(".");
                len = dis.readUnsignedByte();
            }
        }
        if (name.length() > 0 && name.charAt(name.length() - 1) == '.') {
            name.setLength(name.length() - 1);
        }
        return name.toString();
    }

    private String readNameFromPointer(byte[] data, int offset) throws IOException {
        StringBuilder name = new StringBuilder();
        int len = data[offset++] & 0xFF;
        while (len != 0) {
            if ((len & 0xC0) == 0xC0) {
                int b2 = data[offset++] & 0xFF;
                int ptr = ((len & 0x3F) << 8) | b2;
                name.append(readNameFromPointer(data, ptr));
                break;
            } else {
                byte[] label = Arrays.copyOfRange(data, offset, offset + len);
                name.append(new String(label, "UTF-8")).append(".");
                offset += len;
                len = data[offset++] & 0xFF;
            }
        }
        if (name.length() > 0 && name.charAt(name.length() - 1) == '.') {
            name.setLength(name.length() - 1);
        }
        return name.toString();
    }

    private static class DNSResult {
        boolean found = false;
        InetAddress address;
        String txt, cname, ns, mx;
        List<InetSocketAddress> referralServers = new ArrayList<>();
        List<String> nsServers = new ArrayList<>();
    }
}